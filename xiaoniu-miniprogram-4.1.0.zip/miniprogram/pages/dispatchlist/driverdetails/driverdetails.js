var app=getApp();
Page({
    data:{
        addriverID:'',
    },
    onLoad:function (e) {
        this.data.addriverID=e.driverID
        var driverID=e.driverID
        this.setData({
            phone:app.globalData[16],
        })
        var options = {
            port: 'driverDtlQry3',
            body: {
                "driverID":driverID,
            }
        }
        app.connect(options).then(values => {
            console.log(values)
            this.setData({
                shuju:values.data.body.content.driverInfo
            })
        })
    },
    onphone:function (e) {
        var phoneNunmber=e.currentTarget.dataset.name
        wx.makePhoneCall({
            phoneNumber: phoneNunmber
        })
    },
    onPreservation:function() {
        if (!this.pageLoading) {
            this.pageLoading = !0;
            wx.navigateTo({
                url: '../../order/adddriver/adddriver?datas=' + this.data.addriverID
            })
        }
    },
    onShow:function () {
        this.pageLoading = !1
    }
})
