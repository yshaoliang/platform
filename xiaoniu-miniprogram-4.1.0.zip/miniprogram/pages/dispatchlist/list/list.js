var app = getApp();
Page({
    data: {
   //     showRight1: false,
        alltime:'',
        time:'',
        month:'',
        volume:'',
        number:'',
        deliverytime:'',
        dispatchID:'',
        dispatchBatchID:'',
        name:'',
        bepresentcolor:'',
        shipmentcolor:'',
        signincolor:'',
        allmycars:[],
        index:0,
        alldatas:[],
        volumeUnit:'',
        quantityUnit:'',
        quality:0,
        numbers:0,
        company:"",
        company1:"",
    },
    /*下拉刷新*/
    onPullDownRefresh() {
        this.data.index=0
        this.data.alldatas.splice(0, this.data.alldatas.length);
        this.onLoad().then(values => {
            wx.stopPullDownRefresh()
        })
    },
    onReachBottom: function () {
        console.log(app.orderdata["dispatchStatusCode"])
        var dispatchStatus=null;
        if(app.orderdata["dispatchStatusCode"]!=""){
            dispatchStatus="1141010"
        }
        this.data.quality=0
        this.data.numbers=0
        this.data.index=this.data.index+1
        var that = this;
        var options = {
            port: 'dispatchBatchListQry',
            body: {
                dispatchStatus:dispatchStatus,
                "pageIndex": that.data.index,
                "pageSize": 10,
                "graphicCode": null,
                "sessionGraphicCode": null
            }
        }

            app.connect(options).then(values => {
                let j;
                if(values.data.body.content.arrDispatchBatchInfo.length==0){
                    this.setData({
                        load:true,
                        load1:true
                    })
                }
                console.log(values)
                for (j = 0; j <values.data.body.content.arrDispatchBatchInfo.length; j++) {
                    values.data.body.content.arrDispatchBatchInfo[j].arrDispatchAbstractInfo[0].consignorInfo.addressInfo.cityShortName=app.oncityNam(values.data.body.content.arrDispatchBatchInfo[j].arrDispatchAbstractInfo[0].consignorInfo.addressInfo.cityShortName)
                    values.data.body.content.arrDispatchBatchInfo[j].arrDispatchAbstractInfo[0].consigneeInfo.addressInfo.cityShortName=app.oncityNam(values.data.body.content.arrDispatchBatchInfo[j].arrDispatchAbstractInfo[0].consigneeInfo.addressInfo.cityShortName)
                }
                var mycars = new Array()
                for (var i = 0; i <values.data.body.content.arrDispatchBatchInfo.length; i++) {
                    var bepresentcolor;
                    var shipmentcolor;
                    var signincolor;
                    var colors=new Array()
                    for(j = 0; j<values.data.body.content.arrDispatchBatchInfo[i].arrDispatchAbstractInfo.length; j++){
                        if(values.data.body.content.arrDispatchBatchInfo[i].arrDispatchAbstractInfo[j].dispatchStatus=="1141005") {
                            bepresentcolor='#DBDBDB',
                                shipmentcolor='#007aff',
                                signincolor="#aaaaaa"
                        }else if(values.data.body.content.arrDispatchBatchInfo[i].arrDispatchAbstractInfo[j].dispatchStatus=="1141000"){
                            bepresentcolor='#007aff',
                                shipmentcolor='#aaaaaa',
                                signincolor="#aaaaaa"
                        }else{
                            bepresentcolor='#DBDBDB',
                                shipmentcolor='#DBDBDB',
                                signincolor="#007aff"
                        }
                        var  allcolors={bepresentcolor:bepresentcolor,shipmentcolor:shipmentcolor,signincolor:signincolor}
                        colors[j]=allcolors
                    }
                    var date =values.data.body.content.arrDispatchBatchInfo[i].arrDispatchAbstractInfo[0].dispatchBatchUpdateTime
                    that.data.month=date.substring(11,16);
                    /*当前时间*/
                    var myDate = new Date();
                    /*输出时间的月份*/
                    var lastmonth= date.substring(5,7);
                    var lastdate= date.substring(8,10);
                    /*获得当前时间的月份*/
                    var newmonth=myDate.getMonth()+1;
                    var newdtae=myDate.getDate();
                    if(lastmonth==newmonth&&newdtae==lastdate){
                        that.data.time="今天";
                    }else if(lastmonth==newmonth&&newdtae==(parseInt(lastdate)+1).toString()){
                        that.data.time="昨天";
                    }else{
                        that.data.time=date.substring(5,11);
                    }
                    that.data.alltime={alldara:values.data.body.content.arrDispatchBatchInfo[i],month:that.data.month,time:that.data.time,colors:colors,quality:"",numbers:"",company:"",company1:""}
                    mycars.push(that.data.alltime)
                }

                console.log(mycars)
                for(var i=0;i<mycars.length;i++){
                    that.data.alldatas.push(mycars[i])

                }
                console.log(that.data.alldatas)
                for(var i=0;i<that.data.alldatas.length;i++) {
                    that.data.quality = 0
                    that.data.numbers = 0
                    that.data.company = ""
                    that.data.company1 = ""
                    if (that.data.alldatas[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo != null) {
                    for (j = 0; j < that.data.alldatas[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo.length; j++) {
                        if (that.data.alldatas[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].volume == 0) {
                            if (that.data.company == "") {
                                that.data.company = that.data.alldatas[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].weightUnit
                            } else {
                                if (that.data.company != that.data.alldatas[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].weightUnit) {
                                    that.data.company = "单位"
                                }
                            }
                            if (that.data.company1 == "") {
                                that.data.company1 = that.data.alldatas[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].quantityUnit
                            } else {
                                if (that.data.company1 != that.data.alldatas[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].quantityUnit) {
                                    that.data.company1 = "单位"
                                }
                            }
                            that.data.quality = Number(that.data.quality) + Number(that.data.alldatas[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].weight)
                            that.data.numbers = Number(that.data.numbers) + Number(that.data.alldatas[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].quantity)
                        } else {
                            if (that.data.company == "") {
                                that.data.company = that.data.alldatas[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].volumeUnit
                            } else {
                                if (that.data.company != that.data.alldatas[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].volumeUnit) {
                                    that.data.company = "单位"
                                }
                            }
                            if (that.data.company1 == "") {
                                that.data.company1 = that.data.alldatas[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].quantityUnit
                            } else {
                                if (that.data.company1 != that.data.alldatas[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].quantityUnit) {
                                    that.data.company1 = "单位"
                                }
                            }
                            that.data.quality = Number(that.data.quality) + Number(that.data.alldatas[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].volume)
                            that.data.numbers = Number(that.data.numbers) + Number(that.data.alldatas[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].quantity)
                        }
                    }
                }
                    that.data.alldatas[i].company1=that.data.company1
                    that.data.alldatas[i].company=that.data.company
                    that.data.alldatas[i].quality=that.data.quality
                    that.data.alldatas[i].numbers=that.data.numbers
                }
                console.log(that.data.alldatas)
                that.setData({
                    shujulist: that.data.alldatas,
                    load:false
                })
            })
    },
    onShow: function () {
        if(app.orderdata["route"]!=""){
            this.onLoad()
        }
        console.log(this.data.alldatas)
    if(app.orderdata["bepresentcolor"]!=""){
        for(var i=0;i<this.data.alldatas.length;i++){
            if(i==app.orderdata["index"]){
                this.data.alldatas[i].colors[app.orderdata["key"]].bepresentcolor=app.orderdata["bepresentcolor"],
                this.data.alldatas[i].colors[app.orderdata["key"]].shipmentcolor=app.orderdata["shipmentcolor"],
                this.data.alldatas[i].colors[app.orderdata["key"]].signincolor=app.orderdata["signincolor"]
                this.data.alldatas[i].alldara.arrDispatchAbstractInfo[app.orderdata["key"]].dispatchStatusDesc="已装运"
            }
        }
        this.setData({
            shujulist:this.data.alldatas
        })

    }
    if(app.orderdata["dispatchStatus"]!=""){
        console.log(app.orderdata["dispatchStatus"])
        for(var i=0;i<this.data.alldatas.length;i++){
            if(i==app.orderdata["index"]){
                this.data.alldatas[i].alldara.arrDispatchAbstractInfo[app.orderdata["key"]].dispatchStatus=app.orderdata["dispatchStatus"]
                this.data.alldatas[i].alldara.arrDispatchAbstractInfo[app.orderdata["key"]].dispatchStatusDesc="已签收"
            }
        }
        this.setData({
            shujulist:this.data.alldatas
        })

    }

    for(var i=0;i<app.globalData.getAllFuncCodeByCurrUser.length;i++){
        if(app.globalData.getAllFuncCodeByCurrUser[i]=="Q040030"){
            console.log("装运")
            this.setData({
                shipment:true
            })
        }else if(app.globalData.getAllFuncCodeByCurrUser[i]=="Q040040"){
            console.log("签收")
            this.setData({
                sign:true
            })
        }
    }
        this.pageLoading = !1
    },
    /*页面加载数据*/
    onLoad: function () {
        this.data.quality=0
        this.data.numbers=0
        app.loads()
        console.log(app.orderdata["dispatchStatusCode"])
        var dispatchStatus=null;
        if(app.orderdata["dispatchStatusCode"]!=""){
            dispatchStatus="1141010"
        }
        app.orderdata["dispatchStatus"]="",
            app.orderdata["key"]="",
            app.orderdata["index"]="",
            app.orderdata["bepresentcolor"]="",
            app.orderdata["shipmentcolor"]="",
            app.orderdata["signincolor"]="",
        this.data.index=0
        this.data.alldatas.splice(0,this.data.alldatas.length);
        var that = this;
        that.setData({
            load1:false,
            forward:app.globalData[48],
            shfTt:app.globalData.shfTt,
            isdriver:app.orderdata["driver"],
            isblue:this.data.isblue,
            isDarkgrey:this.data.isDarkgrey,
            islightgray:this.data.islightgray,
            to: app.globalData[14],
        })
        var orderID=null;
        if(app.orderdata["orderID"]!=""){
            orderID=app.orderdata["orderID"]
        }else{
            orderID=app.orderID
        }
        var options = {
            port: 'dispatchBatchListQry',
            body: {
                orderID:orderID,
                dispatchStatus:dispatchStatus,
                "pageIndex": this.data.index,
                "pageSize": 10,
                "graphicCode": null,
                "sessionGraphicCode": null
            }
        }

        let prom1 = new Promise(function (resolve, reject) {
        app.connect(options).then(values => {
            wx.hideLoading()
            console.log(values)
            for (var j = 0; j <values.data.body.content.arrDispatchBatchInfo.length; j++) {
                values.data.body.content.arrDispatchBatchInfo[j].arrDispatchAbstractInfo[0].consignorInfo.addressInfo.cityShortName=app.oncityNam(values.data.body.content.arrDispatchBatchInfo[j].arrDispatchAbstractInfo[0].consignorInfo.addressInfo.cityShortName)
                values.data.body.content.arrDispatchBatchInfo[j].arrDispatchAbstractInfo[0].consigneeInfo.addressInfo.cityShortName=app.oncityNam(values.data.body.content.arrDispatchBatchInfo[j].arrDispatchAbstractInfo[0].consigneeInfo.addressInfo.cityShortName)
            }
            var mycars = new Array()
            for (var i = 0; i <values.data.body.content.arrDispatchBatchInfo.length; i++) {
                var bepresentcolor;
                var shipmentcolor;
                var signincolor;
                var colors=new Array()
                for(var j=0;j<values.data.body.content.arrDispatchBatchInfo[i].arrDispatchAbstractInfo.length;j++){
                    if(values.data.body.content.arrDispatchBatchInfo[i].arrDispatchAbstractInfo[j].dispatchStatus=="1141005") {
                        bepresentcolor='#DBDBDB',
                            shipmentcolor='#007aff',
                            signincolor="#aaaaaa"
                    }else if(values.data.body.content.arrDispatchBatchInfo[i].arrDispatchAbstractInfo[j].dispatchStatus=="1141000"){
                        bepresentcolor='#007aff',
                            shipmentcolor='#aaaaaa',
                            signincolor="#aaaaaa"
                    }else{
                        bepresentcolor='#DBDBDB',
                            shipmentcolor='#DBDBDB',
                            signincolor="#007aff"
                    }
                    var  allcolors={bepresentcolor:bepresentcolor,shipmentcolor:shipmentcolor,signincolor:signincolor}
                    colors.push(allcolors)
                }
                var date =values.data.body.content.arrDispatchBatchInfo[i].arrDispatchAbstractInfo[0].dispatchBatchUpdateTime
                that.data.month=date.substring(11,16);
                /*当前时间*/
                var myDate = new Date();
                /*输出时间的月份*/
                var lastmonth= date.substring(5,7);
                var lastdate= date.substring(8,10);
                /*获得当前时间的月份*/
                var newmonth=myDate.getMonth()+1;
                var newdtae=myDate.getDate();
               if(lastmonth==newmonth&&newdtae==lastdate){
                   that.data.time="今天";
                }else if(lastmonth==newmonth&&newdtae==(parseInt(lastdate)+1).toString()){
                   that.data.time="昨天";
               }else{
                   that.data.time=date.substring(5,11);
                }
                that.data.alltime={alldara:values.data.body.content.arrDispatchBatchInfo[i],month:that.data.month,time:that.data.time,colors:colors,quality:"",numbers:"",company:"",company1:""}
                mycars.push(that.data.alltime)
            }
                that.data.alldatas=mycars
            console.log(mycars)
            for(var i=0;i<mycars.length;i++){
                that.data.quality=0
                that.data.numbers=0
                that.data.company=""
                that.data.company1=""
                for(var j=0;j<mycars[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo.length;j++){
                    if(mycars[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].volume==0){
                        if(that.data.company==""){
                            that.data.company=mycars[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].weightUnit
                        }else{
                            if(that.data.company!=mycars[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].weightUnit){
                                that.data.company="单位"
                            }
                        }
                        if(that.data.company1==""){
                            that.data.company1=mycars[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].quantityUnit
                        }else{
                            if(that.data.company1!=mycars[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].quantityUnit){
                                that.data.company1="单位"
                            }
                        }
                        that.data.quality=Number(that.data.quality)+Number(mycars[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].weight)
                        that.data.numbers=Number(that.data.numbers)+Number(mycars[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].quantity)
                    }else{
                        if(that.data.company==""){
                            that.data.company=mycars[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].volumeUnit
                        }else{
                            if(that.data.company!=mycars[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].volumeUnit){
                                that.data.company="单位"
                            }
                        }
                        if(that.data.company1==""){
                            that.data.company1=mycars[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].quantityUnit
                        }else{
                            if(that.data.company1!=mycars[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].quantityUnit){
                                that.data.company1="单位"
                            }
                        }
                        that.data.quality=Number(that.data.quality)+Number(mycars[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].volume)
                        that.data.numbers=Number(that.data.numbers)+Number(mycars[i].alldara.arrDispatchAbstractInfo[0].arrCargoInfo[j].arrAmountInfo[0].quantity)
                    }
                }
                mycars[i].company1=that.data.company1
                mycars[i].company=that.data.company
                mycars[i].quality=that.data.quality
                mycars[i].numbers=that.data.numbers
            }
            console.log(that.data.alldatas)
            console.log(mycars.length)
            if(mycars.length==0){
                wx.showModal({
                    title:"提示",
                    content:"派车单数据为空",
                    showCancel:false,
                    //退出失败，可能一些原因导致
                    success:function (res) {
                        if (res.confirm){
                            wx.navigateBack({
                                delta: -1
                            });
                        }
                    },
                    fail:function (res) {
                        wx.showToast({
                            title:"退出失败,请反馈",
                            duration:1500,
                        });
                    },
                });
            }
            that.setData({
                shujulist: mycars
            })
            resolve(values)
        })
        });
        return prom1;
    },
    /*点击跳详情页面*/
    ondispatch: function (e) {
        if(app.orderdata["type"]!="speed"){
            var s=e.currentTarget.dataset.name.split(",")
            app.islistdispatchBatchID = s[0],
                app.orderdata["company"]=s[3]
            app.orderdata["company1"]=s[4]
            console.log(e.currentTarget.dataset.id)
            if (!this.pageLoading) {
                this.pageLoading = !0;
                wx.navigateTo({
                    url: "../schedulingdetails/schedulingdetails?id=" + e.currentTarget.dataset.id+"&quality="+s[1]+"&numbers="+s[2],
                })
            }
        }else{
            var s=e.currentTarget.dataset.name.split(",")
            wx.navigateTo({
                url: "../../order/speedprogress/speedprogress?dispatchID="+s[0]
            })
        }

    },
    ondispatch1:function(e){
        if (!this.pageLoading) {
            this.pageLoading = !0;
        console.log(e.currentTarget.dataset.name)
        var s=e.currentTarget.dataset.name.split(",")
        app.islistdispatchBatchID = s[0],
            wx.navigateTo({
                url: "../takedeliveryofgoods/takedeliveryofgoods?id=" + e.currentTarget.dataset.id + "&dispatchBatchID=" + s[0] + "&dispatchID=" + s[1] + "&cargoName=" + s[2]+"&key="+s[3]+"&index="+s[4],
            })
        }
    },
    ondispatch2:function(e){
        var s=e.currentTarget.dataset.name.split(",")
        app.islistdispatchBatchID = s[3]
        var options = {
            port: 'dispatchBatchDtlQry',
            body: {
                "dispatchBatchID": s[0],
                "graphicCode": null,
                "sessionGraphicCode": null
            }
        }
        app.connect(options).then(values => {
            if (values.data.body.content.arrDispatchAbstractInfo[0].dispatchStatusDesc == "已到场") {
                this.data.dispatch_status = 1141010;
            }
            values.data.body.content.arrDispatchAbstractInfo[0].consignorInfo.addressInfo.cityName = app.oncityNam(values.data.body.content.arrDispatchAbstractInfo[0].consignorInfo.addressInfo.cityName)
            values.data.body.content.arrDispatchAbstractInfo[0].consigneeInfo.addressInfo.cityName = app.oncityNam(values.data.body.content.arrDispatchAbstractInfo[0].consigneeInfo.addressInfo.cityName)

            if (values.data.body.content.arrDispatchAbstractInfo[0].arrCargoInfo[0].arrAmountInfo[0].volume != "0") {
                this.data.volume = values.data.body.content.arrDispatchAbstractInfo[0].arrCargoInfo[0].arrAmountInfo[0].volume
                  this.data.volumeUnit=values.data.body.content.arrDispatchAbstractInfo[0].arrCargoInfo[0].arrAmountInfo[0].volumeUnit;
            } else {
                this.data.volume = values.data.body.content.arrDispatchAbstractInfo[0].arrCargoInfo[0].arrAmountInfo[0].weight
                   this.data.volumeUnit=values.data.body.content.arrDispatchAbstractInfo[0].arrCargoInfo[0].arrAmountInfo[0].weightUnit;
            }
            this.data.number = values.data.body.content.arrDispatchAbstractInfo[0].arrCargoInfo[0].arrAmountInfo[0].quantity
            this.data.quantityUnit= values.data.body.content.arrDispatchAbstractInfo[0].arrCargoInfo[0].arrAmountInfo[0].quantityUnit
            this.data.deliverytime = values.data.body.content.arrDispatchAbstractInfo[0].createTime
            this.data.dispatchBatchID = values.data.body.content.arrDispatchAbstractInfo[0].dispatchBatchID
            this.data.dispatchID = values.data.body.content.arrDispatchAbstractInfo[0].dispatchID
            this.data.arrCargoInfo = values.data.body.content.arrDispatchAbstractInfo[0].arrCargoInfo
            app.arrCargoInfoAll = this.data.arrCargoInfo
            this.data.name = values.data.body.content.arrDispatchAbstractInfo[0].consigneeInfo.name
                app.orderdata["route"] = "list"
            if (!this.pageLoading) {
                this.pageLoading = !0;
                wx.navigateTo({
                    url: '../signin/signin?volume=' + this.data.volume + "&volumeUnit=" + this.data.volumeUnit + "&number=" + this.data.number + "&quantityUnit=" + this.data.quantityUnit + "&deliverytime=" + this.data.deliverytime + "&dispatchID=" + this.data.dispatchID + "&dispatchBatchID=" + this.data.dispatchBatchID + "&name=" + this.data.name + "&id=" + e.currentTarget.dataset.id+"&key="+s[1]+"&index="+s[2],
                })
            }
        })

    },
  toggleRight1(e) {
    this.setData({
      showRight1: !this.data.showRight1
    });
  },
    onupdatastatus:function (e){
        var that=this;
        var index=e.currentTarget.dataset.id
        wx.showModal({
            title: '提醒',
            content: '是否到场!',
            success: function (res) {
                if (res.confirm) {//这里是点击了确定以后
                    console.log(index)
                    var s=index.split(",")
                    var options = {
                        port: 'dispatchStatusUpd',
                        body: {
                            "dispatchID":  e.currentTarget.dataset.name,
                            "dispatchStatus": 1141005,
                        }
                    }
                    app.connect(options).then(values => {
                        console.log(999)
                        console.log(that.data.alldatas)
                        that.data.alldatas[s[1]].colors[[s[0]]].bepresentcolor="#DBDBDB"
                        that.data.alldatas[s[1]].colors[[s[0]]].shipmentcolor="#007aff"
                        that.data.alldatas[s[1]].colors[[s[0]]].signincolor="#aaaaaa"
                        that.data.alldatas[s[1]].alldara.arrDispatchAbstractInfo[[s[0]]].dispatchStatusDesc="已到场"
                        console.log(that.data.alldatas)
                        that.setData({
                            shujulist:that.data.alldatas
                        })

                    })
                } else {//这里是点击了取消以后
                    console.log(that.data.alldatas)
                    console.log('用户点击取消')
                }
            }
        })
    },

})