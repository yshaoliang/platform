var app = getApp();
Page({
    data: {
        volume: '',
        number: '',
        deliverytime: '',
        dispatchBatchID: '',
        arrCargoInfo: '',
        dispatchID:'',
        name:'',
        dispatch_status:'',
        cargoName:'',
        volumeUnit:'',
        quantityUnit:'',
        carryquality:0,
        carrynumbers:0,
        signquality:0,
        signnumbers:0,
    },
    /*下拉刷新*/
    onPullDownRefresh() {
        wx.stopPullDownRefresh()
    },
    onShow:function(){
        for(var i=0;i<app.globalData.getAllFuncCodeByCurrUser.length;i++){
            if(app.globalData.getAllFuncCodeByCurrUser[i]=="Q040030"){
                console.log("装运")
                this.setData({
                    shipment:true
                })
            }else if(app.globalData.getAllFuncCodeByCurrUser[i]=="Q040040"){
                console.log("签收")
                this.setData({
                    sign:true
                })
            }
        }
        this.pageLoading = !1
        this.onLoads();
    },
    /*数据加载*/
    onLoad: function (e) {
   var that=this;
        app.loads()
            this.data.dispatch_status=e.id
        this.setData({
            company: app.orderdata["company"],
            company1: app.orderdata["company1"],
            forward:app.globalData[48],
            shfTt:app.globalData.shfTt,
            btnlocationdefault:app.globalData[15],
            phone:app.globalData[16],
            delivergoods:app.globalData[17],
            collectgoods:app.globalData[18],
        })
        var options = {
            port: 'dispatchDtlQry3',
            body: {
                "dispatchID": app.islistdispatchBatchID,
                "graphicCode": null,
                "sessionGraphicCode": null
            }
        }
        app.connect(options).then(values => {
            console.log(values)
            wx.hideLoading()
            this.data.cargoName=values.data.body.content.arrCargoInfo[0].cargoName
            if(values.data.body.content.dispatchStatusDesc=="已到场"){
                this.data.dispatch_status=1141010;
            }
            if (values.data.body.content.arrCargoInfo[0].arrAmountInfo[0].volume != "0") {
                this.data.volume= values.data.body.content.arrCargoInfo[0].arrAmountInfo[0].volume
                this.data.volumeUnit=values.data.body.content.arrCargoInfo[0].arrAmountInfo[0].volumeUnit;
            } else {
                this.data.volume = values.data.body.content.arrCargoInfo[0].arrAmountInfo[0].weight
                this.data.volumeUnit=values.data.body.content.arrCargoInfo[0].arrAmountInfo[0].weightUnit;
            }
            this.data.number = values.data.body.content.arrCargoInfo[0].arrAmountInfo[0].quantity
            this.data.quantityUnit= values.data.body.content.arrCargoInfo[0].arrAmountInfo[0].quantityUnit
            console.log(this.data.quantityUnit)

            values.data.body.content.consignorInfo.addressInfo.cityName=app.oncityNam(values.data.body.content.consignorInfo.addressInfo.cityName)
            values.data.body.content.consigneeInfo.addressInfo.cityName=app.oncityNam(values.data.body.content.consigneeInfo.addressInfo.cityName)
            this.data.deliverytime = values.data.body.content.createTime
            this.data.dispatchBatchID = values.data.body.content.dispatchBatchID
            this.data.dispatchID=values.data.body.content.dispatchID
            this.data.arrCargoInfo = values.data.body.content.arrCargoInfo
            app.arrCargoInfoAll=this.data.arrCargoInfo
            this.data.name=values.data.body.content.consigneeInfo.name
            console.log(654)
            that.data.carryquality=0
            that.data.carrynumbers=0
            that.data.signquality=0
            that.data.signnumbers=0
            for(var i=0;i<values.data.body.content.arrCargoInfo.length;i++){
                for(var j=0;j<values.data.body.content.arrCargoInfo[i].arrAmountInfo.length;j++){
                    if(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].amountBizType==7){
                        if(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].volume!=0){
                          that.data.carryquality=Number(that.data.carryquality)+Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].volume)
                        }else{
                            that.data.carryquality=Number(that.data.carryquality)+Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].weight)
                        }
                        that.data.carrynumbers=Number(that.data.carrynumbers)+Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].quantity)
                    }
                    if(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].amountBizType==8){
                        if(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].volume!=0){
                            that.data.signquality=Number(that.data.signquality)+Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].volume)
                        }else{
                            that.data.signquality=Number(that.data.signquality)+Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].weight)
                        }
                        that.data.signnumbers=Number(that.data.signnumbers)+Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].quantity)
                    }
                }
            }
            if(values.data.body.content.consigneeInfo.addressInfo.cityName==null&&values.data.body.content.consigneeInfo.companyName==""){
                this.setData({
                    size:454-181.6
                })
            }else if(values.data.body.content.consigneeInfo.addressInfo.cityName!=null&&values.data.body.content.consigneeInfo.companyName!=""){
                this.setData({
                    size:454
                })
            }else{
                this.setData({
                    size:454-90.8
                })
            }
            this.setData({
                signquality:that.data.signquality,
                signnumbers:that.data.signnumbers,
                carryquality:that.data.carryquality,
                carrynumbers: that.data.carrynumbers,
                quality: e.quality,
                numbers:e.numbers,
                whetherornotshipment:values.data.body.content.dispatchStatusDesc,
                schedushuju: values.data.body.content
            })

            app.userSimpleInfo={
                userID:values.data.body.content.dispatcher.userID,
                userName:values.data.body.content.dispatcher.userName,
                companyID:values.data.body.content.dispatcher.companyID,
                companyName:values.data.body.content.dispatcher.companyName,
                orgType: values.data.body.content.dispatcher.orgType,
                companyType:"",
                mobile:values.data.body.content.dispatcher.mobile,
                portraitPhotoUrl:values.data.body.content.dispatcher.portraitPhotoUrl,
            }
        })
    },
    /*点击跳到发货页面*/
    onLoadingandshipping: function (e) {
        console.log(e.currentTarget.dataset.name)
        app.islistdispatchBatchID=e.currentTarget.dataset.name
        if (!this.pageLoading) {
            this.pageLoading = !0;
            wx.navigateTo({
                url: '../takedeliveryofgoods/takedeliveryofgoods?volume=' + this.data.volume + "&number=" + this.data.number + "&deliverytime=" + this.data.deliverytime + "&dispatchID=" + this.data.dispatchID + "&dispatchBatchID=" + this.data.dispatchBatchID + "&dispatch_status=" + this.data.dispatch_status + "&cargoName=" + this.data.cargoName
            })
        }
    },
    /*点击跳转签收页面*/
    onLoadingandshipping1: function () {
            app.orderdata["route"]="schedulingdetails"
        if (!this.pageLoading) {
            this.pageLoading = !0;
            wx.navigateTo({
                url: '../signin/signin?volume=' + this.data.volume + "&volumeUnit=" + this.data.volumeUnit + "&number=" + this.data.number + "&quantityUnit=" + this.data.quantityUnit + "&deliverytime=" + this.data.deliverytime + "&dispatchID=" + this.data.dispatchID + "&dispatchBatchID=" + this.data.dispatchBatchID + "&name=" + this.data.name
            })
        }
    },
    onphone:function (e) {
        var phoneNunmber=e.currentTarget.dataset.name
        wx.makePhoneCall({
            phoneNumber: phoneNunmber
        })
    },
    chooseimage: function () {
        if (!this.pageLoading) {
            this.pageLoading = !0;
            wx.navigateTo({
                url: '../../order/processinglog/processinglog?type=' + 2 + "&dispatchID=" + this.data.dispatchID
            })
        }
    },
    onvehicletype:function (e) {
        app.orderID=e.currentTarget.dataset.name
        if (!this.pageLoading) {
            this.pageLoading = !0;
            wx.navigateTo({
                url: '../../order/orderDtlQry/orderDtlQry'
            })
        }
    },
    onchiefDriver:function (e) {
        var driverID=e.currentTarget.dataset.name
        if (!this.pageLoading) {
            this.pageLoading = !0;
            wx.navigateTo({
                url: '../driverdetails/driverdetails?driverID=' + driverID
            })
        }
    },
    onvehicleCode:function (e) {
        var vehicleID=e.currentTarget.dataset.name
        if (!this.pageLoading) {
            this.pageLoading = !0;
            wx.navigateTo({
                url: '../particulars/particulars?vehicleID=' + vehicleID
            })
        }
        
    },
onLoads:function () {
    var options = {
        port: 'dispatchDtlQry3',
        body: {
            "dispatchID": app.islistdispatchBatchID,
            "graphicCode": null,
            "sessionGraphicCode": null
        }
    }
    app.connect(options).then(values => {
        console.log(values)
        this.data.cargoName=values.data.body.content.arrCargoInfo[0].cargoName
        if(values.data.body.content.dispatchStatusDesc=="已到场"){
            this.data.dispatch_status=1141010;
        }
        if (values.data.body.content.arrCargoInfo[0].arrAmountInfo[0].volume != "0") {
            this.data.volume= values.data.body.content.arrCargoInfo[0].arrAmountInfo[0].volume
            this.data.volumeUnit=values.data.body.content.arrCargoInfo[0].arrAmountInfo[0].volumeUnit;
        } else {
            this.data.volume = values.data.body.content.arrCargoInfo[0].arrAmountInfo[0].weight
            this.data.volumeUnit=values.data.body.content.arrCargoInfo[0].arrAmountInfo[0].weightUnit;
        }
        this.data.number = values.data.body.content.arrCargoInfo[0].arrAmountInfo[0].quantity
        this.data.quantityUnit= values.data.body.content.arrCargoInfo[0].arrAmountInfo[0].quantityUnit
        console.log(this.data.quantityUnit)

        values.data.body.content.consignorInfo.addressInfo.cityName=app.oncityNam(values.data.body.content.consignorInfo.addressInfo.cityName)
        values.data.body.content.consigneeInfo.addressInfo.cityName=app.oncityNam(values.data.body.content.consigneeInfo.addressInfo.cityName)
        this.data.deliverytime = values.data.body.content.createTime
        this.data.dispatchBatchID = values.data.body.content.dispatchBatchID
        this.data.dispatchID=values.data.body.content.dispatchID
        this.data.arrCargoInfo = values.data.body.content.arrCargoInfo
        app.arrCargoInfoAll=this.data.arrCargoInfo
        this.data.name=values.data.body.content.consigneeInfo.name
        if(values.data.body.content.consigneeInfo.addressInfo.cityName==null&&values.data.body.content.consigneeInfo.companyName==""){
            this.setData({
                size:454-181.6
            })
        }else if(values.data.body.content.consigneeInfo.addressInfo.cityName!=null&&values.data.body.content.consigneeInfo.companyName!=""){
            this.setData({
                size:454
            })
        }else{
            this.setData({
                size:454-90.8
            })
        }
        this.setData({
            whetherornotshipment:values.data.body.content.dispatchStatusDesc,
            schedushuju: values.data.body.content
        })

        app.userSimpleInfo={
            userID:values.data.body.content.dispatcher.userID,
            userName:values.data.body.content.dispatcher.userName,
            companyID:values.data.body.content.dispatcher.companyID,
            companyName:values.data.body.content.dispatcher.companyName,
            orgType: values.data.body.content.dispatcher.orgType,
            companyType:"",
            mobile:values.data.body.content.dispatcher.mobile,
            portraitPhotoUrl:values.data.body.content.dispatcher.portraitPhotoUrl,
        }
    })
},
    previewImage:function (e) {
        console.log(e.currentTarget.dataset.name)
        wx.previewImage({
            urls:[e.currentTarget.dataset.name]
        })
    }
})