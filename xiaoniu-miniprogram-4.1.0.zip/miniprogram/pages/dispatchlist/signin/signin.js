var app = getApp();
var publish = require('../../public_util/publishData');
Page({
    data: {
        dispatchID: '',
        arrdata: [],
        name: '',
        time: '',
        multiArray: [publish.years,publish.mouths,publish.days,publish.houvers,publish.branchs],
        multiIndex: ["", "", "","",""],
        delayid:'',
        damagedid:'',
        defectid:'',
        denyid:'',
        arr:[''],
        index:'',
        index1:'',
        key:'',
        fileID:'',
        arrOtherPhotoInfo:[],
        arrOtherPhotoInfoID:[],
        volumevalue:'',
        weightvalue:'',
        numbervalue:'',
        datas:[],
        isConconfirm:"",
        arrPodType:[]
    },
    /*下拉刷新*/
    onPullDownRefresh() {
        wx.stopPullDownRefresh()
    },
    /*获取上页面数据*/
    onLoad: function (e) {
        var options = {
            port: 'dispatchDtlQry3',
            body: {
                "dispatchID": app.islistdispatchBatchID,
                "graphicCode": null,
                "sessionGraphicCode": null
            }
        }
        app.connect(options).then(values => {
            console.log(values)
            this.data.arrPodType=values.data.body.content.arrPodType
            this.setData({
                shuju:values.data.body.content
            })
            for(var i=0;i<values.data.body.content.arrCargoInfo.length;i++){
                var  shuju={
                    volumevalue:"",
                    numbervalue:"",
                    weightvalue:""
                }
                if(values.data.body.content.arrCargoInfo[i].arrAmountInfo[0].volume!=0){
                    shuju.volumevalue=values.data.body.content.arrCargoInfo[i].arrAmountInfo[0].volume
                }else{
                    shuju.weightvalue=values.data.body.content.arrCargoInfo[i].arrAmountInfo[0].weight
                }
                shuju.numbervalue=values.data.body.content.arrCargoInfo[i].arrAmountInfo[0].quantity
                this.data.datas.push(shuju)
            }
            console.log(this.data.datas)
        })
        this.data.key=e.key
        this.data.index1=e.index
        var now = new Date();
        var year = now.getFullYear(); //得到年份
        var month = now.getMonth();//得到月份
        var date = now.getDate();//得到日期
        var day = now.getDay();//得到周几
        var hour = now.getHours();//得到小时
        var minu = now.getMinutes();//得到分钟
        var sec = now.getSeconds();//得到秒
        month = month + 1;
        if (month < 10) month = "0" + month;
        if (date < 10) date = "0" + date;
        if (hour < 10) hour = "0" + hour;
        if (minu < 10) minu = "0" + minu;
        if (sec < 10) sec = "0" + sec;
        var time = year + "-" + month + "-" + date + " " + hour + ":" + minu + ":" + sec;
        this.data.time = time
        this.data.dispatchID = e.dispatchID
        this.data.name = e.name;
        if(e.volumeUnit=="升"){
            this.data.volumevalue=e.volume
        }else{
            this.data.weightvalue=e.volume
        }
        this.data.numbervalue=e.number,

        this.setData({
            forward:app.globalData[48],
            cargoName:e.name,
            tempFilePaths: this.data.arr,
            company:e.quantityUnit,
            delay: false,
            damaged: false,
            defect: false,
            deny: false,
            circle: app.globalData[38],
            circle1: app.globalData[39],
            volume: e.volume,
            volumeUnit:e.volumeUnit,
            quantityUnit:e.quantityUnit,
            number: e.number,
            deliverytime: time,
        })

    },
    onconfirm: function () {
        console.log(this.data.denyid)
        var taht=this;
        if (!taht.pageLoading) {
            taht.pageLoading = !0;
            for(var i=0;i<taht.data.datas.length;i++){
                if(this.data.datas[i].volumevalue==""&&this.data.datas[i].weightvalue==""||this.data.datas[i].weightvalue=="0"){
                    taht.data.isConconfirm=false
                    taht.pageLoading = !1;
                    wx.showToast({
                        title: "签收量不能为空",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                    })
                }else if(this.data.datas[i].volumevalue=="0"&&this.data.datas[i].weightvalue==""||this.data.datas[i].weightvalue=="0"){
                    taht.data.isConconfirm=false
                    taht.pageLoading = !1;
                    wx.showToast({
                        title: "签收量不能为空",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                    })
                }else{
                    taht.data.isConconfirm=true
                }
            }
            if(taht.data.isConconfirm==true){
                var arrExecResult = []
                if (taht.data.delayid != "") {
                    arrExecResult.push(taht.data.delayid)
                }
                if (taht.data.damagedid != "") {
                    arrExecResult.push(taht.data.damagedid)
                }
                if (taht.data.defectid != "") {
                    arrExecResult.push(taht.data.defectid)
                }
                if (taht.data.denyid != "") {
                    arrExecResult.push(taht.data.denyid)
                }
                console.log(app.arrCargoInfoAll)
                for (var i = 0; i < app.arrCargoInfoAll.length; i++) {
                    for (var j = 0; j < app.arrCargoInfoAll[i].arrAmountInfo.length; j++) {
                        if (app.arrCargoInfoAll[i].arrAmountInfo[j].amountBizType == "7") {
                            app.arrCargoInfoAll[i].arrAmountInfo[j].amountBizType = "8"
                            app.arrCargoInfoAll[i].arrAmountInfo[j].volume = taht.data.datas[i].volumevalue
                            app.arrCargoInfoAll[i].arrAmountInfo[j].weight = taht.data.datas[i].weightvalue
                            app.arrCargoInfoAll[i].arrAmountInfo[j].quantity = taht.data.datas[i].numbervalue
                        }
                        var datas = {
                            arrExecResult: [taht.data.delayid, taht.data.damagedid, taht.data.defectid, taht.data.denyid],
                            cargoID: app.arrCargoInfoAll[i].cargoID,
                            cargoName: app.arrCargoInfoAll[i].cargoName,
                            model: app.arrCargoInfoAll[i].model,
                            valuationMode: app.arrCargoInfoAll[i].valuationMode,
                            arrAmountInfo: app.arrCargoInfoAll[i].arrAmountInfo
                        }
                    }
                    taht.data.arrdata.push(datas)
                }
                console.log(this.data.arrPodType[0].key)
                if(this.data.arrPodType[0].key!="2001020"){

                    if(this.data.denyid==""){
                        if (taht.data.fileID == "") {
                            taht.pageLoading = !1;
                            wx.showToast({
                                title: "签字回单照片不能为空",
                                mask: false,
                                icon: "none",
                                duration: 2000,
                            })
                        } else {
                            var options = {
                                port: 'dispatchSigned2',
                                body: {
                                    "dispatchID": taht.data.dispatchID,
                                    "arrCargoInfo": taht.data.arrdata,
                                    "consigneeName": taht.data.name,
                                    "arrExecResult": arrExecResult,
                                    "isAgent": 'false',
                                    "signedTime": taht.data.time,
                                    "recordPhotoFileID": taht.data.fileID,
                                    "arrOtherPhotoInfo": taht.data.arrOtherPhotoInfoID
                                }
                            }
                            app.connect(options).then(values => {
                                console.log(values)
                                if (values.data.body.code == "0") {
                                    app.orderdata["index"] = taht.data.index1
                                    app.orderdata["key"] = taht.data.key
                                    app.orderdata["dispatchStatus"] = 1141030
                                    wx.showToast({
                                        title: "签收成功",
                                        mask: false,
                                        icon: "success",
                                        duration: 1500,
                                        success: () => {
                                            if(app.orderdata["route"]=="schedulingdetails"){
                                                console.log(app.orderdata["route"])
                                                app.orderdata["route"]=""
                                                wx.navigateBack({
                                                    delta: 2,
                                                })
                                            }
                                            if(app.orderdata["route"]=="list"){
                                                console.log(app.orderdata["route"])
                                                app.orderdata["route"]=""
                                                wx.navigateBack({
                                                    delta: 1,
                                                })
                                            }
                                        },
                                    })
                                }
                            })
                        }
                    }else{
                        if (taht.data.arrOtherPhotoInfoID.length == "") {
                            taht.pageLoading = !1;
                            wx.showToast({
                                title: "拒签补充照片不能为空",
                                mask: false,
                                icon: "none",
                                duration: 2000,
                            })
                        } else {
                            var options = {
                                port: 'dispatchSigned2',
                                body: {
                                    "dispatchID": taht.data.dispatchID,
                                    "arrCargoInfo": taht.data.arrdata,
                                    "consigneeName": taht.data.name,
                                    "arrExecResult": arrExecResult,
                                    "isAgent": 'false',
                                    "signedTime": taht.data.time,
                                    "arrOtherPhotoInfo": taht.data.arrOtherPhotoInfoID
                                }
                            }
                            app.connect(options).then(values => {
                                console.log(values)
                                if (values.data.body.code == "0") {
                                    app.orderdata["index"] = taht.data.index1
                                    app.orderdata["key"] = taht.data.key
                                    app.orderdata["dispatchStatus"] = 1141030
                                    wx.showToast({
                                        title: "签收成功",
                                        mask: false,
                                        icon: "success",
                                        duration: 1500,
                                        success: () => {
                                            if(app.orderdata["route"]=="schedulingdetails"){
                                                console.log(app.orderdata["route"])
                                                app.orderdata["route"]=""
                                                wx.navigateBack({
                                                    delta: 2,
                                                })
                                            }
                                            if(app.orderdata["route"]=="list"){
                                                console.log(app.orderdata["route"])
                                                app.orderdata["route"]=""
                                                wx.navigateBack({
                                                    delta: 1,
                                                })
                                            }
                                        },
                                    })
                                }
                            })
                        }

                    }


                }else{
                    var options = {
                        port: 'dispatchSigned2',
                        body: {
                            "dispatchID": taht.data.dispatchID,
                            "arrCargoInfo": taht.data.arrdata,
                            "consigneeName": taht.data.name,
                            "arrExecResult": arrExecResult,
                            "isAgent": 'false',
                            "signedTime": taht.data.time,
                            "recordPhotoFileID": null,
                            "arrOtherPhotoInfo": taht.data.arrOtherPhotoInfoID,
                            "longitude":app.orderdata["longitude"],
                            "latitude":app.orderdata["latitude"],
                        }
                    }
                    app.connect(options).then(values => {
                        console.log(values)
                        if (values.data.body.code == "0") {
                            app.orderdata["index"] = taht.data.index1
                            app.orderdata["key"] = taht.data.key
                            app.orderdata["dispatchStatus"] = 1141030
                            wx.showToast({
                                title: "签收成功",
                                mask: false,
                                icon: "success",
                                duration: 1500,
                                success: () => {

                                    if(app.orderdata["route"]=="schedulingdetails"){
                                        console.log(app.orderdata["route"])
                                        app.orderdata["route"]=""
                                        wx.navigateBack({
                                            delta: 2,
                                        })
                                    }
                                    if(app.orderdata["route"]=="list"){
                                        console.log(app.orderdata["route"])
                                        app.orderdata["route"]=""
                                        wx.navigateBack({
                                            delta: 1,
                                        })
                                    }
                                },
                            })
                        }
                    })
                }
            }
        }
    },
    ontick: function (e) {
        if (e.currentTarget.dataset.name == "delay") {
            this.data.delayid="1123010"
            this.setData({
                delay: true
            })
        } else if (e.currentTarget.dataset.name == "damaged") {
            this.data.damagedid="1123020"
            this.setData({
                damaged: true
            })
        } else if (e.currentTarget.dataset.name == "defect") {
            this.data.defectid="1123030"
            this.setData({
                defect: true
            })
        } else if (e.currentTarget.dataset.name == "deny") {
            this.data.denyid="1123040"
            this.setData({
                deny: true
            })
        } else if (e.currentTarget.dataset.name == "delay1") {
            this.data.delayid=""
            this.setData({
                delay: false
            })
        }
        else if (e.currentTarget.dataset.name == "damaged1") {
            this.data.damagedid=""
            this.setData({
                damaged: false
            })
        } else if (e.currentTarget.dataset.name == "defect1") {
            this.data.defectid=""
            this.setData({
                defect: false
            })
        } else if (e.currentTarget.dataset.name == "deny1") {
            this.data.denyid=""
            this.setData({
                deny: false
            })
        }
    },
    onnumber1: function (e) {
        console.log(e.detail.value)
        if(e.detail.value!=""){
            this.setData({
                damaged:true
             })
        }else{
            this.setData({
                damaged:false
            })

        }
    },
    onnumber2: function (e) {
        console.log(e.detail.value)
        if(e.detail.value!=""){
            this.setData({
                defect:true
            })
        }else{
            this.setData({
                defect:false
            })

        }
    },
    bindMultiPickerColumnChange: function (e) {
        for(var i=0;i<this.data.multiArray.length;i++){
            for(var j=0;j<this.data.multiArray[i].length;j++) {
                console.log(321)
                if (i==0) {
                    this.data.multiArray[i][j]=this.data.multiArray[i][j].replace("年","");
                    console.log(this.data.multiArray[i][j])
                }else if(i==1){
                    this.data.multiArray[i][j]=this.data.multiArray[i][j].replace("月",'')
                }else if(i==2){
                    this.data.multiArray[i][j]=this.data.multiArray[i][j].replace("日",'')
                }else if(i==3){
                    this.data.multiArray[i][j]=this.data.multiArray[i][j].replace("时",'')
                }else if(i==4){
                    this.data.multiArray[i][j]=this.data.multiArray[i][j].replace("分",'')
                }else if(i==5){
                    this.data.multiArray[i][j]=this.data.multiArray[i][j].replace("秒",'')
                }
            }
        }
        console.log(e.detail.column)
        console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
        var data = {
            multiArray: this.data.multiArray,
            multiIndex: this.data.multiIndex
        };
        data.multiIndex = e.detail.value;

        console.log(data)
        this.setData(data);
        this.data.deliveryDate=data.multiArray[0][data.multiIndex[0]]+"-"+data.multiArray[1][data.multiIndex[1]]+"-"+data.multiArray[2][data.multiIndex[2]]+" "+data.multiArray[3][data.multiIndex[3]]+":"+data.multiArray[4][data.multiIndex[4]]+":"+0
        this.data.deliverytime=null;
        this.setData({
            deliverytime:this.data.deliverytime
        })
    },
    chooseimage4: function (e) {
        var signins=e.currentTarget.dataset.name
        var _this = this;
        wx.chooseImage({
            count: 1, // 默认9
            sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
            sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
            success: function (res) {
                console.log(res.tempFilePaths[0])
                var tempFilePaths = res.tempFilePaths;
                console.log(tempFilePaths)
                var signin=signins
                var page=_this
                var path=tempFilePaths
                var token;
                wx.getStorage({
                    key: 'token',
                    success: function (res) {
                        token = res.data;
                        var alldata={
                            app_key: app.data.appKey,
                            timestamp:new Date().getTime(),
                            access_token:token,
                            signature:"",
                            param:"",
                            bizCode:8,
                            privateField:"",
                            fileName:""

                        }

                        /*  console.log(alldata)*/
                        wx.showToast({
                            icon: "loading",
                            title: "正在上传"
                        }),
                            wx.uploadFile({
                                url: app.data.allDomainNameUrl+'fileUpload?app_key='+app.data.appKey+"&bizCode="+7+"&privateField="+"&fileName="+"&access_token="+token,
                                filePath: path[0],
                                name: 'file',
                                formData:alldata,
                                header: {
                                    "Content-Type": "multipart/form-data"
                                },
                                success: function (res) {
                                    console.log(res)
                                    var jsondata=JSON.parse(res.data)
                                    console.log(jsondata);
                                    if (res.statusCode != 200) {
                                        wx.showModal({
                                            title: '提示',
                                            content: '上传失败',
                                            showCancel: false
                                        })
                                        return;
                                    }
                                    if(signin=="signin"){
                                        page.data.fileID=jsondata.body.content.fileID
                                        page.setData({  //上传成功修改显示头像
                                            src: jsondata.body.content.fileUrl
                                        })
                                    }else{
                                        page.data.arrOtherPhotoInfo[page.data.index-1]=jsondata.body.content.fileUrl
                                        page.data.arrOtherPhotoInfoID[page.data.index-1]={fileID:jsondata.body.content.fileID,bizType:2,otherPhotoUrl:jsondata.body.content.fileUrl,fileSeqNo:page.data.index-1}
                                        console.log(page.data.arrOtherPhotoInfo)
                                        page.setData({
                                            srcs:page.data.arrOtherPhotoInfo
                                        })
                                    }
                                    /*var data = res.data*/

                                },
                                fail: function (e) {
                                    console.log(e);
                                    wx.showModal({
                                        title: '提示',
                                        content: '上传失败',
                                        showCancel: false
                                    })
                                },
                                complete: function () {
                                    wx.hideToast();  //隐藏Toast
                                }
                            })
                    }
                });
                // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
                _this.setData({
                    tempFilePaths4: res.tempFilePaths[0]
                })
            }
        })
    },
    chooseimage: function (e) {
        this.data.index=e.currentTarget.dataset.name
        var _this = this;
        wx.chooseImage({
            count: 1, // 默认9
            sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
            sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
            success: function (res) {
                _this.data.arr[_this.data.index]=res.tempFilePaths[0]
                _this.data.index=_this.data.index+1
                _this.data.arr[_this.data.index]=""
                console.log(res.tempFilePaths[0])
                console.log(_this.data.arr)
                var tempFilePaths = res.tempFilePaths;
                console.log(tempFilePaths)
                var signin=_this.data.index
                var page=_this
                var path=tempFilePaths
              /*  upload:function (signin,page, path) {*/
                    console.log(path[0])
                    var token;
                    wx.getStorage({
                        key: 'token',
                        success: function (res) {
                            token = res.data;
                            var alldata={
                                app_key: app.data.appKey,
                                timestamp:new Date().getTime(),
                                access_token:token,
                                signature:"",
                                param:"",
                                bizCode:8,
                                privateField:"",
                                fileName:""

                            }

                            /*  console.log(alldata)*/
                            wx.showToast({
                                icon: "loading",
                                title: "正在上传"
                            }),
                                wx.uploadFile({
                                    url:app.data.allDomainNameUrl+'fileUpload?app_key='+app.data.appKey+"&bizCode="+7+"&privateField="+"&fileName="+"&access_token="+token,
                                    filePath: path[0],
                                    name: 'file',
                                    formData:alldata,
                                    header: {
                                        "Content-Type": "multipart/form-data"
                                    },
                                    success: function (res) {
                                        console.log(res)
                                        var jsondata=JSON.parse(res.data)
                                        console.log(res);
                                        if (res.statusCode != 200) {
                                            wx.showModal({
                                                title: '提示',
                                                content: '上传失败',
                                                showCancel: false
                                            })
                                            return;
                                        }
                                        if(signin=="signin"){
                                            page.data.fileID=jsondata.body.content.fileID
                                            page.setData({  //上传成功修改显示头像
                                                src: jsondata.body.content.fileUrl
                                            })
                                        }else{
                                            page.data.arrOtherPhotoInfo[page.data.index-1]=jsondata.body.content.fileUrl
                                            page.data.arrOtherPhotoInfoID[page.data.index-1]={fileID:jsondata.body.content.fileID,bizType:2,otherPhotoUrl:jsondata.body.content.fileUrl,fileSeqNo:page.data.index-1}
                                            console.log(page.data.arrOtherPhotoInfo)
                                            page.setData({
                                                srcs:page.data.arrOtherPhotoInfo
                                            })
                                        }
                                        /*var data = res.data*/

                                    },
                                    fail: function (e) {
                                        console.log(e);
                                        wx.showModal({
                                            title: '提示',
                                            content: '上传失败',
                                            showCancel: false
                                        })
                                    },
                                    complete: function () {
                                        wx.hideToast();  //隐藏Toast
                                    }
                                })
                        }
                    });

             /*   }*/
                // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
                _this.setData({
                    tempFilePaths: _this.data.arr
                })
            }
        })
    },
    ontime:function(){
        var myDate = new Date();
        var a=0;
        var b=0;
        var c=0;
        var d=0;
        var e=0;
        for(var i=89;i<parseInt(myDate.getYear());i++){
            a=a+1
        }
        for(var i=0;i<parseInt(myDate.getMonth());i++){
            b=b+1
        }
        for(var i=1;i<parseInt(myDate.getDate());i++) {
            c = c + 1
        }
        for(var i=0;i<parseInt(myDate.getHours());i++){
            d=d+1
        }
        for(var i=0;i<parseInt(myDate.getMinutes());i++){
            e=e+1
        }
        this.data. multiIndex[0]=a
        this.data. multiIndex[1]=b
        this.data. multiIndex[2]=c
        this.data. multiIndex[3]=d
        this.data. multiIndex[4]=e
        this.setData({
            multiArray:this.data.multiArray,
            multiIndex:this.data. multiIndex
        })

    },
    onShow:function () {
        var that=this;
        that.pageLoading = !1
    },

    volumeInput: function (e) {
        console.log(e.currentTarget.dataset.name)
        console.log(e.detail.value)
        this.data.datas[e.currentTarget.dataset.name].volumevalue=e.detail.value

    },
    weightInput: function (e) {
        console.log(e.currentTarget.dataset.name)
        console.log(e.detail.value)
        this.data.datas[e.currentTarget.dataset.name].weightvalue=e.detail.value

    },
    numberInput: function (e) {
        this.data.datas[e.currentTarget.dataset.name].numbervalue=e.detail.value

    },
})

