var app = getApp();
var publish = require('../../public_util/publishData');
Page({
    data: {
        volume: '',
        number: '',
        deliverytime: '',
        dispatchBatchID: '',
        arrCargoInfo: '',
        arrdata:[],
        dispatchID:'',
        arr:[''],
        dispatch_status:'',
        multiArray1: [publish.years,publish.mouths,publish.days,publish.houvers,publish.branchs],
        multiIndex1: ["", "", "","",""],
        volumeUnit:'',
        quantityUnit:'',
        index:"",
        key:"",
        datas:[],
        isConconfirm:""

    },
    /*下拉刷新*/
    onPullDownRefresh() {
        wx.stopPullDownRefresh()
    },
    /*获取上页面数据*/
    onLoad: function (e) {
console.log(app.islistdispatchBatchID)
        this.data.index=e.index
        this.data.key=e.key
        this.data.dispatch_status=e.dispatch_status
        this.data.dispatchID=e.dispatchID
        this.data.dispatchBatchID = e.dispatchBatchID
        this.data.arrCargoInfo = e.arrCargoInfo
        this.setData({
            forward:app.globalData[48],
            cargoName:e.cargoName,
            tempFilePaths: this.data.arr,
            deliverytime: e.deliverytime
        })
        var options = {
            port: 'dispatchBatchDtlQry',
            body: {
                "dispatchBatchID": app.islistdispatchBatchID,
                "graphicCode": null,
                "sessionGraphicCode": null
            }
        }
        app.connect(options).then(values => {
            console.log(values)

            if (values.data.body.content.arrDispatchAbstractInfo[0].dispatchStatusDesc == "已到场") {
                this.data.dispatch_status = 1141010;
            }
            values.data.body.content.arrDispatchAbstractInfo[0].consignorInfo.addressInfo.cityName = app.oncityNam(values.data.body.content.arrDispatchAbstractInfo[0].consignorInfo.addressInfo.cityName)
            values.data.body.content.arrDispatchAbstractInfo[0].consigneeInfo.addressInfo.cityName = app.oncityNam(values.data.body.content.arrDispatchAbstractInfo[0].consigneeInfo.addressInfo.cityName)
            for(var i=0;i<values.data.body.content.arrDispatchAbstractInfo[0].arrCargoInfo.length;i++){
                var  shuju={
                    volumevalue:"",
                    numbervalue:"",
                    weightvalue:""
                }
                if(values.data.body.content.arrDispatchAbstractInfo[0].arrCargoInfo[i].arrAmountInfo[0].volume!=0){
                    shuju.volumevalue=values.data.body.content.arrDispatchAbstractInfo[0].arrCargoInfo[i].arrAmountInfo[0].volume
                }else{
                    shuju.weightvalue=values.data.body.content.arrDispatchAbstractInfo[0].arrCargoInfo[i].arrAmountInfo[0].weight
                }
                shuju.numbervalue=values.data.body.content.arrDispatchAbstractInfo[0].arrCargoInfo[i].arrAmountInfo[0].quantity
                 this.data.datas.push(shuju)
            }
            console.log(this.data.datas)

            this.data.deliverytime = values.data.body.content.arrDispatchAbstractInfo[0].createTime
            app.arrCargoInfoAll = values.data.body.content.arrDispatchAbstractInfo[0].arrCargoInfo
            console.log(app.arrCargoInfoAll)
            console.log(this.data.volume)
            this.setData({
                shuju:values.data.body.content.arrDispatchAbstractInfo[0].arrCargoInfo,
                deliverytime: this.data.deliverytime,
            })
        })



    },
    /*相册组件*/
    chooseimage: function (e) {
        this.data.index=e.currentTarget.dataset.name
        var _this = this;
        wx.chooseImage({
            count: 1, // 默认9
            sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
            sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
            success: function (res) {
               /* console.log(res.tempFilePaths)
                console.log(res.tempFiles)*/
                _this.data.arr[_this.data.index]=res.tempFilePaths[0]
                _this.data.index=_this.data.index+1
                _this.data.arr[_this.data.index]=""
                console.log(res.tempFilePaths[0])
                console.log(_this.data.arr)
                // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
                _this.setData({
                    tempFilePaths: _this.data.arr
                })
            }
        })
    },
    /*发车*/
    onconfirm: function () {
        var that=this;
        if (!that.pageLoading) {
            that.pageLoading = !0;
            console.log(this.data.datas)
            for(var i=0;i<this.data.datas.length;i++){
                if(this.data.datas[i].volumevalue==""&&this.data.datas[i].weightvalue==""||this.data.datas[i].weightvalue=="0"){
                    this.data.isConconfirm=false
                    that.pageLoading = !1;
                    wx.showToast({
                        title: "装运量不能为空",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                    })
                }else if(this.data.datas[i].volumevalue=="0"&&this.data.datas[i].weightvalue==""||this.data.datas[i].weightvalue=="0"){
                    this.data.isConconfirm=false
                    that.pageLoading = !1;
                    wx.showToast({
                        title: "装运量不能为空",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                    })
                }else{
             this.data.isConconfirm=true
                }
            }
if(this.data.isConconfirm==true){
    for (var i = 0; i < app.arrCargoInfoAll.length; i++) {
        for (var j = 0; j < app.arrCargoInfoAll[i].arrAmountInfo.length; j++) {
            if(app.arrCargoInfoAll[i].arrAmountInfo[j].amountBizType=="6"){
                app.arrCargoInfoAll[i].arrAmountInfo[j].amountBizType = "7"
                app.arrCargoInfoAll[i].arrAmountInfo[j].volume = this.data.datas[i].volumevalue
                app.arrCargoInfoAll[i].arrAmountInfo[j].weight = this.data.datas[i].weightvalue
                app.arrCargoInfoAll[i].arrAmountInfo[j].quantity = this.data.datas[i].numbervalue
            }
        }
        console.log(app.arrCargoInfoAll[i].arrAmountInfo)
        var datas = {
            cargoID: app.arrCargoInfoAll[i].cargoID,
            cargoName: app.arrCargoInfoAll[i].cargoName,
            model: app.arrCargoInfoAll[i].model,
            valuationMode: app.arrCargoInfoAll[i].valuationMode,
            arrAmountInfo: app.arrCargoInfoAll[i].arrAmountInfo
        }
        console.log(datas)
        this.data.arrdata.push(datas)
    }
    var batchid;
    var options = {
        port: 'dispatchDeparture2',
        body: {
            "dispatchBatchID": this.data.dispatchBatchID,
            "arrDispatchExecInfo": [{dispatchID: this.data.dispatchID, arrCargoInfo: this.data.arrdata}],
            "longitude":app.orderdata["longitude"],
            "latitude":app.orderdata["latitude"],
        }
    }
    app.connect(options).then(values => {
        console.log(values)
        if (values.data.body.code == "0") {
            app.orderdata["dispatchStatus"]=""
            app.orderdata["index"]=this.data.index
            app.orderdata["key"]=this.data.key
            app.orderdata["bepresentcolor"]='#DBDBDB',
                app.orderdata["shipmentcolor"] ='#DBDBDB',
                app.orderdata["signincolor"]="#007aff"
            wx.showToast({
                title: "派车成功",
                mask: false,
                icon: "success",
                duration: 1500,
                success: () => {
                    var options = {
                        port: 'dispatchStatusUpd',
                        body: {
                            "dispatchID": app.islistdispatchBatchID,
                            "dispatchStatus": this.data.dispatch_status,
                        }
                    }
                    app.connect(options).then(values => {
                        wx.navigateBack({
                            delta: -1
                        });
                    })

                },
            })

        }
    })
}

        }
    },
    bindMultiPickerColumnChange1: function (e) {
        for(var i=0;i<this.data.multiArray1.length;i++){
            console.log(3)
            for(var j=0;j<this.data.multiArray1[i].length;j++) {
                if (i==0) {
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("年","");
                }else if(i==1){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("月",'')
                }else if(i==2){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("日",'')
                }else if(i==3){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("时",'')
                }else if(i==4){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("分",'')
                }else if(i==5){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("秒",'')
                }
            }
        }
        console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
        var data1 = {
            multiArray1: this.data.multiArray1,
            multiIndex1: this.data.multiIndex1
        };
        data1.multiIndex1 = e.detail.value;
        this.setData(data1);
        this.data.destinationDate=data1.multiArray1[0][data1.multiIndex1[0]]+"-"+data1.multiArray1[1][data1.multiIndex1[1]]+"-"+data1.multiArray1[2][data1.multiIndex1[2]]+" "+data1.multiArray1[3][data1.multiIndex1[3]]+":"+data1.multiArray1[4][data1.multiIndex1[4]]+":"+0
        this.data.deliverytime=null;
        this.setData({
            deliverytime:this.data.deliverytime
        })


    },
    ontime:function(){
        console.log(this.data. multiIndex1)
        var myDate = new Date();
        var a=0;
        var b=0;
        var c=0;
        var d=0;
        var e=0;
        for(var i=89;i<parseInt(myDate.getYear());i++){
            a=a+1
        }
        for(var i=0;i<parseInt(myDate.getMonth());i++){
            b=b+1
        }
        for(var i=1;i<parseInt(myDate.getDate());i++) {
            c = c + 1
        }
        for(var i=0;i<parseInt(myDate.getHours());i++){
            d=d+1
        }
        for(var i=0;i<parseInt(myDate.getMinutes());i++){
            e=e+1
        }
        this.data. multiIndex1[0]=a
        this.data. multiIndex1[1]=b
        this.data. multiIndex1[2]=c
        this.data. multiIndex1[3]=d
        this.data. multiIndex1[4]=e
        this.setData({
            multiArray1:this.data.multiArray1,
            multiIndex1:this.data. multiIndex1
        })

    },
    onShow:function () {
        this.pageLoading = !1
    },
    volumeInput: function (e) {
        console.log(e.currentTarget.dataset.name)
        console.log(e.detail.value)
        this.data.datas[e.currentTarget.dataset.name].volumevalue=e.detail.value

    },
    weightInput: function (e) {
        console.log(e.currentTarget.dataset.name)
        console.log(e.detail.value)
        this.data.datas[e.currentTarget.dataset.name].weightvalue=e.detail.value

    },
    numberInput: function (e) {
        this.data.datas[e.currentTarget.dataset.name].numbervalue=e.detail.value
    },
})