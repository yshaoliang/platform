var app=getApp()
Page({
    data:{
        addvehicleID:''
    },
    onLoad:function (e) {
        this.data.addvehicleID=e.vehicleID
        var vehicleID=e.vehicleID
        var options = {
            port: 'vehicleDtlQry3',
            body: {
                "vehicleID":vehicleID,
            }
        }
        app.connect(options).then(values => {
            console.log(values)
            this.setData({
                shuju:values.data.body.content.vehicleInfo
            })
        })
    },
    onPreservation:function () {
        if (!this.pageLoading) {
            this.pageLoading = !0;
            wx.navigateTo({
                url: '../../order/addingtool/addingtool?datas=' + this.data.addvehicleID
            })
        }
    },
    onShow:function () {
        this.pageLoading = !1
    }
})