var app=getApp();
Page({
    onLoad:function (e) {
        app.loads()
            this.setData({
                phone: app.globalData[16],
            })
             app.vehicleID=e.vehicleID
            var options = {
                port: 'vehicleDtlQry3',
                body: {
                    vehicleID: e.vehicleID
                }
            }
            app.connect(options).then(values => {
                wx.hideLoading()
                console.log(values)
            for(var i=0;i<values.data.body.content.vehicleInfo.arrCityInfo.length;i++){
                values.data.body.content.vehicleInfo.arrCityInfo[i].cityName=app.oncityNam(values.data.body.content.vehicleInfo.arrCityInfo[i].cityName)
             }

                this.setData({
                    shuju: values.data.body.content.vehicleInfo
                })
            })
    },
    onStatus:function(e){
            wx.navigateTo({
                url: '../authentication/authentication?vehicleID=' + e.currentTarget.dataset.name
            })
    },
    onconfirm:function (e) {
        if (!this.pageLoading) {
            this.pageLoading = !0;
            wx.navigateTo({
                url: '../../order/addingtool/addingtool?vehicleID=' + e.currentTarget.dataset.name
            })
        }
    },
    onShow:function () {
        var options = {
            port: 'vehicleDtlQry3',
            body: {
                vehicleID: app.vehicleID
            }
        }
        app.connect(options).then(values => {
            console.log(values)
            for(var i=0;i<values.data.body.content.vehicleInfo.arrCityInfo.length;i++){
                values.data.body.content.vehicleInfo.arrCityInfo[i].cityName=app.oncityNam(values.data.body.content.vehicleInfo.arrCityInfo[i].cityName)
            }

            this.setData({
                shuju: values.data.body.content.vehicleInfo
            })
        })
        this.pageLoading = !1
    },
    onphone:function (e) {
        var phoneNunmber=e.currentTarget.dataset.name
        wx.makePhoneCall({
            phoneNumber: phoneNunmber
        })
    },
    previewImage:function (e) {
        console.log(e.currentTarget.dataset.name)
        wx.previewImage({
            urls:[e.currentTarget.dataset.name]
        })
    }
})