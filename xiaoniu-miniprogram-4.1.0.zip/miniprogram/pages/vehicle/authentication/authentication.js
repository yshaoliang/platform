var app=getApp();
Page({
    data:{
        vehicleID:'',
        drivingLicensePhotoID:"",
        roadTransportBusinessLicensePhotoID:""
    },
    onLoad:function(e){
        this.data.vehicleID=e.vehicleID
        this.setData({
            doubt:app.globalData[49]
        })



    },
    chooseimage3: function (e) {
        var  drivinglicense=e.currentTarget.dataset.name
        var _this = this;
        wx.chooseImage({
            count: 1, // 默认9
            sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
            sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
            success: function (res) {
                console.log(res.tempFilePaths[0])
                var tempFilePaths = res.tempFilePaths;
                console.log(tempFilePaths)
                _this.upload(drivinglicense,_this, tempFilePaths);
                // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
                _this.setData({
                    tempFilePaths3: res.tempFilePaths[0]
                })
            }
        })
    },
    /*相册组件*/
    chooseimage4: function () {
        var _this = this;
        wx.chooseImage({
            count: 1, // 默认9
            sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
            sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
            success: function (res) {
                console.log(res.tempFilePaths[0])
                var tempFilePaths = res.tempFilePaths;
                console.log(tempFilePaths)
                _this.upload("",_this, tempFilePaths);
                // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
                _this.setData({
                    tempFilePaths4: res.tempFilePaths[0]
                })
            }
        })
    },
    onconfirm:function () {
        var that=this;
        var options = {
            port: 'vehicleDtlQry3',
            body: {
                vehicleID:this.data.vehicleID,

            }
        }
        app.connect(options).then(values => {
            console.log(values)
            if(this.data.drivingLicensePhotoID==""){
                wx.showToast({
                    title: "行驶证照片不能为空",
                    mask: false,
                    icon: "none",
                    duration: 2000,
                    success: function () {
                        that.pageLoading = !1
                    }
                })
            }else if(this.data.roadTransportBusinessLicensePhotoID==""){
                wx.showToast({
                    title: "道路运输证不能为空",
                    mask: false,
                    icon: "none",
                    duration: 2000,
                    success: function () {
                        that.pageLoading = !1
                    }
                })
            }else{
                if (values.data.body.content.vehicleInfo.carInfo2 != null) {
                    var options = {
                        port: 'vehicleCreUpd4',
                        body: {
                            vehicleID: this.data.vehicleID,
                            vehicleMode: "1071000",
                            carInfo2: {
                                vehicleCode: values.data.body.content.vehicleInfo.carInfo2.vehicleCode,
                                typeID: values.data.body.content.vehicleInfo.carInfo2.typeID,
                                lengthID: values.data.body.content.vehicleInfo.carInfo2.lengthID,
                                tonnage: values.data.body.content.vehicleInfo.carInfo2.tonnage,

                            },
                            linkmanInfo: {
                                "name": values.data.body.content.vehicleInfo.linkmanInfo.name,
                                "mobile": values.data.body.content.vehicleInfo.linkmanInfo.mobile
                            },
                            teamID:values.data.body.content.vehicleInfo.teamID,
                            arrCityInfo:values.data.body.content.vehicleInfo.arrCityInfo,
                            drivingLicenseInfo :{drivingLicensePhotoId:this.data.drivingLicensePhotoID},
                            roadTransportBusinessLicensePhotoID: this.data.roadTransportBusinessLicensePhotoID,
                        }
                    }
                    app.connect(options).then(values => {
                        console.log(values)
                        if(values.data.body.content.vehicleID!=null){
                            wx.navigateBack({
                                delta: -1
                            });
                        }
                    })
                } else {
                    var options = {
                        port: 'vehicleCreUpd4',
                        body: {
                            vehicleID: this.data.vehicleID,
                            vehicleMode: "1071010",
                            shipInfo: {
                                vehicleCode: values.data.body.content.vehicleInfo.shipInfo.vehicleCode,
                                typeID: values.data.body.content.vehicleInfo.shipInfo.typeID,
                                lengthID: values.data.body.content.vehicleInfo.shipInfo.lengthID,
                                tonnage: values.data.body.content.vehicleInfo.shipInfo.tonnage,
                            },
                            linkmanInfo: {
                                "name": values.data.body.content.vehicleInfo.linkmanInfo.name,
                                "mobile": values.data.body.content.vehicleInfo.linkmanInfo.mobile
                            },
                            teamID:values.data.body.content.vehicleInfo.teamID,
                            arrCityInfo:values.data.body.content.vehicleInfo.arrCityInfo,
                            drivingLicenseInfo :{drivingLicensePhotoId:this.data.drivingLicensePhotoID},
                            roadTransportBusinessLicensePhotoID: this.data.roadTransportBusinessLicensePhotoID
                        }
                    }
                    app.connect(options).then(values => {
                        console.log(values)
                        if(values.data.body.content.vehicleID!=null){
                            wx.showToast({
                                title: "认证成功",
                                mask: false,
                                icon: "success",
                                duration: 3000,
                                success: function () {
                                    wx.navigateBack({
                                        delta: -1
                                    });
                                    that.pageLoading = !1
                                }
                            })
                        }
                    })
                }
            }

        })
    },
    upload:function (drivinglicense,page, path) {
        console.log(path[0])
        var token;
        wx.getStorage({
            key: 'token',
            success: function (res) {
                token = res.data;
            }
        });
        var alldata={
            app_key:app.data.appKey,
            timestamp:new Date().getTime(),
            access_token:token,
            signature:"",
            /* /!* sign: datas.sign,*!/
             /!* version:datas.version,*!/
             /!* secretKey:datas.secretKey,*/
            param:"",
            bizCode:8,
            privateField:"",
            fileName:""

        }

        wx.showToast({
            icon: "loading",
            title: "正在上传"
        }),
            wx.uploadFile({
                url: app.data.allDomainNameUrl+'fileUpload?app_key='+app.data.appKey+"&bizCode="+8+"&privateField="+"&fileName="+"&access_token="+token,
                filePath: path[0],
                name: 'file',
                formData:alldata,
                header: {
                    "Content-Type": "multipart/form-data"
                },
                success: function (res) {
                    var jsondata=JSON.parse(res.data)
                    console.log(res);
                    if (res.statusCode != 200) {
                        wx.showModal({
                            title: '提示',
                            content: '上传失败',
                            showCancel: false
                        })
                        return;
                    }
                    if(drivinglicense=="drivinglicense"){
                        page.data.drivingLicensePhotoID=jsondata.body.content.fileID
                        page.setData({
                            drivingLicensePhotoUrl:jsondata.body.content.fileUrl
                        })
                    }else{
                        page.data.roadTransportBusinessLicensePhotoID=jsondata.body.content.fileID
                        page.setData({
                            roadTransportBusinessLicensePhotoUrl:jsondata.body.content.fileUrl
                        })
                    }
                    page.setData({  //上传成功修改显示头像
                        src: jsondata.body.content.fileUrl
                    })
                },
                fail: function (e) {
                    console.log(e);
                    wx.showModal({
                        title: '提示',
                        content: '上传失败',
                        showCancel: false
                    })
                },
                complete: function () {
                    wx.hideToast();  //隐藏Toast
                }
            })
    }

})