var app=getApp();
Page({
    data:{
        index:0,
        alldata:[],
        alldatas1:[],
        searchValue:null
    },
    /*下拉刷新*/
    onPullDownRefresh() {

        this.data.index=0
        this.data.alldata.splice(0, this.data.alldata.length);
        this.onShow().then(values => {
            wx.stopPullDownRefresh()
        })
    },
    nextstep: function () {
        var that=this;
        app.selection=""
        app.driverName=""
        app.shipName=""
        app.carmoderlName=""
        app.lengthValue=""
            app.navigationarea=""
        if (!that.pageLoading) {
            that.pageLoading = !0;
            wx.navigateTo({
                url: '../../order/addingtool/addingtool'
            })
        }
    },
    onReachBottom: function () {
        app.loads()
        console.log(this.data.alldata[0])
        this.data.index=this.data.index+1
        var options = {
            port: 'vehicleListQry3',
            body: {
                vehicleCode:this.data.searchValue,
                isMyVehicle: true,
                "pageIndex": this.data.index,
                "pageSize": 10,
            }
        }
        app.connect(options).then(values => {
            console.log(values)
            wx.hideLoading()
            for(var i=0;i<values.data.body.content.arrVehicleAbstractInfo.length;i++){
                if(values.data.body.content.arrVehicleAbstractInfo[i].arrCityInfo.length!="0") {
                    values.data.body.content.arrVehicleAbstractInfo[i].arrCityInfo[0].cityName = app.oncityNam(values.data.body.content.arrVehicleAbstractInfo[i].arrCityInfo[0].cityName)
                }
            }
            for(var i=0;i<values.data.body.content.arrVehicleAbstractInfo.length;i++){
                this.data.alldata[0].push(values.data.body.content.arrVehicleAbstractInfo[i])
            }
            console.log(this.data.alldata[0])
            this.setData({
                shuju: this.data.alldata[0]
            })
        })
    },
    onLoad: function () {
        /*app.loads()
        this.setData({
            carimage:app.globalData[22],
            shipimage:app.globalData[23],
        })
        var that = this;
        var options = {
            port: 'vehicleListQry3',
            body: {
                isMyVehicle: true,
                "pageIndex": this.data.index,
                "pageSize": 10,
                "graphicCode": null,
                "sessionGraphicCode": null
            }
        }
        let prom1 = new Promise(function (resolve, reject) {
            app.connect(options).then(values => {
                wx.hideLoading()
              console.log(values)
                that.data.alldata.push(values.data.body.content.arrVehicleAbstractInfo)
                for(var i=0;i<values.data.body.content.arrVehicleAbstractInfo.length;i++){
                    if(values.data.body.content.arrVehicleAbstractInfo[i].arrCityInfo.length!="0"){
                        values.data.body.content.arrVehicleAbstractInfo[i].arrCityInfo[0].cityName=app.oncityNam(values.data.body.content.arrVehicleAbstractInfo[i].arrCityInfo[0].cityName)

                    }
                }
                console.log(values.data.body.content.arrVehicleAbstractInfo)
                that.setData({
                    shuju: values.data.body.content.arrVehicleAbstractInfo
                })
                resolve(values)
            })
        });
        return prom1;*/

    },
    oncarrierList: function (e) {
        if (!this.pageLoading) {
            this.pageLoading = !0;
            wx.navigateTo({
                url: '../vehicledetails/vehicledetails?vehicleID=' + e.currentTarget.dataset.id
            })
        }

    },
    onShow:function () {
        this.data.index=0;
        this.pageLoading = !1;
        app.loads()
        this.setData({
            carimage:app.globalData[22],
            shipimage:app.globalData[23],
        })
        var that = this;
        that.data.searchValue=null;
        var options = {
            port: 'vehicleListQry3',
            body: {
                isMyVehicle: true,
                "pageIndex": this.data.index,
                "pageSize": 10,
                "graphicCode": null,
                "sessionGraphicCode": null
            }
        }
        let prom1 = new Promise(function (resolve, reject) {
            app.connect(options).then(values => {
                wx.hideLoading()
                console.log(values)
                that.data.alldata.push(values.data.body.content.arrVehicleAbstractInfo)
                for(var i=0;i<values.data.body.content.arrVehicleAbstractInfo.length;i++){
                    if(values.data.body.content.arrVehicleAbstractInfo[i].arrCityInfo.length!="0"){
                        values.data.body.content.arrVehicleAbstractInfo[i].arrCityInfo[0].cityName=app.oncityNam(values.data.body.content.arrVehicleAbstractInfo[i].arrCityInfo[0].cityName)

                    }
                }
                console.log(values.data.body.content.arrVehicleAbstractInfo)
                that.setData({
                    shuju: values.data.body.content.arrVehicleAbstractInfo
                })
                resolve(values)
            })
        });
        return prom1;
    },
    searchBtn: function (e) {
        app.loads()
        this.data.index=0;
        console.log(e.detail.value)
        var that = this;
        that.data.searchValue=e.detail.value;
        var options = {
            port: 'vehicleListQry3',
            body: {
                 vehicleCode: e.detail.value,
                 isMyVehicle: true,
                "pageIndex": this.data.index,
                "pageSize": 10,
                "graphicCode": null,
                "sessionGraphicCode": null
            }
        }
        app.connect(options).then(values => {
            wx.hideLoading()
            console.log(values)
            this.data.alldata.splice(0,this.data.alldata.length);
            that.data.alldata.push(values.data.body.content.arrVehicleAbstractInfo)
            console.log(this.data.alldata[0])
            for(var i=0;i<values.data.body.content.arrVehicleAbstractInfo.length;i++){
                if(values.data.body.content.arrVehicleAbstractInfo[i].arrCityInfo.length!="0"){
                    values.data.body.content.arrVehicleAbstractInfo[i].arrCityInfo[0].cityName=app.oncityNam(values.data.body.content.arrVehicleAbstractInfo[i].arrCityInfo[0].cityName)
                }
            }
            console.log(values.data.body.content.arrVehicleAbstractInfo)
            that.setData({
                shuju: values.data.body.content.arrVehicleAbstractInfo
            })
        })

    },

})