/**
 * @author chenyang_yuan
 * @version 1.0
 * Created by chenyang_yuan on 2018/10/14.
 * content：登录界面
 */
var app = getApp();
Page({
    data: {
        imgRd46 : app.globalData[46],
        uName:'',
        openid:'',
        token:'',
        userName:'',
        userPass:''
    },
    onShow:function(){
        this.pageLoading = !1
    },
    onLoad:function () {
        //获取存储在userName
        var value = wx.getStorageSync('uName');
        this.data.userName=value
        this.setData({
            uName:value,
        });
        //存储手机相关message
        app.globalData.phoneMessage = wx.getSystemInfoSync();
        var hige= app.globalData.phoneMessage.screenHeight;
        if (hige > 818){
            this.setData({
                mesTap:'mag390',
            })
        }else if(738 < hige && hige < 818){
            this.setData({
                mesTap:'mag388',
            })
        }else if(664 < hige && hige < 737){
            this.setData({
                mesTap:'mag148',
            })
        }else  if(564 < hige && hige<665){
            this.setData({
                mesTap:'mag98',
            })
        }

    },
    formSubmit: function (event) {
        console.log(event.detail.formId)
        /*app.orderdata["formId"]=app.orderdata["formId"]+","+event.detail.formId*/
       /* wx.getUserInfo({
            success:function (res) {
               console.log(res)
            },
            fail:function () {
                console.log(123)
            }
        })*/

        var that=this;
        if (!that.pageLoading) {
            that.pageLoading = !0;
             app.loads()
            wx.getLocation({
                type: 'wgs84',
                success: function(res) {
                    var latitude = res.latitude
                    var longitude = res.longitude
                    var speed = res.speed
                    var accuracy = res.accuracy
                    app.orderdata["latitude"]=latitude
                    app.orderdata["longitude"]=longitude
                    app.orderdata["speed"]=speed
                    app.orderdata["accuracy"]=accuracy
                }
            })
            wx.removeStorage({
                key: "token",
            });
            var options = {
                port: 'login',
                body: {
                    "mobile": that.data.userName,
                    "password": that.data.userPass,
                    "graphicCode": null,
                    "sessionGraphicCode": null
                }
            };
            app.connect(options).then(values => {
                console.log(values)
                console.log(app.globalData);
                /*app.orderdata["formId"] = app.orderdata["formId"].substr(1);*/
                values.data.body.code >= 0 ?
                    wx.showToast({
                        title: "登录成功",
                        mask: false,
                        icon: "success",
                        duration: 6000,
                        success: () => {

                            wx.hideLoading()
                            wx.login({
                                success:function (res) {
                                    console.log(res)



                                    /*var options = {
                                        port: 'wxOpenIDBind',
                                        body: {
                                            "wxCode": res.code,
                                            "formId": app.orderdata["formId"],
                                            "graphicCode": null,
                                            "sessionGraphicCode": null
                                        }
                                    };
                                    app.connect(options).then(values => {
                                        console.log(values)
                                        console.log(123456)
                                    })*/

                                },
                                fail:function () {
                                    console.log(123)
                                }
                            })
                            console.log(values.data.header.token)
                            app.access_token=values.data.header.token
                            wx.setStorageSync('token', values.data.header.token);
                            
                            //手机号码
                            wx.setStorageSync('uName', that.data.userName);
                            //密码
                            /*  wx.setStorageSync('uPass', event.detail.value.userPass);*/

                            //存储当前用户的详情
                            app.globalData.userDe = values.data.body.content;


                            wx.redirectTo({
                                url: '../../pages/workbench/workbench',
                            });
                        },
                    })
                    :
                    wx.showModal({
                        title: "账户密码错误！",
                        content: "请重新输入",
                        showCancel: false,
                        duration: 3000,
                        success:function(){
                            that.pageLoading = !1
                            wx.hideLoading()

                        },
                    });

                app.globalData.companyType = values.data.body.content.userInfo.companyInfo.companyType;
                console.log(app.globalData.companyType)
                /*判断不同的公司用户显示不同的角色，根据不同的角色显示不同的页面*/
                switch (values.data.body.content.userInfo.companyInfo.companyType){
                    case 2541010:{
                        app.globalData.shfTt = true;
                        app.globalData.shfFt = false;
                    }
                        break;
                    case 2541020:{
                        app.globalData.shfTt = false;
                        app.globalData.shfFt = true;
                    }
                        break;
                    case 2541030:{
                        app.orderdata["driver"]=true;
                        app.globalData.shfTt = false;
                        app.globalData.shfFt = true;
                    }
                        break;
                }

            });
       }
    },

    skip:function () {
        wx.navigateTo({
            url:"/pages/user_center/reset_pass/reset_pass",
        })

    },
    numberInput:function (e) {
        this.data.userName=e.detail.value

    },
    passwordInput:function (e) {
        this.data.userPass=e.detail.value

    }

});