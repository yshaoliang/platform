const app = getApp()
var template = require('../public_util/publishData.js');
Page({
    data: {
        imgRd28:app.globalData[28],
        imgRd29:app.globalData[29],
        imgRd30:app.globalData[30],
        imgRd31:app.globalData[31],
        imgRd32:app.globalData[32],
        imgRd33:app.globalData[33],
        imgRd63:app.globalData[63],
        bindData:'',

    },
    onLoad: function () {

        this.setData({
            bindData: template.tabbars,
            thisSel:1,
        });
      console.log(app.data.appName)
        if(app.data.appName=="顺利运"||app.data.appName=="昆仑云通"){
            var option = {
                port:'accountQry',
            };
            app.connect(option).then(value =>{
                console.log(value)
                if(value.data.body.content.openAcount==false){
                    wx.navigateTo({
                        url: '../order/capital/capital?src=' + app.data.allDomainNameUrl+'appApi/huaXiaBank/account',
                    });
                }
            });
        }

      /*  /!*用户详情,区别*!/
       var options = {
            port: 'userDtlQry',
            body: {userID:app.globalData.userDe.userInfo.userID}
        };
        app.connect(options).then(values => {
            console.log(values)
            console.log(app.globalData);
            app.globalData.companyType = values.data.body.content.userInfo.companyInfo.companyType;
            /!*!/!判断不同的公司用户显示不同的角色，根据不同的角色显示不同的页面!/!*!/
            switch (values.data.body.content.userInfo.companyInfo.companyType){
                case 2541010:{
                    app.globalData.shfTt = true;
                    app.globalData.shfFt = false;
                }
                    break;
                case 2541020:{
                    app.globalData.shfTt = false;
                    app.globalData.shfFt = true;
                }
                    break;
                case 2541030:{
                    app.orderdata["driver"]=true;
                    app.globalData.shfTt = false;
                    app.globalData.shfFt = true;
                }
                    break;
            }
        });*/
        /*当前用户的角色所拥有的权限*/
           var option = {
               port:'getAllFuncCodeByCurrUser',
           };
          app.connect(option).then(value =>{
              console.log(value.data.body.content)
               app.globalData.getAllFuncCodeByCurrUser = value.data.body.content;
           });
    },

    /*工作态跳转*/
    workDtl:function (event) {
        var that=this;

            switch (event.target.dataset.id) {
                case '1':
                    if (!that.pageLoading) {
                        that.pageLoading = !0;
                        wx.navigateTo({
                            url: '../supplygoods/supplyofgoods/supplyofgoods',
                        });
                    }
                    break;
                case '2':
                    if (!that.pageLoading) {
                        that.pageLoading = !0;
                        wx.navigateTo({
                            url: '../order/orderlist/orderlist',
                        });
                    }
                    break;
                case '3':
                    if (!that.pageLoading) {
                        app.orderdata["orderID"]=null
                        that.pageLoading = !0;
                        app.orderdata["dispatchStatusCode"]="";
                        wx.navigateTo({
                            url: '../dispatchlist/list/list',
                        });
                    }
                    break;
                case '4':

                    if (!that.pageLoading) {
                        that.pageLoading = !0;
                        app.orderdata["type"]="speed";
                        wx.navigateTo({

                            url: '../order/orderlist/orderlist',
                        });
                    }
                    break;
                case '5':
                    if (!that.pageLoading) {
                        that.pageLoading = !0;
                        wx.navigateTo({
                            url: '../vehicle/vehiclelist/vehiclelist',
                        });
                    }
                    break;
                case '6':
                    if (!that.pageLoading) {
                        that.pageLoading = !0;
                        wx.navigateTo({
                            url: '../driver/driverlist/driverlist',
                        });
                    }
              case '7':
                if (!that.pageLoading) {
                  that.pageLoading = !0;
                  var that = this;
                  wx.scanCode({
                    success: (res) => {
                      console.log(res)
                      /*res.result this.data.params*/
                      if (res.result.indexOf("route/batch?type=app") != "-1") {
                        app.orderdata["dispatchStatusCode"] = "1141010";
                        wx.navigateTo({
                          url: '../dispatchlist/list/list',
                        })
                      } else {
                        wx.navigateTo({
                          url: '../order/test/test?src=' + res.result,
                        })
                      }
                    }
                  })
                }
            }
    },
    onShow:function () {
        app.orderdata["type"]="";
        if(app.orderdata["jumppath"]==true){
            wx.navigateTo({
                url: '../dispatchlist/list/list',
                success:function () {
                    app.orderdata["jumppath"]=false
                }
            });
        }
        this.pageLoading = !1
    }
})


