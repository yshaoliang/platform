var app = getApp();
Page({
  data: {
    datas: '',
    isColor: '',
    arrCargoInfo: [],
    number: 0,
    quality: 0,
    size: 0,
    company: "",
    company1: "",
    cargoindex:"",
    amountStowage:""
  },
  onPullDownRefresh() {
    wx.stopPullDownRefresh()
  },
  onShow: function() {
    this.pageLoading = !1
    app.newschedulingindex = undefined
    app.newschedulingindex1 = undefined
    app.vehiclemodel = "选择载具"
    app.vehiclepropertye = ""
    app.driverName = "选择司机"
    app.drivermobile = ""
    if(""!=this.data.cargoindex){
      if (getCurrentPages().length != 0) {
        for (var i = 0; i < this.data.goodsshuju[0].arrCargoInfo[parseInt(this.data.cargoindex)].arrAmountInfo.length; i++) {
          if (6 == this.data.goodsshuju[0].arrCargoInfo[parseInt(this.data.cargoindex)].arrAmountInfo[i].amountBizType) {
            this.data.goodsshuju[0].arrCargoInfo[parseInt(this.data.cargoindex)].arrAmountInfo[i] = this.data.amountStowage
            this.setData({
              goodsshuju: this.data.goodsshuju,
              datas: this.data.goodsshuju
            })
          }
        }
      }
    }
  },
  onLoad: function(e) {
    app.loads()
    var that = this;
    that.setData({
      c: '#C1EAFE',
      to: app.globalData[14],
      unSelected: app.globalData[20],
      unSelected1: app.globalData[47],
      shuju: app.shuju
    })
    var options = {
      port: 'dispatchCargoListQry2',
      body: {
        orderCode: e.orderCode
      }
    }
    app.connect(options).then(values => {
      wx.hideLoading()
      console.log(values)
      //去重和增加配载量
      if (null != values.data.body.content.arrDispatchCargoInfo) {
        for (var i = 0; i < values.data.body.content.arrDispatchCargoInfo.length; i++) {
          if (null != values.data.body.content.arrDispatchCargoInfo[i].arrCargoInfo) {
            for (var j = 0; j < values.data.body.content.arrDispatchCargoInfo[i].arrCargoInfo.length; j++) {
              var obj = {};
              values.data.body.content.arrDispatchCargoInfo[i].arrCargoInfo[j].arrAmountInfo = values.data.body.content.arrDispatchCargoInfo[i].arrCargoInfo[j].arrAmountInfo.reduce(function(item, next) {
                obj[next.amountBizType] ? '' : obj[next.amountBizType] = true && item.push(next);
                return item;
              }, []);
            }
          }
        }
      }
      //新增带配载量
      if (null != values.data.body.content.arrDispatchCargoInfo) {
        for (var i = 0; i < values.data.body.content.arrDispatchCargoInfo.length; i++) {
          if (null != values.data.body.content.arrDispatchCargoInfo[i].arrCargoInfo) {
            for (var j = 0; j < values.data.body.content.arrDispatchCargoInfo[i].arrCargoInfo.length; j++) {
              for (var z = 0; z < values.data.body.content.arrDispatchCargoInfo[i].arrCargoInfo[j].arrAmountInfo.length; z++) {
                if (values.data.body.content.arrDispatchCargoInfo[i].arrCargoInfo[j].arrAmountInfo[z].amountBizType == 5) {
                  var newAmountInfo ={};
                  newAmountInfo = values.data.body.content.arrDispatchCargoInfo[i].arrCargoInfo[j].arrAmountInfo[z];
                  values.data.body.content.arrDispatchCargoInfo[i].arrCargoInfo[j].arrAmountInfo.push(app.copyObj(newAmountInfo));
                  values.data.body.content.arrDispatchCargoInfo[i].arrCargoInfo[j].arrAmountInfo[z].amountBizType="6";
                  break;
                }
              }
            }
          }
        }
      }
      for (var i = 0; i < values.data.body.content.arrDispatchCargoInfo.length; i++) {
        values.data.body.content.arrDispatchCargoInfo[i].consignorInfo.addressInfo.cityShortName = app.oncityNam(values.data.body.content.arrDispatchCargoInfo[i].consignorInfo.addressInfo.cityShortName)
        values.data.body.content.arrDispatchCargoInfo[i].consigneeInfo.addressInfo.cityShortName = app.oncityNam(values.data.body.content.arrDispatchCargoInfo[i].consigneeInfo.addressInfo.cityShortName)
      }
      this.data.datas = values.data.body.content.arrDispatchCargoInfo
      this.data.datas.push([])
      for (var i = 0; i < this.data.datas[0].arrCargoInfo.length; i++) {
        this.data.datas[1].push({
          "color": "#FCFCFC"
        })
        for (var j = 0; j < this.data.datas[0].arrCargoInfo[i].arrAmountInfo.length; j++) {
          if (this.data.datas[0].arrCargoInfo[i].arrAmountInfo[j].volume != 0) {
            if (this.data.company == "") {
              this.data.company = this.data.datas[0].arrCargoInfo[i].arrAmountInfo[j].volumeUnit
            } else {
              if (this.data.company != this.data.datas[0].arrCargoInfo[i].arrAmountInfo[j].volumeUnit) {
                this.data.company = "单位"
              }
            }
          }
          if (this.data.datas[0].arrCargoInfo[i].arrAmountInfo[j].weight != 0) {
            if (this.data.company == "") {
              this.data.company = this.data.datas[0].arrCargoInfo[i].arrAmountInfo[j].weightUnit
            } else {
              if (this.data.company != this.data.datas[0].arrCargoInfo[i].arrAmountInfo[j].weightUnit) {
                this.data.company = "单位"
              }
            }
          }
          if (this.data.company1 == "") {
            this.data.company1 = this.data.datas[0].arrCargoInfo[i].arrAmountInfo[j].quantityUnit
          } else {
            if (this.data.company1 != this.data.datas[0].arrCargoInfo[i].arrAmountInfo[j].quantityUnit) {
              this.data.company1 = "单位"
            }
          }
        }

      }
      console.log(this.data.datas)
      this.setData({
        company: this.data.company,
        company1: this.data.company1,
        goodsshuju: this.data.datas
      })
    })
  },
  nextstep: function(e) {
    this.data.arrCargoInfo.splice(0, this.data.arrCargoInfo.length);
    console.log(this.data.datas)
    if (this.data.datas == "") {
      wx.showToast({
        title: "请选择要配载的货物！",
        mask: false,
        icon: "none",
        duration: 2000,
      })
    } else {
      for (var i = 0; i < this.data.datas[1].length; i++) {
        if (this.data.datas[1][i].color == "#C1EAFE") {
          this.data.arrCargoInfo.push(this.data.datas[0].arrCargoInfo[i])
          this.data.isColor = true
        }
      }
      app.orderdata["arrCargoInfo1"] = this.data.arrCargoInfo
      console.log(this.data.arrCargoInfo)
      if (this.data.isColor != true) {
        wx.showToast({
          title: "请选择要配载的货物！",
          mask: false,
          icon: "none",
          duration: 2000,
        })
      } else {
        var volume;
        var quantity;
        for (var i = 0; i < this.data.datas[0].arrCargoInfo[0].arrAmountInfo.length; i++) {
          if (this.data.datas[0].arrCargoInfo[0].arrAmountInfo[i].amountBizType == "5") {
            console.log(987)
            if (this.data.datas[0].arrCargoInfo[0].arrAmountInfo[i].volume != "0" && this.data.datas[0].arrCargoInfo[0].arrAmountInfo[i].volumeUnit != null) {
              volume = this.data.datas[0].arrCargoInfo[0].arrAmountInfo[i].volume + this.data.datas[0].arrCargoInfo[0].arrAmountInfo[i].volumeUnit
            } else if (this.data.datas[0].arrCargoInfo[0].arrAmountInfo[i].volume != "0" && this.data.datas[0].arrCargoInfo[0].arrAmountInfo[i].volumeUnit == null) {
              volume = this.data.datas[0].arrCargoInfo[0].arrAmountInfo[i].volume
            } else if (this.data.datas[0].arrCargoInfo[0].arrAmountInfo[i].volume == "0" && this.data.datas[0].arrCargoInfo[0].arrAmountInfo[i].weightUnit != null) {
              volume = this.data.datas[0].arrCargoInfo[0].arrAmountInfo[i].weight + this.data.datas[0].arrCargoInfo[0].arrAmountInfo[i].weightUnit
            } else if (this.data.datas[0].arrCargoInfo[0].arrAmountInfo[i].volume == "0" && this.data.datas[0].arrCargoInfo[0].arrAmountInfo[i].weightUnit == null) {
              volume = this.data.datas[0].arrCargoInfo[0].arrAmountInfo[i].weight
            }
            if (this.data.datas[0].arrCargoInfo[0].arrAmountInfo[i].quantityUnit != null) {
              quantity = this.data.datas[0].arrCargoInfo[0].arrAmountInfo[i].quantity + this.data.datas[0].arrCargoInfo[0].arrAmountInfo[i].quantityUnit
            } else {
              quantity = this.data.datas[0].arrCargoInfo[0].arrAmountInfo[i].quantity
            }
          }
        }
        console.log(volume)
        console.log(quantity)
        if (!this.pageLoading) {
          this.pageLoading = !0;
          this.data.isColor = false
          wx.navigateTo({
            url: '../newscheduling/newscheduling?volume=' + volume + "&quantity=" + quantity +
              "&size=" + this.data.size + "&number1=" + this.data.number + "&quality1=" + this.data.quality + "&company=" + this.data.company + "&company1=" + this.data.company1,
          })
        }
      }
    }

  },
  stowageGoods: function (e) {
    var cargoinfo = JSON.stringify(e.currentTarget.dataset.text)
    var cargoinfoIndex = e.currentTarget.dataset.name
    wx.navigateTo({
      url: '../stowagegood/stowagegood?cargoinfo=' + cargoinfo + '&cargoinfoIndex=' + cargoinfoIndex ,
    })
  },
  ongoods: function(e) {
    var that = this;
    if (that.data.datas[1][e.currentTarget.dataset.name].color == "#C1EAFE") {
      that.data.company = ""
      that.data.company1 = ""
      console.log(that.data.datas[0].arrCargoInfo)
      that.data.datas[1][e.currentTarget.dataset.name].color = "#FCFCFC"
      for (var i = 0; i < that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo.length; i++) {
        if (that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].amountBizType == 6) {
          if (that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].volume != 0) {
            if (that.data.company == "") {
              that.data.company = that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].volumeUnit
            } else {
              if (that.data.company != that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].volumeUnit) {
                that.data.company = "单位"
              }
            }
            that.data.quality = Number(that.data.quality) - Number(that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].volume)

          } else {
            if (that.data.company == "") {
              that.data.company = that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].weightUnit
            } else {
              if (that.data.company != that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].weightUnit) {
                that.data.company = "单位"
              }
            }
            that.data.quality = Number(that.data.quality) - Number(that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].weight)

          }
          if (that.data.company1 == "") {
            that.data.company1 = that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].quantityUnit
          } else {
            if (that.data.company1 != that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].quantityUnit) {
              that.data.company1 = "单位"
            }
          }

          that.data.number = Number(that.data.number) - Number(that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].quantity)

        }
      }
      that.data.size = that.data.size - 1
    } else {
      that.data.company = ""
      that.data.company1 = ""
      for (var i = 0; i < that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo.length; i++) {
        console.log(that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name])
        console.log(that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].amountBizType)
        if (that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].amountBizType == 6) {
          if (that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].volume != 0) {
            if (that.data.company == "") {
              that.data.company = that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].volumeUnit
            } else {
              if (that.data.company != that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].volumeUnit) {
                that.data.company = "单位"
              }
            }
            that.data.quality = Number(that.data.quality) + Number(that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].volume)

          } else {
            if (that.data.company == "") {
              that.data.company = that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].weightUnit
            } else {
              if (that.data.company != that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].weightUnit) {
                that.data.company = "单位"
              }
            }
            that.data.quality = Number(that.data.quality) + Number(that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].weight)

          }
          if (that.data.company1 == "") {
            that.data.company1 = that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].quantityUnit
          } else {
            if (that.data.company1 != that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].quantityUnit) {
              that.data.company1 = "单位"
            }
          }
          that.data.number = Number(that.data.number) + Number(that.data.datas[0].arrCargoInfo[e.currentTarget.dataset.name].arrAmountInfo[i].quantity)

        }
      }
      this.data.datas[1][e.currentTarget.dataset.name].color = "#C1EAFE"
      that.data.size = that.data.size + 1
    }
    console.log(that.data.number)
    this.setData({
      company: that.data.company,
      company1: that.data.company1,
      size: that.data.size,
      number: that.data.number,
      quality: that.data.quality,
      goodsshuju: that.data.datas
    })
  }

  
})