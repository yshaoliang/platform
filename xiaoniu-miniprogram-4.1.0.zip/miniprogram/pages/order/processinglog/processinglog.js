var app = getApp();
Page({
    data: {
        datas: [],
        size: 0,
        type: '',
        orderID: '',
        userSimpleInfo: '',
        content: '',
        dispatchID: '',
        arrfileID:[],
        arrOtherPhoto:[]
    },
    onLoad: function (e) {
        console.log(app.globalData)
    console.log(app.globalData.userDe.portraitPhotoUrl)
        this.data.orderID = e.orderID
        this.data.dispatchID = e.dispatchID
        this.data.userSimpleInfo = e.userSimpleInfo
        this.data.type = e.type
        this.setData({
            portraitPhotoUrl:app.globalData.userDe.userInfo.portraitPhotoUrl,
            headurl: app.globalData[13],
            addlog: app.globalData[19],
        })
        if (this.data.type == 1) {
            var options = {
                port: 'otherLogQry',
                body: {
                    "businessId": this.data.orderID,
                    "bizType": "1133000",
                }
            }
            app.connect(options).then(values => {
                console.log(values)
                this.setData({
                    arrOtherLogInfo: values.data.body.content.arrOtherLogInfo
                })
            })

        } else if (this.data.type == 2) {
            var options = {
                port: 'otherLogQry',
                body: {
                    "businessId": this.data.dispatchID,
                    "bizType": "1133020",
                }
            }
            app.connect(options).then(values => {
                console.log(values)
                this.setData({
                    arrOtherLogInfo: values.data.body.content.arrOtherLogInfo
                })
            })

        }
    },
    onShow: function () {
        var _this = this;
        if (_this.data.size == 2) {
            _this.setData({
                boolean: "false"
            })
        }
        _this.setData({
            datas1: _this.data.datas
        })
    },
    chooseimage4: function () {
        if (this.data.size == 0) {
            var _this = this;
            wx.chooseImage({
                count: 3, // 默认9
                sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
                sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
                success: function (res) {
                    _this.data.size = res.tempFilePaths.length
                    if (res.tempFilePaths.length == 3) {
                        _this.setData({
                            boolean: "false"
                        })
                    }
                    // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
                    for (var i = 0; i < res.tempFilePaths.length; i++) {

                        if(i==0){
                            var page=_this
                            var Identification="zero"
                            var path=res.tempFilePaths[i]
                            wx.getStorage({
                                key: 'token',
                                success: function (res) {
                                    var token=res.data
                                    var alldata={
                                        app_key:app.data.appKey,
                                        timestamp:new Date().getTime(),
                                        access_token:token,
                                        signature:"",
                                        param:"",
                                        bizCode:8,
                                        privateField:"",
                                        fileName:""

                                    }
                                    wx.showToast({
                                        icon: "loading",
                                        title: "正在上传"
                                    }),
                                        wx.uploadFile({
                                            url: app.data.allDomainNameUrl+'fileUpload?app_key='+app.data.appKey+"&bizCode="+8+"&privateField="+"&fileName="+"&access_token="+token,
                                            filePath: path,
                                            name: 'file',
                                            formData:alldata,
                                            header: {
                                                "Content-Type": "multipart/form-data"
                                            },
                                            success: function (res) {
                                                console.log(res)
                                                var jsondata=JSON.parse(res.data)
                                                console.log(res);
                                                if (res.statusCode != 200) {
                                                    wx.showModal({
                                                        title: '提示',
                                                        content: '上传失败',
                                                        showCancel: false
                                                    })
                                                    return;
                                                }

                                                if(Identification=="zero"){
                                                    page.data.arrfileID.push(jsondata.body.content.fileID)
                                                    page.data.datas.push(jsondata.body.content.fileUrl)
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="one"){
                                                    page.data.arrfileID.push(jsondata.body.content.fileID)
                                                    page.data.datas.push(jsondata.body.content.fileUrl)
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="two"){
                                                    page.data.arrfileID.push(jsondata.body.content.fileID)
                                                    page.data.datas.push(jsondata.body.content.fileUrl)
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="modifyzero"){
                                                    page.data.arrfileID[0]=jsondata.body.content.fileID
                                                    page.data.datas[0]=jsondata.body.content.fileUrl
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="modifyone"){
                                                    page.data.arrfileID[1]=jsondata.body.content.fileID
                                                    page.data.datas[1]=jsondata.body.content.fileUrl
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="modifytwo"){
                                                    page.data.arrfileID[2]=jsondata.body.content.fileID
                                                    page.data.datas[2]=jsondata.body.content.fileUrl
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }
                                            },
                                            fail: function (e) {
                                                console.log(e);
                                                wx.showModal({
                                                    title: '提示',
                                                    content: '上传失败',
                                                    showCancel: false
                                                })
                                            },
                                            complete: function () {
                                                wx.hideToast();  //隐藏Toast
                                            }
                                        })
                                }
                            });


                        }else if(i==1){
                            var page=_this
                            var Identification="one"
                            var path=res.tempFilePaths[i]
                            wx.getStorage({
                                key: 'token',
                                success: function (res) {
                                    var token=res.data
                                    var alldata={
                                        app_key:app.data.appKey,
                                        timestamp:new Date().getTime(),
                                        access_token:token,
                                        signature:"",
                                        param:"",
                                        bizCode:8,
                                        privateField:"",
                                        fileName:""

                                    }
                                    wx.showToast({
                                        icon: "loading",
                                        title: "正在上传"
                                    }),
                                        wx.uploadFile({
                                            url: app.data.allDomainNameUrl+'fileUpload?app_key='+app.data.appKey+"&bizCode="+8+"&privateField="+"&fileName="+"&access_token="+token,
                                            filePath: path,
                                            name: 'file',
                                            formData:alldata,
                                            header: {
                                                "Content-Type": "multipart/form-data"
                                            },
                                            success: function (res) {
                                                console.log(res)
                                                var jsondata=JSON.parse(res.data)
                                                console.log(res);
                                                if (res.statusCode != 200) {
                                                    wx.showModal({
                                                        title: '提示',
                                                        content: '上传失败',
                                                        showCancel: false
                                                    })
                                                    return;
                                                }

                                                if(Identification=="zero"){
                                                    page.data.arrfileID.push(jsondata.body.content.fileID)
                                                    page.data.datas.push(jsondata.body.content.fileUrl)
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="one"){
                                                    page.data.arrfileID.push(jsondata.body.content.fileID)
                                                    page.data.datas.push(jsondata.body.content.fileUrl)
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="two"){
                                                    page.data.arrfileID.push(jsondata.body.content.fileID)
                                                    page.data.datas.push(jsondata.body.content.fileUrl)
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="modifyzero"){
                                                    page.data.arrfileID[0]=jsondata.body.content.fileID
                                                    page.data.datas[0]=jsondata.body.content.fileUrl
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="modifyone"){
                                                    page.data.arrfileID[1]=jsondata.body.content.fileID
                                                    page.data.datas[1]=jsondata.body.content.fileUrl
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="modifytwo"){
                                                    page.data.arrfileID[2]=jsondata.body.content.fileID
                                                    page.data.datas[2]=jsondata.body.content.fileUrl
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }
                                            },
                                            fail: function (e) {
                                                console.log(e);
                                                wx.showModal({
                                                    title: '提示',
                                                    content: '上传失败',
                                                    showCancel: false
                                                })
                                            },
                                            complete: function () {
                                                wx.hideToast();  //隐藏Toast
                                            }
                                        })
                                }
                            });
                        }else if(i==2){
                            var page=_this
                            var Identification="two"
                            var path=res.tempFilePaths[i]
                            wx.getStorage({
                                key: 'token',
                                success: function (res) {
                                    var token=res.data
                                    var alldata={
                                        app_key:app.data.appKey,
                                        timestamp:new Date().getTime(),
                                        access_token:token,
                                        signature:"",
                                        param:"",
                                        bizCode:8,
                                        privateField:"",
                                        fileName:""

                                    }
                                    wx.showToast({
                                        icon: "loading",
                                        title: "正在上传"
                                    }),
                                        wx.uploadFile({
                                            url: app.data.allDomainNameUrl+'fileUpload?app_key='+app.data.appKey+"&bizCode="+8+"&privateField="+"&fileName="+"&access_token="+token,
                                            filePath: path,
                                            name: 'file',
                                            formData:alldata,
                                            header: {
                                                "Content-Type": "multipart/form-data"
                                            },
                                            success: function (res) {
                                                console.log(res)
                                                var jsondata=JSON.parse(res.data)
                                                console.log(res);
                                                if (res.statusCode != 200) {
                                                    wx.showModal({
                                                        title: '提示',
                                                        content: '上传失败',
                                                        showCancel: false
                                                    })
                                                    return;
                                                }

                                                if(Identification=="zero"){
                                                    page.data.arrfileID.push(jsondata.body.content.fileID)
                                                    page.data.datas.push(jsondata.body.content.fileUrl)
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="one"){
                                                    page.data.arrfileID.push(jsondata.body.content.fileID)
                                                    page.data.datas.push(jsondata.body.content.fileUrl)
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="two"){
                                                    page.data.arrfileID.push(jsondata.body.content.fileID)
                                                    page.data.datas.push(jsondata.body.content.fileUrl)
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="modifyzero"){
                                                    page.data.arrfileID[0]=jsondata.body.content.fileID
                                                    page.data.datas[0]=jsondata.body.content.fileUrl
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="modifyone"){
                                                    page.data.arrfileID[1]=jsondata.body.content.fileID
                                                    page.data.datas[1]=jsondata.body.content.fileUrl
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="modifytwo"){
                                                    page.data.arrfileID[2]=jsondata.body.content.fileID
                                                    page.data.datas[2]=jsondata.body.content.fileUrl
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }
                                            },
                                            fail: function (e) {
                                                console.log(e);
                                                wx.showModal({
                                                    title: '提示',
                                                    content: '上传失败',
                                                    showCancel: false
                                                })
                                            },
                                            complete: function () {
                                                wx.hideToast();  //隐藏Toast
                                            }
                                        })
                                }
                            });
                        }

                    }


                }
            })
        } else if (this.data.size == 1) {
            var _this = this;
            wx.chooseImage({
                count: 2, // 默认9
                sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
                sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
                success: function (res) {
                    _this.data.size = _this.data.size + res.tempFilePaths.length
                    if (_this.data.size == 3) {
                        _this.setData({
                            boolean: "false"
                        })
                    }
                    // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
                    for (var i = 0; i < res.tempFilePaths.length; i++) {
                       /* _this.data.datas.push(res.tempFilePaths[i])*/
                            if(i==0){
                                var page=_this
                                var Identification="one"
                                var path=res.tempFilePaths[i]
                                wx.getStorage({
                                    key: 'token',
                                    success: function (res) {
                                        var token=res.data
                                        var alldata={
                                            app_key:app.data.appKey,
                                            timestamp:new Date().getTime(),
                                            access_token:token,
                                            signature:"",
                                            param:"",
                                            bizCode:8,
                                            privateField:"",
                                            fileName:""

                                        }
                                        wx.showToast({
                                            icon: "loading",
                                            title: "正在上传"
                                        }),
                                            wx.uploadFile({
                                                url: app.data.allDomainNameUrl+'fileUpload?app_key='+app.data.appKey+"&bizCode="+8+"&privateField="+"&fileName="+"&access_token="+token,
                                                filePath: path,
                                                name: 'file',
                                                formData:alldata,
                                                header: {
                                                    "Content-Type": "multipart/form-data"
                                                },
                                                success: function (res) {
                                                    console.log(res)
                                                    var jsondata=JSON.parse(res.data)
                                                    console.log(res);
                                                    if (res.statusCode != 200) {
                                                        wx.showModal({
                                                            title: '提示',
                                                            content: '上传失败',
                                                            showCancel: false
                                                        })
                                                        return;
                                                    }

                                                    if(Identification=="zero"){
                                                        page.data.arrfileID.push(jsondata.body.content.fileID)
                                                        page.data.datas.push(jsondata.body.content.fileUrl)
                                                        page.setData({  //上传成功修改显示照片
                                                            "datas1": page.data.datas
                                                        })
                                                    }else if(Identification=="one"){
                                                        page.data.arrfileID.push(jsondata.body.content.fileID)
                                                        page.data.datas.push(jsondata.body.content.fileUrl)
                                                        page.setData({  //上传成功修改显示照片
                                                            "datas1": page.data.datas
                                                        })
                                                    }else if(Identification=="two"){
                                                        page.data.arrfileID.push(jsondata.body.content.fileID)
                                                        page.data.datas.push(jsondata.body.content.fileUrl)
                                                        page.setData({  //上传成功修改显示照片
                                                            "datas1": page.data.datas
                                                        })
                                                    }else if(Identification=="modifyzero"){
                                                        page.data.arrfileID[0]=jsondata.body.content.fileID
                                                        page.data.datas[0]=jsondata.body.content.fileUrl
                                                        page.setData({  //上传成功修改显示照片
                                                            "datas1": page.data.datas
                                                        })
                                                    }else if(Identification=="modifyone"){
                                                        page.data.arrfileID[1]=jsondata.body.content.fileID
                                                        page.data.datas[1]=jsondata.body.content.fileUrl
                                                        page.setData({  //上传成功修改显示照片
                                                            "datas1": page.data.datas
                                                        })
                                                    }else if(Identification=="modifytwo"){
                                                        page.data.arrfileID[2]=jsondata.body.content.fileID
                                                        page.data.datas[2]=jsondata.body.content.fileUrl
                                                        page.setData({  //上传成功修改显示照片
                                                            "datas1": page.data.datas
                                                        })
                                                    }
                                                },
                                                fail: function (e) {
                                                    console.log(e);
                                                    wx.showModal({
                                                        title: '提示',
                                                        content: '上传失败',
                                                        showCancel: false
                                                    })
                                                },
                                                complete: function () {
                                                    wx.hideToast();  //隐藏Toast
                                                }
                                            })
                                    }
                                });
                            }else if(i==1){
                                var page=_this
                                var Identification="two"
                                var path=res.tempFilePaths[i]
                                wx.getStorage({
                                    key: 'token',
                                    success: function (res) {
                                        var token=res.data
                                        var alldata={
                                            app_key:app.data.appKey,
                                            timestamp:new Date().getTime(),
                                            access_token:token,
                                            signature:"",
                                            param:"",
                                            bizCode:8,
                                            privateField:"",
                                            fileName:""

                                        }
                                        wx.showToast({
                                            icon: "loading",
                                            title: "正在上传"
                                        }),
                                            wx.uploadFile({
                                                url: app.data.allDomainNameUrl+'fileUpload?app_key='+app.data.appKey+"&bizCode="+8+"&privateField="+"&fileName="+"&access_token="+token,
                                                filePath: path,
                                                name: 'file',
                                                formData:alldata,
                                                header: {
                                                    "Content-Type": "multipart/form-data"
                                                },
                                                success: function (res) {
                                                    console.log(res)
                                                    var jsondata=JSON.parse(res.data)
                                                    console.log(res);
                                                    if (res.statusCode != 200) {
                                                        wx.showModal({
                                                            title: '提示',
                                                            content: '上传失败',
                                                            showCancel: false
                                                        })
                                                        return;
                                                    }

                                                    if(Identification=="zero"){
                                                        page.data.arrfileID.push(jsondata.body.content.fileID)
                                                        page.data.datas.push(jsondata.body.content.fileUrl)
                                                        page.setData({  //上传成功修改显示照片
                                                            "datas1": page.data.datas
                                                        })
                                                    }else if(Identification=="one"){
                                                        page.data.arrfileID.push(jsondata.body.content.fileID)
                                                        page.data.datas.push(jsondata.body.content.fileUrl)
                                                        page.setData({  //上传成功修改显示照片
                                                            "datas1": page.data.datas
                                                        })
                                                    }else if(Identification=="two"){
                                                        page.data.arrfileID.push(jsondata.body.content.fileID)
                                                        page.data.datas.push(jsondata.body.content.fileUrl)
                                                        page.setData({  //上传成功修改显示照片
                                                            "datas1": page.data.datas
                                                        })
                                                    }else if(Identification=="modifyzero"){
                                                        page.data.arrfileID[0]=jsondata.body.content.fileID
                                                        page.data.datas[0]=jsondata.body.content.fileUrl
                                                        page.setData({  //上传成功修改显示照片
                                                            "datas1": page.data.datas
                                                        })
                                                    }else if(Identification=="modifyone"){
                                                        page.data.arrfileID[1]=jsondata.body.content.fileID
                                                        page.data.datas[1]=jsondata.body.content.fileUrl
                                                        page.setData({  //上传成功修改显示照片
                                                            "datas1": page.data.datas
                                                        })
                                                    }else if(Identification=="modifytwo"){
                                                        page.data.arrfileID[2]=jsondata.body.content.fileID
                                                        page.data.datas[2]=jsondata.body.content.fileUrl
                                                        page.setData({  //上传成功修改显示照片
                                                            "datas1": page.data.datas
                                                        })
                                                    }
                                                },
                                                fail: function (e) {
                                                    console.log(e);
                                                    wx.showModal({
                                                        title: '提示',
                                                        content: '上传失败',
                                                        showCancel: false
                                                    })
                                                },
                                                complete: function () {
                                                    wx.hideToast();  //隐藏Toast
                                                }
                                            })
                                    }
                                });
                            }
                    }

                }
            })
        } else if (this.data.size == 2) {
            var _this = this;
            wx.chooseImage({
                count: 1, // 默认9
                sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
                sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
                success: function (res) {
                    _this.data.size = _this.data.size + res.tempFilePaths.length
                    if (_this.data.size == 3) {
                        _this.setData({
                            boolean: "false"
                        })
                    }
                    // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
                    for (var i = 0; i < res.tempFilePaths.length; i++) {

                        if(i==0){
                            var page=_this
                            var Identification="two"
                            var path=res.tempFilePaths[i]
                            wx.getStorage({
                                key: 'token',
                                success: function (res) {
                                    var token=res.data
                                    var alldata={
                                        app_key:app.data.appKey,
                                        timestamp:new Date().getTime(),
                                        access_token:token,
                                        signature:"",
                                        param:"",
                                        bizCode:8,
                                        privateField:"",
                                        fileName:""

                                    }
                                    wx.showToast({
                                        icon: "loading",
                                        title: "正在上传"
                                    }),
                                        wx.uploadFile({
                                            url: app.data.allDomainNameUrl+'fileUpload?app_key='+app.data.appKey+"&bizCode="+8+"&privateField="+"&fileName="+"&access_token="+token,
                                            filePath: path,
                                            name: 'file',
                                            formData:alldata,
                                            header: {
                                                "Content-Type": "multipart/form-data"
                                            },
                                            success: function (res) {
                                                console.log(res)
                                                var jsondata=JSON.parse(res.data)
                                                console.log(res);
                                                if (res.statusCode != 200) {
                                                    wx.showModal({
                                                        title: '提示',
                                                        content: '上传失败',
                                                        showCancel: false
                                                    })
                                                    return;
                                                }

                                                if(Identification=="zero"){
                                                    page.data.arrfileID.push(jsondata.body.content.fileID)
                                                    page.data.datas.push(jsondata.body.content.fileUrl)
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="one"){
                                                    page.data.arrfileID.push(jsondata.body.content.fileID)
                                                    page.data.datas.push(jsondata.body.content.fileUrl)
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="two"){
                                                    page.data.arrfileID.push(jsondata.body.content.fileID)
                                                    page.data.datas.push(jsondata.body.content.fileUrl)
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="modifyzero"){
                                                    page.data.arrfileID[0]=jsondata.body.content.fileID
                                                    page.data.datas[0]=jsondata.body.content.fileUrl
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="modifyone"){
                                                    page.data.arrfileID[1]=jsondata.body.content.fileID
                                                    page.data.datas[1]=jsondata.body.content.fileUrl
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }else if(Identification=="modifytwo"){
                                                    page.data.arrfileID[2]=jsondata.body.content.fileID
                                                    page.data.datas[2]=jsondata.body.content.fileUrl
                                                    page.setData({  //上传成功修改显示照片
                                                        "datas1": page.data.datas
                                                    })
                                                }
                                            },
                                            fail: function (e) {
                                                console.log(e);
                                                wx.showModal({
                                                    title: '提示',
                                                    content: '上传失败',
                                                    showCancel: false
                                                })
                                            },
                                            complete: function () {
                                                wx.hideToast();  //隐藏Toast
                                            }
                                        })
                                }
                            });
                        }
                    }
                    console.log(_this.data.datas)

                }
            })
        }
    },
    textareacontext: function (e) {
        this.data.content = e.detail.value
    },
    onpreservation: function () {
        var that=this;
        wx.showModal({
            title: '提醒',
            content: '是否发布日志!',
            success: function (res) {
                if (res.confirm) {//这里是点击了确定以后
                    if (that.data.type == 1) {
                        for(var i=0;i<that.data.arrfileID.length;i++){
                            that.data.arrOtherPhoto[i]={
                                logisticsOrderID:that.data.orderID,
                                fileID:that.data.arrfileID[i],
                                fileSeqNo:i,
                                bizType:8
                            }
                        }
                        var options = {
                            port: 'otherLogSave',
                            body: {
                                "businessId": that.data.orderID,
                                "bizType": "1133000",
                                "createrInfo": app.userSimpleInfo,
                                "content": that.data.content,
                                "arrOtherPhoto":that.data.arrOtherPhoto
                            }
                        }
                        app.connect(options).then(values => {
                            console.log(values)
                            if (values.data.body.code == "0") {
                                that.data.arrfileID.splice(0,that.data.arrfileID.length);
                                that.data.datas.splice(0, that.data.datas.length);

                                var options = {
                                    port: 'otherLogQry',
                                    body: {
                                        "businessId": that.data.orderID,
                                        "bizType": "1133000",
                                    }
                                }
                                app.connect(options).then(values => {
                                    console.log(values)
                                    that.setData({
                                        "datas1": that.data.datas,
                                        boolean:false,
                                        evaContent: "",
                                        arrOtherLogInfo: values.data.body.content.arrOtherLogInfo
                                    })
                                })
                            }
                        })
                    } else if (that.data.type == 2) {
                        for(var i=0;i<that.data.arrfileID.length;i++){
                            that.data.arrOtherPhoto[i]={
                                logisticsOrderID:that.data.dispatchID,
                                fileID:that.data.arrfileID[i],
                                fileSeqNo:i,
                                bizType:8
                            }
                        }
                        var options = {
                            port: 'otherLogSave',
                            body: {
                                "businessId": that.data.dispatchID,
                                "bizType": "1133020",
                                "createrInfo": app.userSimpleInfo,
                                "content": that.data.content,
                                "arrOtherPhoto":that.data.arrOtherPhoto
                            }
                        }
                        app.connect(options).then(values => {
                            console.log(values)
                            if (values.data.body.code == "0") {
                                that.data.arrfileID.splice(0,that.data.arrfileID.length);
                                that.data.datas.splice(0, that.data.datas.length);
                                var options = {
                                    port: 'otherLogQry',
                                    body: {
                                        "businessId": that.data.dispatchID,
                                        "bizType": "1133020",
                                    }
                                }
                                app.connect(options).then(values => {
                                    console.log(values)
                                    that.setData({
                                        "datas1": that.data.datas,
                                        boolean:false,
                                        evaContent: "",
                                        arrOtherLogInfo: values.data.body.content.arrOtherLogInfo
                                    })
                                })
                            }
                        })
                    }
                } else {//这里是点击了取消以后
                }
            }
        })
    },
    onDelete: function (e) {
        var that=this;
        wx.showModal({
            title:"提示",
            content:"确认删除该日志",
            showCancel:true,
            //用户确定
            success:function (res) {
                if (res.confirm) {
                    var otherLogId = e.currentTarget.dataset.name
                    var options = {
                        port: 'otherLogDel',
                        body: {
                            "arrOtherLogId": [otherLogId]
                        }
                    }
                    app.connect(options).then(values => {
                        console.log(values)
                        console.log(that.data.type)
                        if (that.data.type == 1) {
                            var options = {
                                port: 'otherLogQry',
                                body: {
                                    "businessId": that.data.orderID,
                                    "bizType": "1133000",
                                }
                            }
                            app.connect(options).then(values => {
                                if (values.data.body.content != null) {
                                    that.setData({
                                        arrOtherLogInfo: values.data.body.content.arrOtherLogInfo
                                    })
                                } else {
                                    that.setData({
                                        arrOtherLogInfo: values.data.body.content
                                    })
                                }
                            })
                        } else if (that.data.type == 2) {
                            var options = {
                                port: 'otherLogQry',
                                body: {
                                    "businessId": that.data.dispatchID,
                                    "bizType": "1133020",
                                }
                            }
                            app.connect(options).then(values => {
                                console.log(values)
                                if (values.data.body.content != null) {
                                    that.setData({
                                        arrOtherLogInfo: values.data.body.content.arrOtherLogInfo
                                    })
                                } else {
                                    that.setData({
                                        arrOtherLogInfo: values.data.body.content
                                    })
                                }

                            })

                        }
                    })
                }
            },
            //退出失败，可能一些原因导致
            fail:function (res) {
                wx.showToast({
                    title:"退出失败,请反馈",
                    duration:1500,
                });
            },
        });
    },
    upload:function (page,Identification,path) {
        console.log(path)
        var token;
        wx.getStorage({
            key: 'token',
            success: function (res) {
                token = res.data;
            }
        });
        var alldata={
            app_key:app.data.appKey,
            timestamp:new Date().getTime(),
            access_token:token,
            signature:"",
            param:"",
            bizCode:8,
            privateField:"",
            fileName:""

        }
        wx.showToast({
            icon: "loading",
            title: "正在上传"
        }),
            wx.uploadFile({
                url: app.data.allDomainNameUrl+'fileUpload?app_key='+app.data.appKey+"&bizCode="+8+"&privateField="+"&fileName="+"&access_token="+token,
                filePath: path,
                name: 'file',
                formData:alldata,
                header: {
                    "Content-Type": "multipart/form-data"
                },
                success: function (res) {
                    console.log(res)
                    var jsondata=JSON.parse(res.data)
                    console.log(res);
                    if (res.statusCode != 200) {
                        wx.showModal({
                            title: '提示',
                            content: '上传失败',
                            showCancel: false
                        })
                        return;
                    }

                    if(Identification=="zero"){
                        page.data.arrfileID.push(jsondata.body.content.fileID)
                        page.data.datas.push(jsondata.body.content.fileUrl)
                        page.setData({  //上传成功修改显示照片
                            "datas1": page.data.datas
                        })
                    }else if(Identification=="one"){
                        page.data.arrfileID.push(jsondata.body.content.fileID)
                        page.data.datas.push(jsondata.body.content.fileUrl)
                        page.setData({  //上传成功修改显示照片
                            "datas1": page.data.datas
                        })
                    }else if(Identification=="two"){
                        page.data.arrfileID.push(jsondata.body.content.fileID)
                        page.data.datas.push(jsondata.body.content.fileUrl)
                        page.setData({  //上传成功修改显示照片
                            "datas1": page.data.datas
                        })
                    }else if(Identification=="modifyzero"){
                        page.data.arrfileID[0]=jsondata.body.content.fileID
                        page.data.datas[0]=jsondata.body.content.fileUrl
                        page.setData({  //上传成功修改显示照片
                            "datas1": page.data.datas
                        })
                    }else if(Identification=="modifyone"){
                        page.data.arrfileID[1]=jsondata.body.content.fileID
                        page.data.datas[1]=jsondata.body.content.fileUrl
                        page.setData({  //上传成功修改显示照片
                            "datas1": page.data.datas
                        })
                    }else if(Identification=="modifytwo"){
                        page.data.arrfileID[2]=jsondata.body.content.fileID
                        page.data.datas[2]=jsondata.body.content.fileUrl
                        page.setData({  //上传成功修改显示照片
                            "datas1": page.data.datas
                        })
                    }
                },
                fail: function (e) {
                    console.log(e);
                    wx.showModal({
                        title: '提示',
                        content: '上传失败',
                        showCancel: false
                    })
                },
                complete: function () {
                    wx.hideToast();  //隐藏Toast
                }
            })
    },
    modify:function (e) {
        var index=e.currentTarget.dataset.id;
        var _this = this;
        wx.chooseImage({
            count: 1, // 默认9
            sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
            sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
            success: function (res) {
                // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
                    if(index==0){
                        _this.upload(_this,"modifyzero",res.tempFilePaths[0]);
                    }else if(index==1){
                        _this.upload(_this,"modifyone",res.tempFilePaths[0]);
                    }else if(index==2){
                        _this.upload(_this,"modifytwo",res.tempFilePaths[0]);
                    }

            }
        })
    },
    previewImage:function (e) {
        console.log(e.currentTarget.dataset.name)
        wx.previewImage({
            urls:[e.currentTarget.dataset.name]
        })
    }
})