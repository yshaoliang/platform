var app = getApp();
var publish = require('../../public_util/publishData');
Page({
    /*下拉刷新*/
    onPullDownRefresh() {
        wx.stopPullDownRefresh()
    },
    data: {
        name: '',
        mobile: '',
        driverID:'',
        idNumber:'',
        qualificationCerrificateNumber:'',
        bankcardNumber:'',
        drivingYears:'',
        desc:'',
        relationType:'',
        teamID:'',
        idPhotoFileID:"",
        idBackPhotoFileID:"",
        licensePhotoFileID:"",
        arrOtherPhotoInfo:[],
        multiArray1: [publish.years,publish.mouths,publish.days,publish.houvers,publish.branchs],
        multiIndex1: ["", "", "","",""],
        multiArray2: [publish.years,publish.mouths,publish.days,publish.houvers,publish.branchs],
        multiIndex2: ["", "", "","",""],
        multiArray3: [publish.years,publish.mouths,publish.days,publish.houvers,publish.branchs],
        multiIndex3: ["", "", "","",""],
        multiArray4: [publish.years,publish.mouths,publish.days,publish.houvers,publish.branchs],
        multiIndex4: ["", "", "","",""],
        multiArray5: [publish.years,publish.mouths,publish.days,publish.houvers,publish.branchs],
        multiIndex5: ["", "", "","",""],
        access_token:'',
        frontofidcardID:'',
        frontofidcardUrl:'',
        thebackoftheidcardID:'',
        thebackoftheidcardUrl:'',
        bankcardID:'',
        bankcardUrl:'',
        frontofdriverlicenseID:'',
        frontofdriverlicenseUrl:'',
        theothersideUrl:'',
        theothersideID:'',
        allShuju:'',
        onLoadSex:'',
        judgeMobile:'',
        judgeIdPositivePhoto:'',
        judgeName:'',
        judgeIdNumber:'',
        judgeIdSex:'',
        judgethebackoftheidcardUrl:'',
        judgeDeliverytime:'',
        judgeDeliverytime2:'',
        judgefrontofdriverlicenseUrl:'',
        judgedeliverytime3:'',
        judgedeliverytime4:'',
        judgedeliverytime5:'',
        judgedeDrivingName:'',
        isshuju2:''

    },
    /*相册组件*/
    chooseimage1: function (e) {
        var transport=e.currentTarget.dataset.name
        var _this = this;
        wx.chooseImage({
            count: 1, // 默认9
            sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
            sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
            success: function (res) {
                console.log(res.tempFilePaths[0])
                var tempFilePaths = res.tempFilePaths;
                var page=_this
                var data=transport
                var path=tempFilePaths
                console.log(path[0])
                var token;
                var bizCode;
                wx.getStorage({
                    key: 'token',
                    success: function (res) {
                        token = res.data;
                        console.log(token)
                        if(data=="frontofidcard"&&data=="thebackoftheidcard"){
                            bizCode=2
                        }else if(data=="frontofdriverlicense"){
                            bizCode=3
                        }
                        else{
                            bizCode=8
                        }
                        var alldata={
                            app_key: app.data.appKey,
                            timestamp:new Date().getTime(),
                            access_token: token,
                            signature:"",
                            param:"",
                            bizCode:bizCode,
                            privateField:"",
                            fileName:""

                        }
                        wx.showToast({
                            icon: "loading",
                            title: "正在上传"
                        }),
                            wx.uploadFile({
                                url:app.data.allDomainNameUrl+'fileUpload?app_key='+app.data.appKey+"&bizCode="+8+"&privateField="+"&fileName="+"&access_token="+token,
                         //       url: 'https://www.niuinfo.com/test/api/fileUpload?app_key='+app.data.appKey+"&bizCode="+8+"&privateField="+"&fileName="+"&access_token="+token,

                                filePath: path[0],
                                name: 'file',
                                formData:alldata,
                                header: {
                                    "Content-Type": "multipart/form-data"
                                },
                                success: function (res) {
                                    console.log(res)
                                    var jsondata=JSON.parse(res.data)
                                    console.log(res);
                                    if (res.statusCode != 200) {
                                        wx.showModal({
                                            title: '提示',
                                            content: '上传失败',
                                            showCancel: false
                                        })
                                        return;
                                    }
                                    if(data=="frontofidcard"){

                                        page.data.frontofidcardID=jsondata.body.content.fileID
                                        page.data.judgeIdPositivePhoto=jsondata.body.content.fileUrl
                                        page.data.frontofidcardUrl=jsondata.body.content.fileUrl
                                        //---------------------
                                        var url="https://aip.baidubce.com/rest/2.0/ocr/v1/idcard";
                                        const fs = wx.getFileSystemManager();
                                        fs.readFile({
                                            filePath:path[0],
                                            encoding:"base64",
                                            success:function (data) {
                                                wx.showLoading({
                                                    title: "正在加载中...",
                                                    mask:"true"
                                                });
                                                var s = data.data.replace("\n","");
                                                var datas={
                                                    access_token:_this.data.access_token,
                                                    image:s,
                                                    id_card_side:"front",
                                                    detect_direction:"true",
                                                    detect_risk:"true"
                                                }
                                                wx.request({
                                                    data: datas,
                                                    header: {'content-type': 'application/x-www-form-urlencoded'},
                                                    url: url,
                                                    method: 'POST',
                                                    success: function (res) {
                                                        wx.hideToast();
                                                        console.log(res)
                                                        if(res.data.direction=="-1"){
                                                            wx.showToast({
                                                                title: "图片不清晰，请重新识别",
                                                                mask: false,
                                                                icon: "none",
                                                                duration: 2000,
                                                            })
                                                            return;
                                                        }
                                                        _this.data.judgeName=res.data.words_result.姓名.words
                                                        _this.data.judgeIdNumber=res.data.words_result.公民身份号码.words
                                                        console.log(res.data.words_result.性别.words)
                                                        _this.data.judgeIdSex=res.data.words_result.性别.words
                                                        _this.setData({
                                                            idName:res.data.words_result.姓名.words,
                                                            idNumber:res.data.words_result.公民身份号码.words,
                                                            idSex:res.data.words_result.性别.words
                                                        })
                                                    },
                                                    fail: function (event) {
                                                        console.log(event)


                                                    },
                                                })
                                            }
                                        })

                                        //---------------------

                                        page.setData({  //上传成功修改显示头像
                                            frontofidcardUrl: jsondata.body.content.fileUrl
                                        })
                                    }else if(data=="thebackoftheidcard"){
                                        page.data.thebackoftheidcardID=jsondata.body.content.fileID
                                        page.data.judgethebackoftheidcardUrl=jsondata.body.content.fileUrl
                                        page.data.thebackoftheidcardUrl=jsondata.body.content.fileUrl
                                        //---------------------
                                        var url="https://aip.baidubce.com/rest/2.0/ocr/v1/idcard";
                                        const fs = wx.getFileSystemManager();
                                        fs.readFile({
                                            filePath:path[0],
                                            encoding:"base64",
                                            success:function (data) {
                                                wx.showLoading({
                                                    title: "正在加载中...",
                                                     mask:"true"
                                                });
                                                var s = data.data.replace("\n","");
                                                var datas={
                                                    access_token:_this.data.access_token,
                                                    image:s,
                                                    id_card_side:"back",
                                                    detect_direction:"true",
                                                    detect_risk:"true"
                                                }
                                                wx.request({
                                                    data: datas,
                                                    header: {'content-type': 'application/x-www-form-urlencoded'},
                                                    url: url,
                                                    method: 'POST',
                                                    success: function (res) {
                                                        wx.hideToast();
                                                        console.log(res)
                                                        if(res.data.direction=="-1"){
                                                            wx.showToast({
                                                                title: "图片不清晰，请重新识别",
                                                                mask: false,
                                                                icon: "none",
                                                                duration: 2000,
                                                            })
                                                            return;
                                                        }
                                                        var deliverytime="";
                                                        var deliverytime2="";
                                                        if(res.data.words_result.签发日期.words.length!=8||res.data.words_result.失效日期.words.length!=8){
                                                            wx.showToast({
                                                                title: "图片不清晰，请重新识别",
                                                                mask: false,
                                                                icon: "none",
                                                                duration: 2000,
                                                            })
                                                            return;
                                                        }else{
                                                            deliverytime=res.data.words_result.签发日期.words.substring(0,4)+"-"+res.data.words_result.签发日期.words.substring(4,6)+"-"+res.data.words_result.签发日期.words.substring(6,8);
                                                            deliverytime2=res.data.words_result.失效日期.words.substring(0,4)+"-"+res.data.words_result.失效日期.words.substring(4,6)+"-"+res.data.words_result.失效日期.words.substring(6,8)

                                                        }
                                                        _this.data.judgeDeliverytime=deliverytime;
                                                        _this.data.judgeDeliverytime2=deliverytime2;
                                                        _this.setData({
                                                            deliverytime:deliverytime,
                                                            deliverytime2:deliverytime2
                                                        })
                                                    },
                                                    fail: function (event) {
                                                        console.log(event)
                                                    },
                                                })
                                            }
                                        })
                                        //---------------------

                                        page.setData({  //上传成功修改显示头像
                                            thebackoftheidcardUrl: jsondata.body.content.fileUrl
                                        })

                                    }else if(data=="bankcard"){
                                        page.data.bankcardID=jsondata.body.content.fileID
                                        page.data.bankcardUrl=jsondata.body.content.fileUrl
                                        //---------------------
                                        var url="https://aip.baidubce.com/rest/2.0/ocr/v1/bankcard";
                                        const fs = wx.getFileSystemManager();
                                        fs.readFile({
                                            filePath:path[0],
                                            encoding:"base64",
                                            success:function (data) {
                                                wx.showLoading({
                                                    title: "正在加载中...",
                                                    mask:"true"
                                                });
                                                var s = data.data.replace("\n","");
                                                var datas={
                                                    access_token:_this.data.access_token,
                                                    image:s,

                                                }
                                                wx.request({
                                                    data: datas,
                                                    header: {'content-type': 'application/x-www-form-urlencoded'},
                                                    url: url,
                                                    method: 'POST',
                                                    success: function (res) {
                                                        wx.hideToast();
                                                        console.log(res)
                                                        if(res.data.result==undefined){
                                                            wx.showToast({
                                                                title: "图片不清晰，请重新识别",
                                                                mask: false,
                                                                icon: "none",
                                                                duration: 2000,
                                                            })
                                                            return;
                                                        }
                                                        _this.data.bankcardNumber=res.data.result.bank_card_number.replace(/\s*/g,"");
                                                        _this.setData({
                                                            bankCardNumber:res.data.result.bank_card_number.replace(/\s*/g,""),
                                                        })
                                                    },
                                                    fail: function (event) {
                                                        console.log(event)
                                                    },
                                                })
                                            }
                                        })
                                        //---------------------

                                        page.setData({  //上传成功修改显示头像
                                            bankcardUrl: jsondata.body.content.fileUrl
                                        })


                                    }else if(data=="frontofdriverlicense"){
                                        page.data.frontofdriverlicenseID=jsondata.body.content.fileID
                                        page.data.judgefrontofdriverlicenseUrl=jsondata.body.content.fileUrl
                                        page.data.frontofdriverlicenseUrl=jsondata.body.content.fileUrl
                                        //---------------------
                                        var url="https://aip.baidubce.com/rest/2.0/ocr/v1/driving_license";
                                        const fs = wx.getFileSystemManager();
                                        fs.readFile({
                                            filePath:path[0],
                                            encoding:"base64",
                                            success:function (data) {
                                                wx.showLoading({
                                                    title: "正在加载中...",
                                                    mask:"true"
                                                });
                                                var s = data.data.replace("\n","");
                                                var datas={
                                                    access_token:_this.data.access_token,
                                                    image:s,
                                                    detect_direction:'true',
                                                    unified_valid_period:'true'

                                                }
                                                wx.request({
                                                    data: datas,
                                                    header: {'content-type': 'application/x-www-form-urlencoded'},
                                                    url: url,
                                                    method: 'POST',
                                                    success: function (res) {
                                                        wx.hideToast();
                                                        console.log(res)
                                                        var deliverytime3="";
                                                        var deliverytime4="";
                                                        var deliverytime5="";
                                                        if(res.data.words_result.初次领证日期.words.length!=8||res.data.words_result.初次领证日期.words.length!=8){
                                                            wx.showToast({
                                                                title: "图片不清晰，请重新识别",
                                                                mask: false,
                                                                icon: "none",
                                                                duration: 2000,
                                                            })
                                                            return;
                                                        }else{
                                                            if(res.data.words_result.有效期限.words.length!=8){
                                                                deliverytime3=res.data.words_result.初次领证日期.words.substring(0,4)+"-"+res.data.words_result.初次领证日期.words.substring(4,6)+"-"+res.data.words_result.初次领证日期.words.substring(6,8);
                                                                deliverytime4=res.data.words_result.初次领证日期.words.substring(0,4)+"-"+res.data.words_result.初次领证日期.words.substring(4,6)+"-"+res.data.words_result.初次领证日期.words.substring(6,8);
                                                                deliverytime5=(Number(res.data.words_result.初次领证日期.words.substring(0,4))+Number(res.data.words_result.有效期限.words.substring(0,1)))+"-"+res.data.words_result.初次领证日期.words.substring(4,6)+"-"+res.data.words_result.初次领证日期.words.substring(6,8);
                                                            }else{
                                                                deliverytime3=res.data.words_result.初次领证日期.words.substring(0,4)+"-"+res.data.words_result.初次领证日期.words.substring(4,6)+"-"+res.data.words_result.初次领证日期.words.substring(6,8);
                                                                deliverytime4=res.data.words_result.初次领证日期.words.substring(0,4)+"-"+res.data.words_result.初次领证日期.words.substring(4,6)+"-"+res.data.words_result.初次领证日期.words.substring(6,8);
                                                                deliverytime5=res.data.words_result.有效期限.words.substring(0,4)+"-"+res.data.words_result.有效期限.words.substring(4,6)+"-"+res.data.words_result.有效期限.words.substring(6,8);
                                                            }

                                                        }
                                                        _this.data.judgedeliverytime3=deliverytime3
                                                        _this.data.judgedeliverytime4=deliverytime4
                                                        _this.data.judgedeliverytime5=deliverytime5
                                                        _this.data.judgedeDrivingName=res.data.words_result.准驾车型.words
                                                        _this.setData({
                                                            deliverytime3:deliverytime3,
                                                            drivingName:res.data.words_result.准驾车型.words,
                                                            deliverytime4:deliverytime4,
                                                            deliverytime5:deliverytime5,
                                                        })
                                                    },
                                                    fail: function (event) {
                                                        console.log(event)
                                                    },
                                                })
                                            }
                                        })
                                        //---------------------

                                        page.setData({  //上传成功修改显示头像
                                            frontofdriverlicenseUrl: jsondata.body.content.fileUrl
                                        })



                                    }else if(data=="theotherside"){
                                        page.data.theothersideID=jsondata.body.content.fileID
                                        page.data.theothersideUrl=jsondata.body.content.fileUrl


                                        page.setData({  //上传成功修改显示头像
                                            theothersideUrl: jsondata.body.content.fileUrl
                                        })



                                    }
                                },
                                fail: function (e) {
                                    console.log(e);
                                    wx.showModal({
                                        title: '提示',
                                        content: '上传失败',
                                        showCancel: false
                                    })
                                },
                                complete: function () {
                                    wx.hideToast();  //隐藏Toast
                                }
                            })
                    }
                });
                // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
                _this.setData({
                    tempFilePaths1: res.tempFilePaths[0]
                })
            }
        })
    },

   /*跳转页面*/
    ontypeofdriver: function () {
        wx.navigateTo({
            url: '../typeofdriver/typeofdriver',
        })
    },
    /*跳转页面*/
    onIseffective: function () {
        wx.navigateTo({
            url: '../effective/effective',
        })
    },
    onsex:function(){
        wx.navigateTo({
            url: '../sex/sex',
        })
    },
    /*加载数据*/
    onLoad: function (e) {
        var that=this;
        var url="https://aip.baidubce.com/oauth/2.0/token";
        var datas={
            grant_type: "client_credentials",
            client_id:"XG8eM7GVGLuXepax8kczamzf",
            client_secret:"MGWGt1d9zZ5hkWPjffn2y5EjtjO4ZNDw"
        }
        wx.request({
            data: datas,
            header: {'content-type': 'application/x-www-form-urlencoded'},
            url: url,
            method: 'POST',
            success: function (res) {
                console.log(res)
                that.data.access_token=res.data.access_token
            },
            fail: function (event) {
                console.log(event)
            },
        })

        //----------------
        app.driverType=1

        if(undefined!=e.driverID){
            this.data.driverID=e.driverID
            var options = {
                port: 'driverDtlQry3',
                body: {
                    driverID:e.driverID
                }
            }
            wx.setNavigationBarTitle({
                title:"修改司机信息"
            })
            app.connect(options).then(values => {
                var sex;
                console.log(values)
                /*this.data.name=values.data.body.content.driverInfo.name*/
                app.driverType=values.data.body.content.driverInfo.relationType
                if(values.data.body.content.driverInfo.relationType==1){
                    app.typeofdriver_name="外协司机"
                }else{
                    app.typeofdriver_name="公司同事"
                }

                this.data.teamID=values.data.body.content.driverInfo.teamID
                this.data.mobile=values.data.body.content.driverInfo.mobile
                this.data.idNumber=values.data.body.content.driverInfo.idNumber
                this.data.qualificationCerrificateNumber=values.data.body.content.driverInfo.qualificationCerrificateNumber
                this.data.bankcardNumber=values.data.body.content.driverInfo.bankcardNumber
                this.data.drivingYears=values.data.body.content.driverInfo.drivingYears
                this.data.desc=values.data.body.content.driverInfo.desc

                if(values.data.body.content.driverInfo.gender=="1"){
                    sex="男"
                }else{
                    sex="女"
                }
                app.sex=values.data.body.content.driverInfo.gender;
                this.data.judgeIdSex=sex;
                console.log(values.data.body.content.driverInfo.idPhotoUrl)
                this.data.allShuju=values.data.body.content.driverInfo
                this.data.judgeMobile=values.data.body.content.driverInfo.mobile
               /*this.data.judgeName=values.data.body.content.driverInfo.name*/
                this.data.judgeName=values.data.body.content.driverInfo.name
                this.data.judgeIdNumber=values.data.body.content.driverInfo.idNumber
                this.data.judgeIdSex=values.data.body.content.driverInfo.gender
                this.data.judgeDeliverytime=values.data.body.content.driverInfo.effectiveStartDate
                this.data.judgeDeliverytime2=values.data.body.content.driverInfo.effectiveEndDate
                this.data.bankcardNumber=values.data.body.content.driverInfo.bankcardNumber
                this.data.judgedeliverytime3=values.data.body.content.driverInfo.driverLicenceFirstGetDate
                this.data.judgedeliverytime4=values.data.body.content.driverInfo.driverLicenceStartDate
                this.data.judgedeliverytime5=values.data.body.content.driverInfo.driverLicenceExpiryDate
                if(values.data.body.content.driverInfo.isEndless=='1'){
                    this.data.isshuju2="是"
                }else{
                    this.data.isshuju2="否"
                }
                var s = {
                    2951010:"A1",
                    2951020:"A2",
                    2951030:"A3",
                    2951040:"B1",
                    2951050:"B2",
                    2951060:"C1",
                    2951070:"C2",
                    2951080:"C3",
                    2951090:"C4",
                    2951100:"D",
                    2951110:"E",
                    2951120:"F",
                    2951130:"M",
                    2951140:"N",
                    2951150:"P",

                }
                this.data.judgedeDrivingName=s[values.data.body.content.driverInfo.driverLicenseType]
                this.data.judgeIdPositivePhoto=values.data.body.content.driverInfo.idPhotoUrl
                this.data.judgethebackoftheidcardUrl=values.data.body.content.driverInfo.idBackPhotoFileUrl
                this.data.judgefrontofdriverlicenseUrl=values.data.body.content.driverInfo.licensePhotoUrl
                this.setData({
                    deliverytime5:values.data.body.content.driverInfo.driverLicenceExpiryDate,
                    deliverytime4:values.data.body.content.driverInfo.driverLicenceStartDate,
                    drivingName:s[values.data.body.content.driverInfo.driverLicenseType],
                    deliverytime3:values.data.body.content.driverInfo.driverLicenceFirstGetDate,
                    bankCardNumber:values.data.body.content.driverInfo.bankcardNumber,
                    shuju2:this.data.isshuju2,
                    deliverytime2:values.data.body.content.driverInfo.effectiveEndDate,
                    deliverytime:values.data.body.content.driverInfo.effectiveStartDate,
                    thebackoftheidcardUrl:values.data.body.content.driverInfo.idBackPhotoFileUrl,
                    frontofdriverlicenseUrl:values.data.body.content.driverInfo.licensePhotoUrl,
                    idSex:sex,
                    idNumber:values.data.body.content.driverInfo.idNumber,
                    idName:values.data.body.content.driverInfo.name,
                    echodisplaymobile:values.data.body.content.driverInfo.mobile,
                    frontofidcardUrl:values.data.body.content.driverInfo.idPhotoUrl,
                    shuju: app.typeofdriver_name,
                    idSex:sex,
                    allshuju:values.data.body.content.driverInfo,

                })

            })

        }
        /*this.data.judgedeDrivingName=app.data.drivingName*/
        this.data.isshuju2=app.data.isEffective
        this.setData({

            shuju2:app.data.isEffective,
            forward:app.globalData[48]
        })
        console.log(e.datas)
        if(e.datas!="") {
            var options = {
                port: 'driverDtlQry3',
                body: {
                    "driverID": e.datas,
                }
            }
        }
        app.connect(options).then(values => {
          /* this.data.judgeName=values.data.body.content.driverInfo.name*/
            this.setData({
                alldata:values.data.body.content.driverInfo
            })
        })
        if(e.driverID==undefined){
            this.setData({
                shuju: app.data.typeofdriver_name
            })
        }

    },
    /*加载数据*/
    onShow: function () {
        this.pageLoading = !1
        this.data.isshuju2=app.isEffective
        if(app.drivingName!=undefined){
            this.data.judgedeDrivingName=app.drivingName
        }
        console.log(app.data.sex_name)
        this.data.judgeIdSex=app.data.sex_name;
        this.setData({
            album:app.globalData[50],
            drivingName:app.drivingName,
            drivingType:app.drivingType,
            tranName: app.selection,
            shuju: app.typeofdriver_name,
            idSex:app.sex_name,
            shuju2:app.isEffective,
        })
    },
    /*获取input参数*/
    nameInput: function (e) {
        this.data.judgeName=e.detail.value;
        this.data.name = e.detail.value
        if(e.detail.value==""){
            this.data.name=""
        }else{
            this.data.judgeName=e.detail.value
        }
    },
    /*获取input参数*/
    mobileInput: function (e) {
        this.data.judgeMobile=e.detail.value
        if(e.detail.value==""){
            this.data.mobile=""
        }else{
            this.data.mobile = e.detail.value
        }

    },
    inputID:function(e){

        if(e.detail.value!=""){
            this.data.judgeIdNumber=e.detail.value
            this.data.idNumber=e.detail.value
        }

    },
    inputqualificationCerrificateNumber:function(e){
        if(e.detail.value!=""){
            this.data.qualificationCerrificateNumber=e.detail.value
        }

    },
    inputbankcardNumber:function(e){
        if(e.detail.value!=""){
            this.data.bankcardNumber=e.detail.value
        }

    },
    inputdrivingYears:function(e){
        if(e.detail.value!=""){
            this.data.drivingYears=e.detail.value
        }

    },
    inputdesc:function(e){
        if(e.detail.value!=""){
            this.data.desc=e.detail.value
        }

    },

    /*保存*/
    onPreservation: function () {
        var that=this;
        if (!that.pageLoading) {
            that.pageLoading = !0;
            console.log(this.data.judgedeDrivingName)
            var s = {
                "A1":2951010,
                "A2":2951020,
                "A3":2951030,
                "B1":2951040,
                "B2":2951050,
                "C1":2951060,
                "C2":2951070,
                "C3":2951080,
                "C4":2951090,
                "D":2951100,
                "E":2951110,
                "F":2951120,
                "M": 2951130,
                "N": 2951140,
                "P": 2951150,

            }
            if (app.relationType == undefined) {
                app.relationType = 1
            }
            var arrTeamID;
            console.log(app.orderdata["teamID"])
            if (app.orderdata["teamID"] == "") {
                arrTeamID = null
            } else {
                arrTeamID = [app.orderdata["teamID"]]
            }
            console.log(app.selection)
            if (app.selection == "") {
                arrTeamID = null
            }
            var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
            var strBin = "10,18,30,35,37,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,58,60,62,65,68,69,84,87,88,94,95,98,99";
            var num = /^\d*$/; //全数字
            if(this.data.bankcardNumber!=""&&this.data.bankcardNumber!=null){
                console.log(this.data.bankcardNumber)
                if(this.data.bankcardNumber.length<16||this.data.bankcardNumber.length > 19){
                    wx.showToast({
                        title: "银行卡号长度必须在16到19之间!",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                        success: function () {
                            that.pageLoading = !1
                        }
                    })
                    return;
                }else if(!num.exec(this.data.bankcardNumber)){
                    wx.showToast({
                        title: "银行卡号必须全为数字!",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                        success: function () {
                            that.pageLoading = !1
                        }
                    })
                    return;
                }else if(strBin.indexOf(this.data.bankcardNumber.substring(0, 2)) == -1){
                    wx.showToast({
                        title: "银行卡号开头6位不符合规范!",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                        success: function () {
                            that.pageLoading = !1
                        }
                    })
                    return;
                }
            }
                if(reg.test(this.data.judgeIdNumber) === false){
                    wx.showToast({
                        title: "身份证输入不合法!",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                        success: function () {
                            that.pageLoading = !1
                        }
                    })
                    return;
                }
        if(this.data.judgeDeliverytime!=null&&this.data.judgeDeliverytime!=""||
            this.data.judgeDeliverytime2!=null&&this.data.judgeDeliverytime2!=""||
            this.data.judgedeliverytime3!=null&&this.data.judgedeliverytime3!=""||
            this.data.judgedeliverytime4!=null&&this.data.judgedeliverytime4!=""||
            this.data.judgedeliverytime5!=null&&this.data.judgedeliverytime5!=""
        ){
            if(this.data.judgeDeliverytime.length!=10||
                this.data.judgeDeliverytime2.length!=10||
                this.data.judgedeliverytime3.length!=10||
                this.data.judgedeliverytime4.length!=10||
                this.data.judgedeliverytime5.length!=10
            ){
                wx.showToast({
                    title: "日期格式不正确请修改日期!",
                    mask: false,
                    icon: "none",
                    duration: 2000,
                    success: function () {
                        that.pageLoading = !1
                    }
                })
                return;
            }
        }else{
            wx.showToast({
                title: "日期不能为空!",
                mask: false,
                icon: "none",
                duration: 2000,
                success: function () {
                    that.pageLoading = !1
                }
            })
            return;
        }

            if (this.data.judgeMobile == ""||this.data.judgeMobile==null) {
                wx.showToast({
                    title: "请填写手机号码!",
                    mask: false,
                    icon: "none",
                    duration: 2000,
                    success: function () {
                        that.pageLoading = !1
                    }
                })
                return;
            }else if(this.data.judgeIdPositivePhoto==""||this.data.judgeIdPositivePhoto==null){
                    wx.showToast({
                        title: "身份证正面照片不能为空!",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                        success: function () {
                            that.pageLoading = !1
                        }
                    })
                    return;

            }else if(this.data.judgeName==""||this.data.judgeName==null){
                wx.showToast({
                    title: "姓名不能为空!",
                    mask: false,
                    icon: "none",
                    duration: 2000,
                    success: function () {
                        that.pageLoading = !1
                    }
                })
                return;
            }else if(this.data.judgeIdNumber==""||this.data.judgeIdNumber==null){

                wx.showToast({
                    title: "身份证号码不能为空!",
                    mask: false,
                    icon: "none",
                    duration: 2000,
                    success: function () {
                        that.pageLoading = !1
                    }
                })
                return;
            }else if(this.data.judgeIdSex==""||this.data.judgeIdSex==null){
                wx.showToast({
                    title: "性别不能为空!",
                    mask: false,
                    icon: "none",
                    duration: 2000,
                    success: function () {
                        that.pageLoading = !1
                    }
                })
                return;
            }else if(this.data.judgethebackoftheidcardUrl==""||this.data.judgethebackoftheidcardUrl==null){
                wx.showToast({
                    title: "身份证背面照片不能为空!",
                    mask: false,
                    icon: "none",
                    duration: 2000,
                    success: function () {
                        that.pageLoading = !1
                    }
                })
                return;
            }else if(this.data.judgeDeliverytime==""||this.data.judgeDeliverytime==null){
                wx.showToast({
                    title: "身份证有效期开始日期不能为空!",
                    mask: false,
                    icon: "none",
                    duration: 2000,
                    success: function () {
                        that.pageLoading = !1
                    }
                })
                return;
            }else if(this.data.judgeDeliverytime2==""||this.data.judgeDeliverytime2==null){
                wx.showToast({
                    title: "身份证有效期结束日期不能为空!",
                    mask: false,
                    icon: "none",
                    duration: 2000,
                    success: function () {
                        that.pageLoading = !1
                    }
                })
                return;
            }else if(this.data.judgefrontofdriverlicenseUrl==""||this.data.judgefrontofdriverlicenseUrl==null){
                wx.showToast({
                    title: "驾驶证正面照片不能为空!",
                    mask: false,
                    icon: "none",
                    duration: 2000,
                    success: function () {
                        that.pageLoading = !1
                    }
                })
                return;
            }else if(this.data.judgedeliverytime3==""||this.data.judgedeliverytime3==null){
                wx.showToast({
                    title: "首次驾照签发日期不能为空!",
                    mask: false,
                    icon: "none",
                    duration: 2000,
                    success: function () {
                        that.pageLoading = !1
                    }
                })
                return;
            }else if(this.data.judgedeDrivingName==""||this.data.judgedeDrivingName==null){
                wx.showToast({
                    title: "驾驶证类型不能为空!",
                    mask: false,
                    icon: "none",
                    duration: 2000,
                    success: function () {
                        that.pageLoading = !1
                    }
                })
                return;
            }
            else if(this.data.judgedeliverytime4==""||this.data.judgedeliverytime4==null){
                wx.showToast({
                    title: "驾驶证有效开始日期不能为空!",
                    mask: false,
                    icon: "none",
                    duration: 2000,
                    success: function () {
                        that.pageLoading = !1
                    }
                })
                return;
            }else if(this.data.judgedeliverytime5==""||this.data.judgedeliverytime5==null){
                wx.showToast({
                    title: "驾驶证有效结束日期不能为空!",
                    mask: false,
                    icon: "none",
                    duration: 2000,
                    success: function () {
                        that.pageLoading = !1
                    }
                })
                return;
            }
            if(this.data.isshuju2=='是'){
                this.data.isshuju2="1"
            }else{
                this.data.isshuju2="2"
            }
            var options = {
                port: 'driverCreUpd4',
                body: {
                    driverID: this.data.driverID,
                    "name": this.data.judgeName,
                    "mobile": this.data.mobile,
                    "gender": app.sex,
                    "arrTeamID": arrTeamID,
                    "relationType": app.driverType,
                    "idNumber": this.data.judgeIdNumber,
                    "effectiveStartDate":this.data.judgeDeliverytime,
                    "effectiveEndDate":this.data.judgeDeliverytime2,
                    "isEndless":this.data.isshuju2,
                    "idPhotoFileID":this.data.frontofidcardID,
                    "idBackPhotoFileID":this.data.thebackoftheidcardID,
                     "driverLicenseType":s[this.data.judgedeDrivingName],
                     "driverLicenceFirstGetDate":this.data.judgedeliverytime3,
                     "driverLicenceStartDate":this.data.judgedeliverytime4,
                     "driverLicenceExpiryDate":this.data.judgedeliverytime5,
                     "licensePhotoFileID":this.data.frontofdriverlicenseID,
                     "bankcardNumber":this.data.bankcardNumber,
                     //司机危险货物运输从业资格证
                      "supportingDangerousID":this.data.theothersideID,
                      "taxpayerBankCardID":this.data.bankcardID,
                      "desc":this.data.desc
                }
            }
            app.connect(options).then(values => {
                console.log(values)
                if (values.data.body.content != null) {
                    wx.showToast({
                        title: "添加司机成功",
                        mask: false,
                        icon: "success",
                        duration: 2000,
                        success: function () {
                            wx.navigateBack({
                                delta: -1
                            });
                        }

                    })
                } else {
                    wx.showToast({
                        title: values.data.body.desc,
                        mask: false,
                        icon: "none",
                        duration: 2000,
                        success: function () {
                            that.pageLoading = !1
                        }
                    })
                }
            })
        }
    },
    bindMultiPickerColumnChange1: function (e) {
        for(var i=0;i<this.data.multiArray1.length;i++){
            console.log(3)
            for(var j=0;j<this.data.multiArray1[i].length;j++) {
                if (i==0) {
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("年","");
                }else if(i==1){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("月",'')
                }else if(i==2){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("日",'')
                }else if(i==3){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("时",'')
                }else if(i==4){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("分",'')
                }else if(i==5){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("秒",'')
                }
            }
        }
        console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
        var data1 = {
            multiArray1: this.data.multiArray1,
            multiIndex1: this.data.multiIndex1
        };
        data1.multiIndex1 = e.detail.value;
        this.setData(data1);
        console.log(data1)
        this.data.destinationDate=data1.multiArray1[0][data1.multiIndex1[0]]+"-"+data1.multiArray1[1][data1.multiIndex1[1]]+"-"+data1.multiArray1[2][data1.multiIndex1[2]]
        console.log(this.data.destinationDate)
        this.data.deliverytime=null;
        this.data.judgeDeliverytime=this.data.destinationDate
        this.setData({
            deliverytime:this.data.deliverytime
        })


    },
    ontime:function(){
        var myDate = new Date();
        var a=0;
        var b=0;
        var c=0;
        var d=0;
        var e=0;
        for(var i=89;i<parseInt(myDate.getYear());i++){
            a=a+1
        }
        for(var i=0;i<parseInt(myDate.getMonth());i++){
            b=b+1
        }
        for(var i=1;i<parseInt(myDate.getDate());i++) {
            c = c + 1
        }
        for(var i=0;i<parseInt(myDate.getHours());i++){
            d=d+1
        }
        for(var i=0;i<parseInt(myDate.getMinutes());i++){
            e=e+1
        }
        this.data. multiIndex1[0]=a
        this.data. multiIndex1[1]=b
        this.data. multiIndex1[2]=c
        this.data. multiIndex1[3]=d
        this.data. multiIndex1[4]=e
        this.setData({
            multiArray1:this.data.multiArray1,
            multiIndex1:this.data. multiIndex1
        })

    },
    bindMultiPickerColumnChange2: function (e) {
        for(var i=0;i<this.data.multiArray2.length;i++){
            console.log(3)
            for(var j=0;j<this.data.multiArray2[i].length;j++) {
                if (i==0) {
                    this.data.multiArray2[i][j]=this.data.multiArray2[i][j].replace("年","");
                }else if(i==1){
                    this.data.multiArray2[i][j]=this.data.multiArray2[i][j].replace("月",'')
                }else if(i==2){
                    this.data.multiArray2[i][j]=this.data.multiArray2[i][j].replace("日",'')
                }else if(i==3){
                    this.data.multiArray2[i][j]=this.data.multiArray2[i][j].replace("时",'')
                }else if(i==4){
                    this.data.multiArray2[i][j]=this.data.multiArray2[i][j].replace("分",'')
                }else if(i==5){
                    this.data.multiArray2[i][j]=this.data.multiArray2[i][j].replace("秒",'')
                }
            }
        }
        console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
        var data1 = {
            multiArray2: this.data.multiArray2,
            multiIndex2: this.data.multiIndex2
        };
        data1.multiIndex2 = e.detail.value;
        this.setData(data1);
        this.data.destinationDate2=data1.multiArray2[0][data1.multiIndex2[0]]+"-"+data1.multiArray2[1][data1.multiIndex2[1]]+"-"+data1.multiArray2[2][data1.multiIndex2[2]]
        this.data.deliverytime2=null;
        this.data.judgeDeliverytime2=this.data.destinationDate2
        this.setData({
            deliverytime2:this.data.deliverytime2
        })


    },
    ontime2:function(){
        var myDate = new Date();
        var a=0;
        var b=0;
        var c=0;
        var d=0;
        var e=0;
        for(var i=89;i<parseInt(myDate.getYear());i++){
            a=a+1
        }
        for(var i=0;i<parseInt(myDate.getMonth());i++){
            b=b+1
        }
        for(var i=1;i<parseInt(myDate.getDate());i++) {
            c = c + 1
        }
        for(var i=0;i<parseInt(myDate.getHours());i++){
            d=d+1
        }
        for(var i=0;i<parseInt(myDate.getMinutes());i++){
            e=e+1
        }
        this.data. multiIndex2[0]=a
        this.data. multiIndex2[1]=b
        this.data. multiIndex2[2]=c
        this.data. multiIndex2[3]=d
        this.data. multiIndex2[4]=e
        this.setData({
            multiArray2:this.data.multiArray2,
            multiIndex2:this.data. multiIndex2
        })

    },
    bindMultiPickerColumnChange3: function (e) {
        for(var i=0;i<this.data.multiArray3.length;i++){
            console.log(3)
            for(var j=0;j<this.data.multiArray3[i].length;j++) {
                if (i==0) {
                    this.data.multiArray3[i][j]=this.data.multiArray3[i][j].replace("年","");
                }else if(i==1){
                    this.data.multiArray3[i][j]=this.data.multiArray1[i][j].replace("月",'')
                }else if(i==2){
                    this.data.multiArray3[i][j]=this.data.multiArray3[i][j].replace("日",'')
                }else if(i==3){
                    this.data.multiArray3[i][j]=this.data.multiArray3[i][j].replace("时",'')
                }else if(i==4){
                    this.data.multiArray3[i][j]=this.data.multiArray3[i][j].replace("分",'')
                }else if(i==5){
                    this.data.multiArray3[i][j]=this.data.multiArray3[i][j].replace("秒",'')
                }
            }
        }
        console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
        var data1 = {
            multiArray3: this.data.multiArray3,
            multiIndex3: this.data.multiIndex3
        };
        data1.multiIndex3 = e.detail.value;
        this.setData(data1);
        this.data.destinationDate3=data1.multiArray3[0][data1.multiIndex3[0]]+"-"+data1.multiArray3[1][data1.multiIndex3[1]]+"-"+data1.multiArray3[2][data1.multiIndex3[2]]
        this.data.deliverytime3=null;
        this.data.judgedeliverytime3=this.data.destinationDate3
        this.setData({
            deliverytime3:this.data.deliverytime3
        })


    },
    ontime3:function(){
        var myDate = new Date();
        var a=0;
        var b=0;
        var c=0;
        var d=0;
        var e=0;
        for(var i=89;i<parseInt(myDate.getYear());i++){
            a=a+1
        }
        for(var i=0;i<parseInt(myDate.getMonth());i++){
            b=b+1
        }
        for(var i=1;i<parseInt(myDate.getDate());i++) {
            c = c + 1
        }
        for(var i=0;i<parseInt(myDate.getHours());i++){
            d=d+1
        }
        for(var i=0;i<parseInt(myDate.getMinutes());i++){
            e=e+1
        }
        this.data. multiIndex3[0]=a
        this.data. multiIndex3[1]=b
        this.data. multiIndex3[2]=c
        this.data. multiIndex3[3]=d
        this.data. multiIndex3[4]=e
        this.setData({
            multiArray3:this.data.multiArray3,
            multiIndex3:this.data. multiIndex3
        })

    },
    bindMultiPickerColumnChange4: function (e) {
        for(var i=0;i<this.data.multiArray4.length;i++){
            console.log(3)
            for(var j=0;j<this.data.multiArray4[i].length;j++) {
                if (i==0) {
                    this.data.multiArray4[i][j]=this.data.multiArray4[i][j].replace("年","");
                }else if(i==1){
                    this.data.multiArray4[i][j]=this.data.multiArray4[i][j].replace("月",'')
                }else if(i==2){
                    this.data.multiArray4[i][j]=this.data.multiArray4[i][j].replace("日",'')
                }else if(i==3){
                    this.data.multiArray4[i][j]=this.data.multiArray4[i][j].replace("时",'')
                }else if(i==4){
                    this.data.multiArray4[i][j]=this.data.multiArray4[i][j].replace("分",'')
                }else if(i==5){
                    this.data.multiArray4[i][j]=this.data.multiArray4[i][j].replace("秒",'')
                }
            }
        }
        console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
        var data1 = {
            multiArray4: this.data.multiArray4,
            multiIndex4: this.data.multiIndex4
        };
        data1.multiIndex4 = e.detail.value;
        this.setData(data1);
        this.data.destinationDate4=data1.multiArray4[0][data1.multiIndex4[0]]+"-"+data1.multiArray4[1][data1.multiIndex4[1]]+"-"+data1.multiArray4[2][data1.multiIndex4[2]]
        this.data.deliverytime4=null;
        this.data.judgedeliverytime4=this.data.destinationDate4
        this.setData({
            deliverytime4:this.data.deliverytime4
        })


    },
    ontime4:function(){
        var myDate = new Date();
        var a=0;
        var b=0;
        var c=0;
        var d=0;
        var e=0;
        for(var i=89;i<parseInt(myDate.getYear());i++){
            a=a+1
        }
        for(var i=0;i<parseInt(myDate.getMonth());i++){
            b=b+1
        }
        for(var i=1;i<parseInt(myDate.getDate());i++) {
            c = c + 1
        }
        for(var i=0;i<parseInt(myDate.getHours());i++){
            d=d+1
        }
        for(var i=0;i<parseInt(myDate.getMinutes());i++){
            e=e+1
        }
        this.data. multiIndex4[0]=a
        this.data. multiIndex4[1]=b
        this.data. multiIndex4[2]=c
        this.data. multiIndex4[3]=d
        this.data. multiIndex4[4]=e
        this.setData({
            multiArray4:this.data.multiArray4,
            multiIndex4:this.data. multiIndex4
        })

    },
    bindMultiPickerColumnChange5: function (e) {
        for(var i=0;i<this.data.multiArray5.length;i++){
            console.log(3)
            for(var j=0;j<this.data.multiArray5[i].length;j++) {
                if (i==0) {
                    this.data.multiArray5[i][j]=this.data.multiArray5[i][j].replace("年","");
                }else if(i==1){
                    this.data.multiArray5[i][j]=this.data.multiArray5[i][j].replace("月",'')
                }else if(i==2){
                    this.data.multiArray5[i][j]=this.data.multiArray5[i][j].replace("日",'')
                }else if(i==3){
                    this.data.multiArray5[i][j]=this.data.multiArray5[i][j].replace("时",'')
                }else if(i==4){
                    this.data.multiArray5[i][j]=this.data.multiArray5[i][j].replace("分",'')
                }else if(i==5){
                    this.data.multiArray5[i][j]=this.data.multiArray5[i][j].replace("秒",'')
                }
            }
        }
        console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
        var data1 = {
            multiArray5: this.data.multiArray5,
            multiIndex5: this.data.multiIndex5
        };
        data1.multiIndex5 = e.detail.value;
        this.setData(data1);
        this.data.destinationDate5=data1.multiArray5[0][data1.multiIndex5[0]]+"-"+data1.multiArray5[1][data1.multiIndex5[1]]+"-"+data1.multiArray5[2][data1.multiIndex5[2]]
        this.data.deliverytime5=null;
        this.data.judgedeliverytime5=this.data.destinationDate5
        this.setData({
            deliverytime5:this.data.deliverytime5
        })


    },
    ontime5:function(){
        var myDate = new Date();
        var a=0;
        var b=0;
        var c=0;
        var d=0;
        var e=0;
        for(var i=89;i<parseInt(myDate.getYear());i++){
            a=a+1
        }
        for(var i=0;i<parseInt(myDate.getMonth());i++){
            b=b+1
        }
        for(var i=1;i<parseInt(myDate.getDate());i++) {
            c = c + 1
        }
        for(var i=0;i<parseInt(myDate.getHours());i++){
            d=d+1
        }
        for(var i=0;i<parseInt(myDate.getMinutes());i++){
            e=e+1
        }
        this.data. multiIndex5[0]=a
        this.data. multiIndex5[1]=b
        this.data. multiIndex5[2]=c
        this.data. multiIndex5[3]=d
        this.data. multiIndex5[4]=e
        this.setData({
            multiArray5:this.data.multiArray5,
            multiIndex5:this.data. multiIndex5
        })

    },
})