var app = getApp();
Page({
    data: {
        name: '',
    },
    onLoad: function () {
        var body;
        var car;
        var ship;
        if (app.data.sex_name == "男") {
            body = {
                car: "true",
                ship: "false"
            }
        } else {
            body = {
                car: "false",
                ship: "true"
            }
        }
        this.setData({
            save:app.globalData[11],
            shuju: body
        })
    },
    onShow: function () {
        var body;
        var car;
        var ship;
        console.log(app.sex_name)
        if (app.sex_name == "男") {
            body = {
                car: "true",
                ship: "false"
            }
        } else if (app.sex_name == "女") {
            body = {
                car: "false",
                ship: "true"
            }
        }
        this.setData({
            shuju: body
        })
    },
    mySelect: function (e) {
        console.log(e.currentTarget.dataset.name)
        this.data.name = e.currentTarget.dataset.name
        var body;
        var car;
        var ship;
        console.log(this.data.name)
        if (this.data.name == "car") {
            app.sex = 1;
            app.sex_name = "男";
            body = {
                car: "true",
                ship: "false"
            }
        } else if (this.data.name == "ship") {
            app.sex = 2;
            app.sex_name = "女";
            body = {
                car: "false",
                ship: "true"
            }
        }
        console.log(body.car)
        this.setData({
            shuju: body
        })
        wx.navigateBack({
            delta: -1
        });
    }
})