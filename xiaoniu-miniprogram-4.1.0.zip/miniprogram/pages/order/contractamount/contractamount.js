Page({
    onLoad:function (e) {
        var allmoney=e.allmoney
        this.setData({
            allmoney:allmoney
        })
    }
})