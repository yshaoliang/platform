var app = getApp();
Page({
    data:{
        index:0,
        alldata:[],
        quality:0,
        numbers:0,
        company:"",
        company1:""
    },
    /*下拉刷新*/
    onPullDownRefresh() {
        this.data.index=0
        this.data.alldata.splice(0, this.data.alldata.length);
        this.onLoad().then(values => {
                    wx.stopPullDownRefresh()
        })
    },
    onReachBottom: function () {
        var that = this;
        that.data.alldata[1].splice(0,that.data.alldata[1].length)
        that.data.quality=0
        that.data.numbers=0
        that.data.index=that.data.index+1
        var options = {
            port: 'orderListQry',
            body: {
                "pageIndex": that.data.index,
                "pageSize": 10,
                "graphicCode": null,
                "sessionGraphicCode": null
            }
        }
        let prom1 = new Promise(function (resolve, reject) {
            app.connect(options).then(values => {
                for(var i=0;i<values.data.body.content.arrOrderAbstractInfo.length;i++){
                    values.data.body.content.arrOrderAbstractInfo[i].consignorInfo.addressInfo.cityShortName=app.oncityNam(values.data.body.content.arrOrderAbstractInfo[i].consignorInfo.addressInfo.cityShortName)
                    values.data.body.content.arrOrderAbstractInfo[i].consigneeInfo.addressInfo.cityShortName=app.oncityNam(values.data.body.content.arrOrderAbstractInfo[i].consigneeInfo.addressInfo.cityShortName)
                }
                console.log(values.data.body.content.arrOrderAbstractInfo)
                if(values.data.body.content.arrOrderAbstractInfo.length==0){
                    that.setData({
                        load1:true,
                        load:true
                    })
                }
                for(var i=0;i<values.data.body.content.arrOrderAbstractInfo.length;i++){
                    that.data.alldata[0].push(values.data.body.content.arrOrderAbstractInfo[i])
                }
                for(var i=0;i<that.data.alldata[0].length;i++){
                    that.data.quality=0
                    that.data.numbers=0
                    that.data.company=""
                    that.data.company1=""
                    for(var j=0;j<that.data.alldata[0][i].arrCargoInfo.length;j++){
                        for(var h=0;h<that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo.length;h++){
                            if(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].amountBizType==2){
                                if(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volume!=0){
                                    console.log(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volume)
                                    if(that.data.company==""){
                                        that.data.company=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volumeUnit
                                    }else{
                                        if(that.data.company!=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volumeUnit){
                                            that.data.company="单位"
                                        }
                                    }
                                    that.data.quality=Number(that.data.quality)+Number(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volume)
                                }
                                if(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weight!=0){
                                    if(that.data.company==""){
                                        that.data.company=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weightUnit
                                    }else{
                                        if(that.data.company!=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weightUnit){
                                            that.data.company="单位"
                                        }
                                    }
                                    console.log(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weight)
                                    that.data.quality=Number(that.data.quality)+Number(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weight)
                                }
                                if(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].quantity!=0){
                                    if(that.data.company1==""){
                                        that.data.company1=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].quantityUnit
                                    }else{
                                        if(that.data.company1!=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].quantityUnit){
                                            that.data.company1="单位"
                                        }
                                    }
                                    that.data.numbers=Number(that.data.numbers)+Number(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].quantity)
                                }
                            }
                        }

                    }
                    that.data.alldata[1].push([
                        {
                            company:that.data.company,
                            company1:that.data.company1,
                            quality:that.data.quality,
                            numbers: that.data.numbers
                        }
                    ])
                }
                console.log(that.data.alldata)

                that.setData({
                    shuju: that.data.alldata,
                    load:false
                })
                resolve(values);

            })
        });
        return prom1;

    },

    onLoad: function () {

        app.loads()
        console.log(app.globalData[13])
        this.setData({
            load1:false,
            headurl:app.globalData[13],
            to:app.globalData[14],
        })
        var that = this;

        var options = {
            port: 'orderListQry',
            body: {
                "pageIndex": this.data.index,
                "pageSize": 10,
                "graphicCode": null,
                "sessionGraphicCode": null
            }
        }
        let prom1 = new Promise(function (resolve, reject) {
            app.connect(options).then(values => {
                wx.hideLoading()
                console.log(values)
                for(var i=0;i<values.data.body.content.arrOrderAbstractInfo.length;i++){
                    values.data.body.content.arrOrderAbstractInfo[i].consignorInfo.addressInfo.cityShortName=app.oncityNam(values.data.body.content.arrOrderAbstractInfo[i].consignorInfo.addressInfo.cityShortName)
                    values.data.body.content.arrOrderAbstractInfo[i].consigneeInfo.addressInfo.cityShortName=app.oncityNam(values.data.body.content.arrOrderAbstractInfo[i].consigneeInfo.addressInfo.cityShortName)
                }
                that.data.alldata.push(values.data.body.content.arrOrderAbstractInfo)
                if(values.data.body.content.arrOrderAbstractInfo.length==0){
                    wx.showModal({
                        title:"提示",
                        content:"订单为空",
                        showCancel:false,
                        success:function (res) {
                            if (res.confirm){
                                wx.navigateBack({
                                    delta: -1
                                });
                            }
                        },
                        //退出失败，可能一些原因导致
                        fail:function (res) {
                            wx.showToast({
                                title:"退出失败,请反馈",
                                duration:1500,
                            });
                        },
                    });
                }
                that.data.alldata.push([])
                for(var i=0;i<that.data.alldata[0].length;i++){
                    that.data.quality=0
                    that.data.numbers=0
                    that.data.company=""
                    that.data.company1=""
                    for(var j=0;j<that.data.alldata[0][i].arrCargoInfo.length;j++){
                        for(var h=0;h<that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo.length;h++){
                            if(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].amountBizType==2){
                                if(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volume!=0){
                                    console.log(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volume)
                                    if(that.data.company==""){
                                        that.data.company=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volumeUnit
                                    }else{
                                        if(that.data.company!=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volumeUnit){
                                            that.data.company="单位"
                                        }
                                    }
                                    that.data.quality=Number(that.data.quality)+Number(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volume)
                                }
                                if(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weight!=0){
                                    console.log(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weight)
                                    if(that.data.company==""){
                                        that.data.company=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weightUnit
                                    }else{
                                        console.log(that.data.company)
                                        console.log(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weightUnit)
                                        if(that.data.company!=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weightUnit){
                                            that.data.company="单位"
                                        }
                                    }
                                    that.data.quality=Number(that.data.quality)+Number(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weight)
                                }
                                if(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].quantity!=0){
                                    if(that.data.company1==""){
                                        that.data.company1=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].quantityUnit
                                    }else{
                                        if(that.data.company1!=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].quantityUnit){
                                            that.data.company1="单位"
                                        }
                                    }
                                    that.data.numbers=Number(that.data.numbers)+Number(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].quantity)
                                }
                            }
                        }

                    }
                    that.data.alldata[1].push([
                        {
                            company:that.data.company,
                            company1:that.data.company1,
                            quality:that.data.quality,
                            numbers: that.data.numbers
                        }
                    ])

                }

                console.log(that.data.alldata)
                console.log(values.data.body.content.arrOrderAbstractInfo)
                that.setData({
                    shuju: that.data.alldata
                })

                resolve(values)

            })
        });
        return prom1;
    },

    tapName: function (e) {
        if(app.orderdata["type"]!="speed"){
            if (!this.pageLoading) {
                this.pageLoading = !0;
                app.orderID = e.currentTarget.dataset.name;
                var s=e.currentTarget.dataset.id.split(",")
                app.orderdata["company"]=s[0]
                app.orderdata["company1"]=s[1]
                wx.navigateTo({
                    url: '../orderDtlQry/orderDtlQry'
                })
            }
        }else{
            console.log(e.currentTarget.dataset.name)
            app.orderID = e.currentTarget.dataset.name;
            wx.navigateTo({
                url: '../../dispatchlist/list/list',
            })

        }

    },
    onShow:function () {
        this.pageLoading = !1
    }


})