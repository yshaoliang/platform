var app = getApp();
Page({
  data: {
    cargoinfo: '',
    volumeStar:'',
    quantityStar:'',
    amountStowage:'',
    weighStowage:'',
    volumeStowage:'',
    quantityStowage:'',
    amountTotal:'',
    cargoinfoIndex:'',
  },
 
  onLoad: function (option) {
    var that = this
    var cargoinfos = JSON.parse(option.cargoinfo)
    var cargoinfoIndexs = option.cargoinfoIndex
    let quantityStarXingShow = {}
    let volumeStarShow = {}
    let amountStowages ={}
    let amountTotals = {}
    if (null != cargoinfos.valuationMode && cargoinfos.valuationMode == 1131020){
      quantityStarXingShow = false
    }else{
      quantityStarXingShow = true
    }
    if (null != cargoinfos.valuationMode && cargoinfos.valuationMode == 1131010) {
      volumeStarShow = false
    } else {
      volumeStarShow = true
    }
    for (var i = 0; i < cargoinfos.arrAmountInfo.length; i++) {
      if (6 == cargoinfos.arrAmountInfo[i].amountBizType) {
        amountStowages = cargoinfos.arrAmountInfo[i];
      }
    }
    for (var i = 0; i < cargoinfos.arrAmountInfo.length; i++) {
      if (5 == cargoinfos.arrAmountInfo[i].amountBizType) {
        amountTotals = cargoinfos.arrAmountInfo[i];
      }
    }

    this.setData({ 
      quantityStar:quantityStarXingShow,
      volumeStar:volumeStarShow,
      cargoinfo:cargoinfos,
      amountStowage: amountStowages,
      weighStowage: amountStowages.weight,
      volumeStowage: amountStowages.volume, 
      quantityStowage: amountStowages.quantity,
      amountTotal: amountTotals,
      cargoinfoIndex: cargoinfoIndexs
    }) 
   
  },
  weighpayment: function (e) {
    this.data.weighStowage= e.detail.value
  },
  volumepayment: function (e) {
    this.data.volumeStowage= e.detail.value
  },
  quantitypayment: function (e) {
    this.data.quantityStowage = e.detail.value
  },
  ongenerate:function(){
    var that = this;
    if (!that.pageLoading) {
      that.pageLoading = !0;
    }
    if (this.data.weighStowage == "") {
       wx.showToast({
        title: "请填写重量！",
        mask: false,
        icon: "none",
        duration: 2000,
        success: function () {
          that.pageLoading = !1
        }
      })
      return
    } else if (null != this.data.cargoinfo.valuationMode 
      && this.data.cargoinfo.valuationMode == 1131010
      && this.data.volumeStowage==""){
      wx.showToast({
        title: "请填写体积！",
        mask: false,
        icon: "none",
        duration: 2000,
        success: function () {
          that.pageLoading = !1
        }
      })
      return
    } else if (null != this.data.cargoinfo.valuationMode
      && this.data.cargoinfo.valuationMode == 1131020
      && this.data.quantityStowage == "") {
      wx.showToast({
        title: "请填写件数！",
        mask: false,
        icon: "none",
        duration: 2000,
        success: function () {
          that.pageLoading = !1
        }
      })
      return
    } else if (parseInt(this.data.weighStowage) >parseInt(this.data.amountTotal.weight)){
      wx.showToast({
        title: "重量不能大于配重量！",
        mask: false,
        icon: "none",
        duration: 2000,
        success: function () {
          that.pageLoading = !1
        }
      })
      return
    } else if ("" != this.data.volumeStowage){
      if (parseInt(this.data.volumeStowage) > parseInt(this.data.amountTotal.volume)){
        wx.showToast({
          title: "体积不能大于配重量！",
          mask: false,
          icon: "none",
          duration: 2000,
          success: function () {
            that.pageLoading = !1
          }
        })
        return
      }
    } else if ("" != this.data.quantityStowage){
      if (parseInt(this.data.quantityStowage) > parseInt(this.data.amountTotal.quantity)){
        wx.showToast({
          title: "数量不能大于配重量！",
          mask: false,
          icon: "none",
          duration: 2000,
          success: function () {
            that.pageLoading = !1
          }
        })
        return
      }
    }
    this.data.amountStowage.weight = this.data.weighStowage
    this.data.amountStowage.volume = this.data.volumeStowage
    this.data.amountStowage.quantity = this.data.quantityStowage
    
    var pages = getCurrentPages();
    var currPage = pages[pages.length - 1];  //当前页面
    var prevPage = pages[pages.length - 2]; //上一个页面
      //直接调用上一个页面的setData()方法，把数据存到上一个页面中去
      prevPage.setData({
        cargoindex: this.data.cargoinfoIndex,
        amountStowage: this.data.amountStowage
      })
      wx.navigateBack();
      console.log(this.data.amountStowage)
  }
})