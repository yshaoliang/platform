var app=getApp();
Page({

onload:function () {
    this.setData({
        all:app.appALL,
    })
}

})