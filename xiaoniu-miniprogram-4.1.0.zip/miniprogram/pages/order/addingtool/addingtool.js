var app = getApp();
var publish = require('../../public_util/publishData');

Page({
    data: {
        numbers: '',
        numbers1: '',
        size: '',
        carrier: '',
        approvedtonnage: '',
        name: '',
        mobile: '',
        inputunmber: '',
        i: 0,
        arr: [{provinces: '', city: ''}],
        arrs: [{cityCode: '', cityName: ''}],
        vehicleID:'',
        owner:'',
        fileID:"",
        sCode:[],
        licenseID:"",
        multiArray1: [publish.years,publish.mouths,publish.days,publish.houvers,publish.branchs],
        multiIndex1: ["", "", "","",""],
        access_token:"",
        base64Data:"",
        identificationcode:"",
        natureofusage:"",
        headSrc:"",
        transportno:"",
        licenseUrl:"",
        positiveID:"",
        theOthersideID:"",
        positiveUrl:"",
        theOthersideUrl:"",
        agreementID:"",
        agreementUrl:"",
        trailerPassID:"",
        transportID:"",
        certificateID:"",
        certificateUrl:"",
        engine:""

    },
    /*下拉刷新*/
    onPullDownRefresh() {
        wx.stopPullDownRefresh()
    },
    /*给页面引外部页面做判断*/
    onvehicletype: function () {
        this.data.inputunmber=undefined
        this.data.numbers = 'false',
            this.setData({
                number3: "false",
                number4: "false",
                number1: "false",
                number: this.data.numbers

            })
        wx.navigateTo({
            url: '../vehicletype/vehicletype',
        })
    },
    onPersonal: function () {
       /* this.data.numbers = 'false',
            this.setData({
                header: "",
                stringSizes: "",
                number3: "false",
                number4: "false",
                number1: "false",
                number: this.data.numbers
            })*/
        wx.navigateTo({
            url: '../personaltype/personaltype',
        })
    },
    /*车辆类型判断*/
    onShipnumber: function () {
        this.data.inputunmber=undefined
        console.log(app.vehicletype_name);
        if (app.vehicletype_name == "车辆" || app.vehicletype_name == undefined) {
            console.log(app.vehicletype_name);
            this.data.size = ""
            this.setData({
                vehiclelicenseplate:"",
                number3: "false",
                number4: "false",
                carboolean: true,
                header:"",
                stringSizes: ""
            })
            if (this.data.numbers == "" || this.data.numbers == "false") {
                this.data.numbers = 'true'
            } else if (this.data.numbers == "true") {
                this.data.numbers = 'false'
            }
            this.setData({
                number1: "false",
                number: this.data.numbers
            })
        }
        if (app.vehicletype_name == "船舶") {
            console.log(app.vehicletype_name);
            this.setData({
                carboolean: false,
            })
        }
    },
    /*页面加载数据*/
    onLoad: function (e) {
        console.log(app.loadlength)
        console.log(app.carriertype)
        var that=this;
        var url="https://aip.baidubce.com/oauth/2.0/token";
        var datas={
            grant_type: "client_credentials",
            client_id:"XG8eM7GVGLuXepax8kczamzf",
            client_secret:"MGWGt1d9zZ5hkWPjffn2y5EjtjO4ZNDw"
        }
            wx.request({
                data: datas,
                header: {'content-type': 'application/x-www-form-urlencoded'},
                url: url,
                method: 'POST',
                success: function (res) {
                    console.log(res)
                    that.data.access_token=res.data.access_token
                },
                fail: function (event) {
                    console.log(event)
                },
            })

        app.vehicletype_name="车辆"
        console.log(e.vehicleID)
        this.data.vehicleID=e.vehicleID
        if(undefined!=e.vehicleID) {
            wx.setNavigationBarTitle({
                title:"修改载具信息"
            })
            app.navigationarea=null
            console.log(888)
            var options = {
                port: 'vehicleDtlQry3',
                body: {
                    "vehicleID": e.vehicleID,
                }
            }
        app.connect(options).then(values => {
            console.log(values)
            if(values.data.body.content.vehicleInfo.carInfo2!=null){
               app.data.loadlength="车长",
                 app.data.carriertype="车型",
                   app.vehicletype_name="车辆"
                this.setData({
                    shuju: app.vehicletype_name,
                    carboolean:true,
                    carriertype:"车型",
                    loadlength:'车长'
                })
                this.data.inputunmber=values.data.body.content.vehicleInfo.carInfo2.vehicleCode
                this.data.owner=values.data.body.content.vehicleInfo.owner
                this.data.name=values.data.body.content.vehicleInfo.linkmanInfo.name
                this.data.mobile=values.data.body.content.vehicleInfo.linkmanInfo.mobile
                app.selection=""
                app.selection=values.data.body.content.vehicleInfo.teamName
                if(values.data.body.content.vehicleInfo.defaultDriverInfo!=null) {
                    app.driverID=""
                    app.driverID = values.data.body.content.vehicleInfo.defaultDriverInfo.driverID
                }
                app.shiptype=""
                app.shiptype=values.data.body.content.vehicleInfo.carInfo2.typeID
                app.length=""
                app.length=values.data.body.content.vehicleInfo.carInfo2.lengthID
                this.data.approvedtonnage=values.data.body.content.vehicleInfo.carInfo2.tonnage
                this.data.arrs=values.data.body.content.vehicleInfo.arrCityInfo
                if(values.data.body.content.vehicleInfo.defaultDriverInfo!=null) {
                    app.orderdata["teamID"]=""
                    app.orderdata["teamID"] = values.data.body.content.vehicleInfo.defaultDriverInfo.teamID
                }
                this.data.fileID=values.data.body.content.vehicleInfo.roadTransportBusinessLicensePhotoID
            }else{
                app.data.loadlength="船区",
                    app.data.carriertype="船型",
                    app.vehicletype_name="船舶"
                console.log(app.vehicletype_nam)
                this.setData({
                    carboolean:false,
                    carriertype:"船型",
                    shuju: app.vehicletype_name,
                    loadlength:'船区'
                })
                this.data.inputunmber=values.data.body.content.vehicleInfo.shipInfo.vehicleCode
                this.data.owner=values.data.body.content.vehicleInfo.owner
                this.data.name=values.data.body.content.vehicleInfo.linkmanInfo.name
                this.data.mobile=values.data.body.content.vehicleInfo.linkmanInfo.mobile
                app.selection=""
                app.selection=values.data.body.content.vehicleInfo.teamName
                if(values.data.body.content.vehicleInfo.defaultDriverInfo!=null){
                    app.driverID=""
                    app.driverID=values.data.body.content.vehicleInfo.defaultDriverInfo.driverID
                }
                app.shiptype=""
                app.shiptype=values.data.body.content.vehicleInfo.shipInfo.typeID
                app.length=""
                app.length=values.data.body.content.vehicleInfo.shipInfo.zoneID
                this.data.approvedtonnage=values.data.body.content.vehicleInfo.shipInfo.tonnage
                this.data.arrs=values.data.body.content.vehicleInfo.arrCityInfo
                if(values.data.body.content.vehicleInfo.defaultDriverInfo!=null){
                    app.orderdata["teamID"]=values.data.body.content.vehicleInfo.defaultDriverInfo.teamID
                }
                this.data.fileID=values.data.body.content.vehicleInfo.roadTransportBusinessLicensePhotoID
            }
            this.setData({
                alldata:values.data.body.content.vehicleInfo
            })
        })
        }
        this.setData({
            forward:app.globalData[48],
            add:app.globalData[21],
            arr: this.data.arr,
            loadlength: app.loadlength,
            carriertype: app.carriertype,
            carboolean: 'true',
            shuju: app.data.vehicletype_name,
            personal:app.data.personal_name
        })
            this.data.inputunmber=undefined
            app.shiptype=undefined
            app.length=undefined
    },
    /*页面数据加载*/
    onShow: function () {
        console.log(app.vehicletype_name)
        this.pageLoading = !1
        if(app.vehicletype_name=="车辆"){
            app.data.loadlength="车长"
             app.data.carriertype="车型"
            this.setData({
                /*header:this.data.inputunmber,*/
                carboolean:true
            })

        }else{
            app.data.loadlength="船区"
            app.data.carriertype="船型"
            this.setData({
                carboolean:false
            })
        }
        this.setData({
            album:app.globalData[50],
            navigationarea: app.navigationarea,
            driverNames: app.driverName,
            loadlength: app.data.loadlength,
            carriertype: app.data.carriertype,
            lengthValue: app.lengthValue,
            carmoderlName: app.carmoderlName,
            shipName: app.shipName,
            shiptype: app.shiptype,
            tran: app.selection,
            shuju: app.vehicletype_name,
            personal:app.personal_name

        })
    },
    /*外部引用页面事件*/
    onChoice: function (e) {
        this.data.inputunmber = e.currentTarget.dataset.name
        this.setData({
            carboolean:true,
            header: e.currentTarget.dataset.name
        })
        this.data.numbers = 'false'
        this.data.numbers1 = "true"
        this.setData({
            number: this.data.numbers,
            number1: this.data.numbers1
        })

    },
    /*外部引用页面事件*/
    onMove: function () {
        this.data.size = this.data.size.substring(0, this.data.size.length - 1)
        this.setData({
            stringSizes: this.data.size
        })
    },
    /*外部引用页面事件*/
    onReturn: function () {
        this.setData({
            header: "",
            stringSizes: "",
            number: true,
            number1: false
        })
    },
    /*外部引用页面事件*/
    onSize: function (e) {
            this.data.size = this.data.size + e.currentTarget.dataset.name
            console.log(e)
        this.data.inputunmber = this.data.inputunmber + e.currentTarget.dataset.name
        console.log(this.data.size)
        if(this.data.size.length<7) {
            this.setData({
                carboolean:true,
                stringSizes: this.data.size
            })
        }
            if (this.data.size.length == "6") {
            this.setData({
                carboolean:true,
                number1: "false"
            })
            }


    },
    /*城市*/
    dianji: function (e) {
        app.newschedulingindex = e.currentTarget.dataset.name
        this.data.arrs[app.newschedulingindex] = {cityCode: '', cityName: ''}
        this.data.arr[app.newschedulingindex] = {provinces: '', city: ''}
        this.setData({
            number: 'false',
            number4: "true",
        })
    },
    /*页面引用判断*/
    dianji1: function () {
        this.setData({
            number4: "true",
            number3: "false",
        })
    },
    /*外部页面事件*/
    onAcity: function (e) {
        var s = [[ '东城区', '西城区', '朝阳区', '丰台区', '石景山区', '海区', '门头沟去', '房山区', '通州区', '顺义区', '昌平区', '大兴区', '怀柔区', '平谷区', '密云区', '延庆区'],
            [ '和平区', '河东区', '河西区', '南开区', '河北区', '红桥区', '东丽区', '西青区', '津南区', '北辰区', '武清区', '宝坻区', '滨海新区', '宁河区', '静海区', '蓟州区'],
            [ '石家庄市', '唐山市', '秦皇岛市', '邯郸市', '邢台市', '保定市', '张家口市', '承德市', '沧州市', '廊坊市', '衡水市', '定州市', '辛集市'],
            [ '太原市', '大同市', '阳泉市', '长治市', '晋城市', '朔州市', '晋中市', '远城市', '忻州市', '临汾市', '吕梁市'],
            ['呼和浩特市', '包头市', '乌海市', '赤峰市', '通辽市', '鄂尔多斯市', '呼伦贝尔市', '巴彦淖尔是', '乌兰察布市', '兴安盟', '锡林郭勒盟', '阿拉善盟'],
            [ '沈阳市', '大连市', '鞍山市', '抚顺市', '本溪市', '丹东市', '锦州市', '营口市', '阜新市', '辽阳市', '盘锦市', '铁岭市', '朝阳市', '葫芦岛市'],
            [ '长春市', '吉林市', '四平市', '辽源市', '通化市', '白山市', '松原市', '白城市', '延边朝鲜族自治州'],
            [ '哈尔滨市', '齐齐哈尔市', '鸡西市', '鹤岗市', '双鸭山市', '大庆市', '伊春市', '佳木斯市', '七台河市', '牡丹江市', '黑河市', '绥化市', '大兴安岭地区'],
            [ '黄浦区', '徐浦区', '长宁区', '静安区', '普陀区', '虹口区', '杨浦区', '闵行区', '宝山区', '嘉定区', '浦东新区', '金山区', '松江区', '青浦区', '奉贤区', '崇明区'],
            [ '南京市', '无锡市', '徐州市', '常州市', '苏州市', '南通市', '连云港市', '淮安市', '盐城市', '扬州市', '镇江市', '泰州市', '宿迁市'],
            [ '杭州市', '宁波市', '温州市', '嘉兴市', '湖州市', '绍兴市', '金华市', '衢州市', '舟山市', '台州市', '丽水市'],
            [ '合肥市', '芜湖市', '蚌埠市', '淮南市', '马鞍山市', '淮北市', '铜陵市', '安庆市', '黄山市', '滁州市', '阜阳市', '宿州市', '六安市', '毫州市', '池州市', '宣城市'],
            ['福州市', '厦门市', '莆田市', '三明市', '泉州市', '漳州市', '南平市', '龙岩市', '宁德市'],
            [ '南昌市', '景德镇市', '萍乡市', '九江市', '新余市', '鹰潭市', '赣州市', '吉安市', '宜春市', '抚州市', '上饶市'],
            [ '济南市', '青岛市', '淄博市', '枣庄市', '东营市', '烟台市', '潍坊市', '济宁市', '泰安市', '威海市', '日照市', '莱芜市', '临沂市', '德州市', '聊城市', '滨州市','菏泽市'],
            [ '郑州市', '开封市', '洛阳市', '平顶山市', '安阳市', '鹤壁市', '新乡市', '焦作市', '濮阳市', '许昌市', '漯河市', '三门峡市', '南阳市', '商丘市', '信阳市', '周口市','驻马店市'],
            [ '武汉市', '黄石市', '十堰市', '宜昌市', '襄阳市', '鄂州市', '荆门市', '孝感市', '荆州市', '黄冈市', '咸宁市', '随州市', '恩施土家族苗族自治州', '仙桃市', '潜江市', '天门市','神农架林区'],
            [ '长沙市', '株洲市', '湘潭市', '衡阳市', '邵阳市', '岳阳市', '常德市', '张家界市', '益阳市', '郴州市', '永州市', '怀化市', '娄底市', '湘西土家族'],
            [ '广州市', '韶关市', '深圳市', '珠海市', '汕头市', '佛山市', '江门市', '湛江市', '茂名市', '肇庆市', '惠州市', '梅州市', '汕尾市', '河源市', '阳江市', '清远市','东莞市','中山市','潮州市','揭阳市','云浮市'],
            [ '南宁市', '柳州市', '桂林市', '梧州市', '北海市', '防城港市', '钦州市', '贵港市', '玉林市', '百色市', '贺州市', '河池市', '来宾市', '崇左市'],
            [ '海口市', '三亚市', '三沙市', '儋州市', '五指山市', '琼海市', '文昌市', '万宁市', '东方市', '定安县', '屯昌县', '澄迈县', '临高县', '白沙黎族自治县', '昌江黎族自治县', '乐东黎族自治县','陵水黎族自治县','保亭黎族苗族自治县','琼中黎族苗族自治县'],
            [ '万州市', '涪陵区', '渝中区', '大渡口区', '江北区', '沙坪坝区', '九龙坡区', '南岸区', '北碚区', '綦江区', '大足区', '渝北区', '巴南区', '黔江区', '长寿区', '江津区','合川区','永川区','南川区','璧山区','铜梁区','潼南区','荣昌区','开州区','县'],
            [ '成都市', '自贡市', '攀枝花市', '泸州市', '德阳市', '绵阳市', '广元市', '遂宁市', '内江市', '乐山市', '南充市', '眉山市', '宜宾市', '广安市', '达州市', '雅安市','巴中市','资阳市','阿坝藏族羌族自治州','甘孜藏族自治州','凉山彝族自治州'],
            [ '贵阳市', '六盘水市', '遵义市', '安顺市', '毕节市', '铜仁市', '黔西南布依族苗族自治州', '黔东南苗族侗族自治州', '黔南布依族苗族自治州'],
            [ '昆明市', '曲靖市', '玉溪市', '保山市', '昭通市', '丽江市', '普洱市', '临沧市', '楚雄彝族自治州', '红河哈尼族彝族自治州', '文山壮族苗族自治州', '西双版纳傣族自治州', '大理白族自治州', '德宏傣族景颇族自治州', '怒江傈僳族自治州'],
            [ '拉萨市', '日喀则市', '昌都市', '林芝市', '山南市', '那曲地区', '阿里地区'],
            [ '西安市', '铜川市', '宝鸡市', '咸阳市', '渭南市', '延安市', '汉中市', '榆林市', '安康市', '商洛市'],
            ['兰州市', '嘉峪关市', '金昌市', '白银市', '天水市', '武威市', '张掖市', '平凉市', '酒泉市', '庆阳市', '定西市', '陇南市', '临夏回族自治州', '甘南藏族自治州'],
            [ '西宁市', '海东市', '海北藏族自治州', '黄南藏族自治州', '海南藏族自治州', '果洛藏族自治州', '玉树藏族自治州', '海西蒙古族藏族自治州'],
            [ '银川市', '石嘴山市', '吴忠市', '固原市', '中卫市'],
            [ '乌鲁木齐市', '克拉玛依市', '吐鲁番市', '哈密市', '昌吉回族自', '博尔塔拉蒙古自治州', '巴音郭楞蒙古自治州', '阿克苏地区','克孜勒苏柯' , '喀什地区', '和田地区', '伊犁哈萨克自治州', '塔城地区', '阿勒泰地区', '自治区直辖县级行政区划'],
            [],
            [],
            [],

        ];
        var sCode=[
            ['110101', '110102','110105', '110106', '110107', '110108', '110109','110111', '110112','110113', '110114',
                '110115', '110116', '110117','110118','110119',],
            ['120101','120102','120103', '120104', '120105', '120106', '120110','120111','120112', '120113', '120114',
                '120115','120116','120117','120118','120119',],
            ['130100','130200','130300','130400','130500','130600','130700','130800','130900','131000','131100','139001','139002',],
            ['140100','140200','140300','140400','140500', '140600','140700','140800','140900','141000','141100',],
            ['150100','150200','150300','150400','150500','150600','150700','150800','150900','152200','152500','152900',],
            ['210100','210200','210300','210400','210500','210600', '210700','210800','210900','211000','211100','211200','211300','211400',],
            ['220100', '220200','220300','220400','220500','220600','220700','220800','222400',],
            ['230100','230200','230300','230400','230500','230600','230700','230800','230900','231000','231100','231200','232700',],
            ['310101','310104', '310105', '310106', '310107', '310109','310110','310112','310113','310114','310115','310116',  '310117','310118','310120','310151',],
            ['320100','320200', '320300', '320400','320500','320600','320700','320800','320900','321000','321100','321200','321300',],
            ['330100','330200','330300','330400', '330500','330600','330700','330800', '330900','331000','331100',],
            ['340100','340200','340300','340400','340500','340600','340700','340800','341000','341100', '341200','341300','341500','341600','341700','341800',],
            ['350100', '350200','350300','350400','350500','350600','350700','350800','350900',],
            [ '360100','360200','360300','360400','360500','360600', '360700','360800','360900','361000','361100',],
            ['370100','370200','370300','370400','370500', '370600','370700','370800','370900','371000', '371100','371200','371300','371400','371500','371600','371700',],
            ['410100','410200','410300','410400','410500','410600','410700','410800','410900','411000','411100','411200','411300','411400', '411500','411600', '411700',],
            [ '420100', '420200','420300','420500','420600','420700','420800','420900','421000','421100','421200','421300','422800','429004','429005', '429006','429021',],
            ['430100','430200', '430300','430400','430500','430600','430700','430800','430900','431000','431100','431200','431300','433100',],
            [ '440100','440200','440300','440400', '440500','440600','440700','440800','440900','441200','441300','441400','441500','441600','441700','441800','441900','442000','445100','445200','445300',],
            [ '450100','450200', '450300', '450400','450500','450600','450700','450800','450900','451000','451100','451200','451300','451400',],
            ['460100','460200','460300','460400','469001', '469002','469005','469006','469007', '469021', '469022', '469023', '469024', '469025','469026','469027', '469028','469029', '469030',],
            ['500101','500102','500103', '500104','500105', '500106','500107','500108','500109', '500110',  '500111','500112','500113', '500114','500115', '500116', '500117','500118',
                '500119', '500120','500151', '500152', '500153','500154', '500200',],
            ['510300','510400','510500','510600','510700','510800','510900', '511000', '511100','511300', '511400','511500','511600','511700','511800','511900','512000','513200','513300','513400',],
            ['520100','520200','520300','520400','520500', '520600','522300', '522600','522700',],
            [ '530100', '530300', '530400','530500', '530600','530700','530800','530900','532300','532500','532600','532800','532900', '533100','533300',],
            ['540100','540200','540300','540400','540500','542400','542500',],
            [ '610100','610200','610300','610400','610500','610600','610700','610800','610900','611000',],
            [ '620100','620200','620300', '620400', '620500', '620600','620700', '620800', '620900','621000', '621100', '621200','622900','623000',],
            ['630100','630200','632200', '632300','632500','632600','632700','632800',],
            ['640100', '640200','640300', '640400','640500',],
            ['650100','650200', '650400','650500','652300','652700','652800', '652900', '653000','653100','653200','654000','654200','654300','659000',],
            [''],
            [''],
            [''],
        ]
        this.data.sCode=sCode[e.currentTarget.dataset.name]
        var province = ['北京', '天津市', '河北省', '山西省', '内蒙古自治区', '辽林省', '吉林省', '黑龙江省', '上海市', '江苏省', '浙江省', '安徽省', '福建省', '江西省', '山东省', '河南省', '湖北省', '湖南省', '广东省', '广西壮族自', '海南省', '重庆市', '四川省', '贵州省', '云南省', '西藏自治区', '陕西省', '甘肃省', '青海省', '宁夏回族自治区', '新疆维吾尔自治区', '台湾省', '香港特别行政区', '澳门特别行政区']
        var cityCode = ['110000', '120000', '130000', '140000', '150000', '210000', '220000', '230000', '310000', '320000', '330000', '340000', '350000', '360000', '370000', '410000', '420000', '430000', '440000', '450000', '460000', '500000', '510000', '520000', '530000', '540000', '610000', '620000', '630000', '640000', '650000', '710000', '810000', '820000']
        this.data.arr[app.newschedulingindex].provinces = province[e.currentTarget.dataset.name]
        this.data.arrs[app.newschedulingindex].cityCode = cityCode[e.currentTarget.dataset.name]
        this.data.arrs[app.newschedulingindex].cityName = province[e.currentTarget.dataset.name]
        this.setData({
            arr: this.data.arr,
            number4: "false",
            number3: "true",
            all: s[e.currentTarget.dataset.name],
        })
    },
    /*选择市*/
    oncity: function (e) {
        console.log(this.data.sCode[e.currentTarget.dataset.id])
        this.data.arrs[app.newschedulingindex].cityCode=this.data.sCode[e.currentTarget.dataset.id]
        this.data.arrs[app.newschedulingindex].cityName = this.data.arrs[app.newschedulingindex].cityName+","+ e.currentTarget.dataset.name,
            console.log(this.data.arrs)
        app.cityName = app.cityName + e.currentTarget.dataset.name,
            this.data.arr[app.newschedulingindex].city = e.currentTarget.dataset.name,
            this.data.arrs[app.newschedulingindex].cityName = this.data.arrs[app.newschedulingindex].cityName+e.currentTarget.dataset.name,
            this.setData({
                arr: this.data.arr,
                number4: "false",
                number3: "false",
            })
    },
    /*跳转页面*/
    onDrivinglicense: function () {
        wx.navigateTo({
            url: '../cameralist/cameralist',
        })
    },
    /*相册组件*/
    chooseimage: function (e) {

        var license=e.currentTarget.dataset.name
        var _this = this;
        console.log(license);

        wx.chooseImage({

            count: 1, // 默认9
            sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
            sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
            success: function (res) {
                console.log(_this.data.access_token);
                var tempFilePaths = res.tempFilePaths;
                console.log(tempFilePaths)
                var page=_this
                var data=license
                var path=tempFilePaths
                console.log(path[0])
                var token;
                var bizCode;
                wx.getStorage({
                    key: 'token',
                    success: function (res) {
                        token = res.data;
                        console.log(token)
                        if(data=="license"){
                            bizCode=4
                        }else if(data=="headstockphotos"){
                            bizCode=5
                        }else if(data=="drivinglicensesidelinePositive"){
                            bizCode=4
                        }else if(data=="drivinglicensesidelineTheOtherside"){
                            bizCode=4
                        } else if(data=="affiliationagreement"){
                            bizCode=8
                        }else if(data=="trailerPass"){
                            bizCode=8
                        }else if(data=="transport"){
                            bizCode=8
                        }else if(data=="registrationcertificate"){
                            bizCode=8
                        }else{
                            bizCode=8
                        }
                        var alldata={
                            app_key: app.data.appKey,
                            timestamp:new Date().getTime(),
                            access_token: token,
                            signature:"",
                            param:"",
                            bizCode:bizCode,
                            privateField:"",
                            fileName:""

                        }
                        wx.showToast({
                            icon: "loading",
                            title: "正在上传"
                        }),
                            wx.uploadFile({
                                url: app.data.allDomainNameUrl+'fileUpload?app_key='+app.data.appKey+"&bizCode="+8+"&privateField="+"&fileName="+"&access_token="+token,
                                filePath: path[0],
                                name: 'file',
                                formData:alldata,
                                header: {
                                    "Content-Type": "multipart/form-data"
                                },
                                success: function (res) {
                                    console.log(res)
                                    var jsondata=JSON.parse(res.data)
                                    console.log(res);
                                    if (res.statusCode != 200) {
                                        wx.showModal({
                                            title: '提示',
                                            content: '上传失败',
                                            showCancel: false
                                        })
                                        return;
                                    }
                                    console.log(data);
                                    if(data=="license"){

                                        page.data.licenseID=jsondata.body.content.fileID
                                        page.data.licenseUrl=jsondata.body.content.fileUrl
                                        //---------------------
                                        var url="https://aip.baidubce.com/rest/2.0/ocr/v1/vehicle_license";
                                        const fs = wx.getFileSystemManager();
                                        fs.readFile({
                                            filePath:path[0],
                                            encoding:"base64",
                                            success:function (data) {
                                                wx.showLoading({
                                                    title: "正在加载中...",
                                                });

                                                var s = data.data.replace("\n","");
                                                var datas={
                                                    access_token:_this.data.access_token,
                                                    image:s,
                                                    vehicle_license_side:"front"
                                                }
                                                wx.request({
                                                    data: datas,
                                                    header: {'content-type': 'application/x-www-form-urlencoded'},
                                                    url: url,
                                                    method: 'POST',
                                                    success: function (res) {
                                                        console.log(res.data.words_result)
                                                        wx.hideToast();
                                                        if(res.data.words_result!=undefined){
                                                            _this.data.inputunmber=res.data.words_result.号牌号码.words;
                                                            _this.data.identificationcode=res.data.words_result.车辆识别代号.words;
                                                            _this.data.owner=res.data.words_result.所有人.words;
                                                            _this.data.natureofusage=res.data.words_result.使用性质.words;
                                                            _this.data.engine=res.data.words_result.发动机号码.words;
                                                            _this.setData({
                                                                vehiclelicenseplate:res.data.words_result.号牌号码.words,
                                                                vehicleidentificationcode:res.data.words_result.车辆识别代号.words,
                                                                allName:res.data.words_result.所有人.words,
                                                                natureofusage:res.data.words_result.使用性质.words,
                                                                vehicletype:res.data.words_result.车辆类型.words,
                                                                enginenumber:res.data.words_result.发动机号码.words,
                                                            })
                                                        }
                                                        /*_this.setData({
                                                            carboolean:true
                                                        })*/
                                                        app.shiptype="1085090";
                                                    },
                                                    fail: function (event) {
                                                        console.log(event)


                                                    },
                                                })
                                            }
                                        })

                                        //---------------------
                                        page.setData({  //上传成功修改显示头像
                                            carboolean:true,
                                            src1: jsondata.body.content.fileUrl
                                        })
                                    }else if(data=="headstockphotos"){
                                        page.data.headID=jsondata.body.content.fileID
                                        page.setData({  //上传成功修改显示头像
                                            headSrc: jsondata.body.content.fileUrl
                                        })
                                    }else if(data=="drivinglicensesidelinePositive"){
                                        page.data.positiveID=jsondata.body.content.fileID
                                        page.data.positiveUrl=jsondata.body.content.fileUrl
                                        page.setData({  //上传成功修改显示头像
                                            positiveSrc: jsondata.body.content.fileUrl
                                        })
                                    }else if(data=="drivinglicensesidelineTheOtherside"){
                                        page.data.theOthersideID=jsondata.body.content.fileID
                                        page.data.theOthersideUrl=jsondata.body.content.fileUrl
                                        page.setData({  //上传成功修改显示头像
                                            theOthersideSrc: jsondata.body.content.fileUrl
                                        })
                                    }else if(data=="affiliationagreement"){
                                        page.data.agreementID=jsondata.body.content.fileID
                                        page.data.agreementUrl=jsondata.body.content.fileUrl
                                        page.setData({  //上传成功修改显示头像
                                            agreementSrc: jsondata.body.content.fileUrl
                                        })
                                    }else if(data=="trailerPass"){
                                        page.data.trailerPassID=jsondata.body.content.fileID
                                        page.data.trailerPassUrl=jsondata.body.content.fileUrl
                                        page.setData({  //上传成功修改显示头像
                                            trailerPassSrc: jsondata.body.content.fileUrl
                                        })
                                    }else if(data=="transport"){
                                        page.data.transportID=jsondata.body.content.fileID
                                        page.data.transportUrl=jsondata.body.content.fileUrl
                                        page.setData({  //上传成功修改显示头像
                                            transportSrc: jsondata.body.content.fileUrl
                                        })
                                    }else if(data=="registrationcertificate"){
                                        page.data.certificateID=jsondata.body.content.fileID
                                        page.data.certificateUrl=jsondata.body.content.fileUrl
                                        page.setData({  //上传成功修改显示头像
                                            certificateSrc: jsondata.body.content.fileUrl
                                        })
                                    }
                                },
                                fail: function (e) {
                                    console.log(e);
                                    wx.showModal({
                                        title: '提示',
                                        content: '上传失败',
                                        showCancel: false
                                    })
                                },
                                complete: function () {
                                    wx.hideToast();  //隐藏Toast
                                }
                            })
                    }
                });
                // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
                _this.setData({
                    tempFilePaths1: res.tempFilePaths
                })
            }
        })
    },

    Inputowner:function(e){
        this.data.owner=e.detail.value
    },
    identificationcode:function(e){
        this.data.identificationcode=e.detail.value
    },
    transportnoInput:function(e){
        this.data.transportno=e.detail.value
    },
    /*保存*/
    onPreservation: function () {
        var that=this;
        console.log(that.data.engine)
        if (!that.pageLoading) {
            that.pageLoading = !0;
            console.log(this.data.inputunmber)
            if(app.vehicletype_name=="车辆"){
                if (this.data.inputunmber == undefined) {
                    wx.showToast({
                        title: "请填写车船牌照!",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                        success: function () {
                            that.pageLoading = !1
                        }
                    })
                    return;
                }else if(that.data.identificationcode==""){
                    wx.showToast({
                        title: "请填写车辆识别代码!",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                        success: function () {
                            that.pageLoading = !1
                        }
                    })
                    return;
                }else if(this.data.owner==""){
                    wx.showToast({
                        title: "请填写所有人!",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                        success: function () {
                            that.pageLoading = !1
                        }

                    })
                    return;
                }else if(this.data.natureofusage==""){
                    wx.showToast({
                        title: "请填写使用性质!",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                        success: function () {
                            that.pageLoading = !1
                        }

                    })
                    return;
                }
                else if (app.shiptype == undefined) {

                    if (app.vehicletype_name == "车辆") {
                        wx.showToast({
                            title: "请填写车型!",
                            mask: false,
                            icon: "none",
                            duration: 2000,
                            success: function () {
                                that.pageLoading = !1
                            }

                        })
                        return;
                    } else {
                        wx.showToast({
                            title: "请填写船型!",
                            mask: false,
                            icon: "none",
                            duration: 2000,
                            success: function () {
                                that.pageLoading = !1
                            }

                        })
                        return;
                    }

                } else if (app.length == undefined) {
                    if (app.vehicletype_name  == "车辆") {
                        wx.showToast({
                            title: "请填写车长!",
                            mask: false,
                            icon: "none",
                            duration: 2000,
                            success: function () {
                                that.pageLoading = !1
                            }

                        })
                        return;
                    } else {
                        console.log(app.data.vehicletype_name)
                        wx.showToast({
                            title: "请填写船区!",
                            mask: false,
                            icon: "none",
                            duration: 2000,
                            success: function () {
                                that.pageLoading = !1
                            }

                        })
                        return;
                    }

                } else if (this.data.approvedtonnage == "") {
                    wx.showToast({
                        title: "请填写核定吨位!",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                        success: function () {
                            that.pageLoading = !1
                        }
                    })
                    return;
                } else if (this.data.arrs[0].cityCode == "") {
                    wx.showToast({
                        title: "请填写常跑城市!",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                        success: function () {
                            that.pageLoading = !1
                        }
                    })
                    return;
                }
            }else{
                if (this.data.inputunmber == undefined) {
                    wx.showToast({
                        title: "请填写车船牌照!",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                        success: function () {
                            that.pageLoading = !1
                        }

                    })
                    return;
                }else if(this.data.owner==""){
                    wx.showToast({
                        title: "请填写所有人!",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                        success: function () {
                            that.pageLoading = !1
                        }

                    })
                    return;
                }else if (app.shiptype == undefined) {

                    if (app.vehicletype_name == "车辆") {
                        wx.showToast({
                            title: "请填写车型!",
                            mask: false,
                            icon: "none",
                            duration: 2000,
                            success: function () {
                                that.pageLoading = !1
                            }

                        })
                        return;
                    } else {
                        wx.showToast({
                            title: "请填写船型!",
                            mask: false,
                            icon: "none",
                            duration: 2000,
                            success: function () {
                                that.pageLoading = !1
                            }

                        })
                        return;
                    }

                }else if (this.data.approvedtonnage == "") {
                    wx.showToast({
                        title: "请填写核定吨位!",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                        success: function () {
                            that.pageLoading = !1
                        }
                    })
                    return;
                }else if (app.length == undefined) {
                    if (app.vehicletype_name  == "车辆") {
                        wx.showToast({
                            title: "请填写车长!",
                            mask: false,
                            icon: "none",
                            duration: 2000,
                            success: function () {
                                that.pageLoading = !1
                            }

                        })
                        return;
                    } else {
                        console.log(app.data.vehicletype_name)
                        wx.showToast({
                            title: "请填写船区!",
                            mask: false,
                            icon: "none",
                            duration: 2000,
                            success: function () {
                                that.pageLoading = !1
                            }

                        })
                        return;
                    }

                }
            }
                var vehicleOwnerType="";
                console.log(app.personal_name)
                if(app.data.personal_name=="个人"){
                    vehicleOwnerType="2992010"
                }else {
                    vehicleOwnerType="2992020"
                }
                var body;
                if (app.vehicletype_name == "车辆") {
                    this.data.carrier = "1071000";
                    var linkmanInfo = {"name": this.data.name, "mobile": this.data.mobile};
                    body = {
                        vehicleID: this.data.vehicleID,
                        driverID: app.driverID,
                        vehicleMode: this.data.carrier,
                        carInfo2: {
                            vehicleCode: this.data.inputunmber,
                            typeID: app.shiptype,
                            lengthID: app.length,
                            tonnage: this.data.approvedtonnage,
                        },
                        linkmanInfo: linkmanInfo,
                        arrCityInfo: this.data.arrs,
                        owner: this.data.owner,
                        //行驶证照片
                        drivingLicensePhotoID:this.data.licenseID,
                        //载具正面照片
                        frontPhotoID:this.data.headID,
                        //道路运输证编号
                        roadTranCertCode:this.data.transportno,
                        // 道路运输证到期日
                        roadTranCertAvailableDate:this.data.destinationDate,
                      /*  //归属关系
                        relationType*/
                        //其他照片
                       /* arrOtherPhotoInfo:[{
                            fileID:this.data.certificateID,
                            bizType:4,
                            otherPhotoUrl:this.data.certificateUrl,
                            fileSeqNo:1
                        }],*/
                        //道路运输许可经营证
                        roadTransportCertificateInfo:{

                        },
                      /*  //档案信息
                        vehicleArchivesInfo*/
                        //行驶证信息
                        drivingLicenseInfo:{
                            Owner:this.data.owner,
                            engineNo:this.data.engine,
                            useCharacter:this.data.natureofusage,
                            vin:this.data.identificationcode,
                            //行驶证照片ID
                            drivingLicensePhotoId:this.data.licenseID,
                            //行驶证照片
                            drivingLicensePhotoUrl:this.data.licenseUrl,
                            //车辆行驶证副页正面ID
                            driveringLicenseFrontID:this.data.positiveID,
                            //车辆行驶证副页正面
                            driveringLicenseFrontUrl:this.data.positiveUrl,
                            //车辆行驶证副页反面
                            driveringLicenseBackID:this.data.theOthersideID,
                            //车辆行驶证副页反面
                            driveringLicenseBackUrl:this.data.theOthersideUrl,
                        },
                        //车辆挂靠协议图片ID
                        alignmentProtocolPhotoID:this.data.agreementID,
                        //挂车行驶证图片ID
                        trailerDrivingLicensePhotoID:this.data.trailerPassID,
                        //车辆归属类型
                        vehicleOwnerType:vehicleOwnerType,
                      /*  //车主身份证照片ID
                        ownerIdnumberPhotoID*/
                        //运输队ID
                        teamID: app.orderdata["teamID"],
                            //道路运输证图片ID
                        roadTransportBusinessLicensePhotoID:this.data.transportID,
                        roadTransportBusinessLicensePhotoUrl:this.data.transportUrl


                    }
                } else if (app.vehicletype_name == "船舶") {
                    this.data.carrier = "1071010"
                    var linkmanInfo = {"name": this.data.name, "mobile": this.data.mobile};
                    body = {
                        vehicleID: this.data.vehicleID,
                        driverID: app.driverID,
                        vehicleMode: this.data.carrier,
                        shipInfo: {
                            vehicleCode: this.data.inputunmber,
                            typeID: app.shiptype,
                            zoneID: app.length,
                            tonnage: this.data.approvedtonnage,
                        },
                        linkmanInfo: linkmanInfo,
                     /*   arrCityInfo: this.data.arrs,*/
                        owner: this.data.owner,

                      /*  //行驶证照片
                        drivingLicensePhotoID:this.data.licenseID,
                        //载具正面照片
                        frontPhotoID:this.data.headID,
                        //道路运输证编号
                        roadTranCertCode:this.data.transportno,
                        // 道路运输证到期日
                        roadTranCertAvailableDate:this.data.destinationDate,*/
                      /*  //归属关系
                        relationType*/
                        //其他照片
                      /*  arrOtherPhotoInfo:[{
                            fileID:this.data.certificateID,
                            bizType:4,
                            otherPhotoUrl:this.data.certificateUrl,
                            fileSeqNo:1
                        }],*/
                      /*  //道路运输许可经营证
                        roadTransportCertificateInfo*/
                      /*  //档案信息
                        vehicleArchivesInfo*/
                       //行驶证信息
                       /*drivingLicenseInfo:{
                            Owner:this.data.owner,
                            engineNo:this.data.engine,
                            useCharacter:this.data.natureofusage,
                            vin:this.data.identificationcode,
                            //行驶证照片ID
                            drivingLicensePhotoId:this.data.licenseID,
                            //行驶证照片
                            drivingLicensePhotoUrl:this.data.licenseUrl,
                            //车辆行驶证副页正面ID
                           driveringLicenseFrontID:this.data.positiveID,
                            //车辆行驶证副页正面
                           driveringLicenseFrontUrl:this.data.positiveUrl,
                            //车辆行驶证副页反面
                           driveringLicenseBackID:this.data.theOthersideID,
                            //车辆行驶证副页反面
                           driveringLicenseBackUrl:this.data.theOthersideUrl,
                                },*/
                      /* //车辆挂靠协议图片ID
                       alignmentProtocolPhotoID:this.data.agreementID,
                       //挂车行驶证图片ID
                       trailerDrivingLicensePhotoID:this.data.trailerPassID,
                       //车辆归属类型
                       vehicleOwnerType:vehicleOwnerType,*/
                      /* //车主身份证照片ID
                       ownerIdnumberPhotoID*/
                       teamID: app.orderdata["teamID"],
                        //道路运输证
                    /*   roadTransportBusinessLicens
                    ePhotoID:this.data.transportID,
                        roadTransportBusinessLicensePhotoUrl:this.data.transportUrl*/

                    }
                }
                var options = {
                    port: 'vehicleCreUpd4',
                    body
                }
                app.connect(options).then(values => {
                    console.log(values)
                    if (values.data.body.code != "-1") {
                        wx.showToast({
                            title: "添加载具成功",
                            mask: false,
                            icon: "success",
                            duration: 1500,
                            success: function () {
                                if(app.isRegister==true){
                                    app.isRegister=false
                                    //实现跳转
                                    wx.reLaunch({
                                        url: '../../workbench/workbench',
                                    });
                                }else{
                                    wx.navigateBack({
                                        delta: -1
                                    });
                                }
                            }
                        })
                    }else{
                        wx.showToast({
                            title: values.data.body.desc,
                            mask: false,
                            icon: "none",
                            duration: 2000,
                            success:function(){
                                that.pageLoading = !1
                            }
                        })
                    }

                })
        }
    },
    /*获取input值*/
    nameInput: function (e) {
        this.data.name = e.detail.value
    },
    engineInput:function(e){
        this.data.engine = e.detail.value
    },
    /*获取input值*/
    mobileInput: function (e) {
        this.data.mobile = e.detail.value
    },
    natureofusageInput:function (e) {
        this.data.natureofusage = e.detail.value
    },
    /*引用页面判断*/
    onAddingtool: function () {
        this.setData({
            number3: "false",
            number4: "false",
            number: 'false',
        })
    },
    /*获取input参数*/
    Inputunmber: function (e) {
        this.data.inputunmber = e.detail.value
    },
    /*下滑外部页面销毁判断*/
    handletouchtart: function (event) {
        this.setData({
            number3: "false",
            number4: "false",
            number: 'false',
        })

    },
    onatoolindex: function () {
        console.log(this.data.i)
        this.data.arr.push(this.data.i++)
        this.setData({
            arr: this.data.arr
        })
        console.log(this.data.arr)
    },
    userNameInput:function (e) {
        if (isNaN(e.detail.value)) {
            wx.showToast({
                title: "请填写数字",
                mask: false,
                icon: "success",
                duration: 2000,
                success: function () {

                }
            })
        } else {
            this.data.approvedtonnage = e.detail.value
            if (e.detail.value == "") {
                this.data.approvedtonnage = ""
            }
        }
    },
    bindMultiPickerColumnChange1: function (e) {
        for(var i=0;i<this.data.multiArray1.length;i++){

            for(var j=0;j<this.data.multiArray1[i].length;j++) {
                if (i==0) {
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("年","");
                }else if(i==1){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("月",'')
                }else if(i==2){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("日",'')
                }else if(i==3){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("时",'')
                }else if(i==4){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("分",'')
                }else if(i==5){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("秒",'')
                }
            }
        }
        console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
        var data1 = {
            multiArray1: this.data.multiArray1,
            multiIndex1: this.data.multiIndex1
        };
        data1.multiIndex1 = e.detail.value;
        this.setData(data1);
        this.data.destinationDate=data1.multiArray1[0][data1.multiIndex1[0]]+"-"+data1.multiArray1[1][data1.multiIndex1[1]]+"-"+data1.multiArray1[2][data1.multiIndex1[2]]
        this.data.deliverytime=null;
        this.setData({
            deliverytime:this.data.deliverytime
        })


    },
    ontime:function(){
        var myDate = new Date();
        var a=0;
        var b=0;
        var c=0;
        var d=0;
        var e=0;
        for(var i=89;i<parseInt(myDate.getYear());i++){
            a=a+1
        }
        for(var i=0;i<parseInt(myDate.getMonth());i++){
            b=b+1
        }
        for(var i=1;i<parseInt(myDate.getDate());i++) {
            c = c + 1
        }
        for(var i=0;i<parseInt(myDate.getHours());i++){
            d=d+1
        }
        for(var i=0;i<parseInt(myDate.getMinutes());i++){
            e=e+1
        }
        this.data. multiIndex1[0]=a
        this.data. multiIndex1[1]=b
        this.data. multiIndex1[2]=c
        this.data. multiIndex1[3]=d
        this.data. multiIndex1[4]=e
        this.setData({
            multiArray1:this.data.multiArray1,
            multiIndex1:this.data. multiIndex1
        })

    },


})