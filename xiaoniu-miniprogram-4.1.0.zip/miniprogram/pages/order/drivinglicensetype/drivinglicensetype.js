var app = getApp();
Page({
    onType: function (e) {
        var s = {
            2951010:"A1",
            2951020:"A2",
            2951030:"A3",
            2951040:"B1",
            2951050:"B2",
            2951060:"C1",
            2951070:"C2",
            2951080:"C3",
            2951090:"C4",
            2951100:"D",
            2951110:"E",
            2951120:"F",
            2951130:"M",
            2951140:"N",
            2951150:"P",

        }
        app.drivingName= s[e.currentTarget.dataset.name]
        app.drivingType=e.currentTarget.dataset.name
        wx.navigateBack({
            delta: -1
        });
    }
})