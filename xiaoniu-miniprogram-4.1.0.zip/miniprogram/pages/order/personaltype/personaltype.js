var app = getApp();
Page({
    data: {
        name: '',
    },
    onLoad: function () {
        var body;
        var car;
        var ship;
        if (app.data.personal_name == "个人") {
            body = {
                car: "true",
                ship: "false"
            }
        } else {
            body = {
                car: "false",
                ship: "true"
            }
        }
        this.setData({
            shuju: body
        })
    },
    onShow: function () {
        var body;
        var car;
        var ship;
        console.log(app.personal_name)
        if (app.personal_name == "个人") {
            body = {
                car: "true",
                ship: "false"
            }
        } else if (app.personal_name == "所有人") {
            body = {
                car: "false",
                ship: "true"
            }
        }
        this.setData({
            shuju: body
        })

    },
    mySelect: function (e) {
        console.log(e.currentTarget.dataset.name)
        this.data.name = e.currentTarget.dataset.name
        var body;
        var car;
        var ship;
        if (this.data.name == "car") {
            app.personal_name="个人";
            body = {
                car: "true",
                ship: "false"
            }
        } else if (this.data.name == "ship") {
            app.personal_name="所有人";
            body = {
                car: "false",
                ship: "true"
            }
        }
        console.log(body.car)
        this.setData({
            shuju: body
        })
        wx.navigateBack({
            delta: -1
        });
    }
})