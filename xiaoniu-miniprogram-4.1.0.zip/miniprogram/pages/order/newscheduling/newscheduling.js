var app = getApp();
var publish = require('../../public_util/publishData');
Page({
    data: {
        multiArray: [publish.years,publish.mouths,publish.days,publish.houvers,publish.branchs],
        multiIndex: ["", "", "","",""],
        multiArray1: [publish.years,publish.mouths,publish.days,publish.houvers,publish.branchs],
        multiIndex1: ["", "", "","",""],
        cashpaymentunmber: 0,
        topaynumber: 0,
        returnpaymentnumber: 0,
        monthlyknotnumber: 0,
        arr: [{driverName: '', drivermobile: '', vehiclemodel: '', vehiclepropertye: '',vehicleID:'',chiefDriverID:''}],
        i: 1,
        j: 750,
        /*计划出发时间*/
        deliveryDate:'',
        /*计划到达时间s*/
        destinationDate:'',
        defaultDriverInfo:'',
        vehicleID:'',
        arrCargoInfo1:[]

    },
    /*下拉刷新*/
    onPullDownRefresh() {
        wx.stopPullDownRefresh()
    },

/*加载数据*/
    onLoad: function (options) {
        this.data.arrCargoInfo1.splice(0,this.data.arrCargoInfo1);
        app.shuju.consigneeInfo.addressInfo.cityShortName=app.oncityNam(app.shuju.consigneeInfo.addressInfo.cityShortName)
        app.shuju.consignorInfo.addressInfo.cityShortName=app.oncityNam(app.shuju.consignorInfo.addressInfo.cityShortName)
     console.log(app.shuju)
        this.data.arr[0] = {vehiclemodel: "选择载具", driverName: "选择司机"}
        console.log(this.data.arr)
        this.setData({
            company:options.company,
            company1:options.company1,
            forward:app.globalData[48],
            volume:options.volume,
            quantity:options.quantity,
            shuju: app.shuju,
            arr: this.data.arr,
            driverName: "选择司机",
            vehiclemodel: "选择载具",
            delivergoods:app.globalData[17],
            collectgoods:app.globalData[18],
            add:app.globalData[21],
            size1:options.size,
            number1:options.number1,
            quality1:options.quality1
        })


    },
    /*加载数据*/
    onShow: function () {
        this.pageLoading = !1
        this.data.arr[0].vehicleID=app.vehicleID1
        if(app.chiefDriverID!=undefined){
            this.data.arr[0].chiefDriverID=app.chiefDriverID
        }
        if(app.vehicleID!=undefined){
            var options = {
                port: 'vehicleDtlQry3',
                body: {
                    vehicleID:app.vehicleID
                }
            }
            app.connect(options).then(values => {
                console.log(values)
                console.log(app.newschedulingindex)
                if(app.newschedulingindex==0){
                    this.data.arr[0].chiefDriverID=values.data.body.content.vehicleInfo.defaultDriverInfo.driverID
                }
                this.data.defaultDriverInfo=this.data.arr[app.newschedulingindex1].driverName = values.data.body.content.vehicleInfo.defaultDriverInfo
                this.data.arr[app.newschedulingindex1].driverName = values.data.body.content.vehicleInfo.defaultDriverInfo.name
                this.data.arr[app.newschedulingindex1].drivermobile = values.data.body.content.vehicleInfo.defaultDriverInfo.mobile
                this.setData({
                    arr:this.data.arr
                })
                app.vehicleID=undefined
            })
        }
        if (app.newschedulingindex == undefined) {
            app.newschedulingindex = 0
            app.vehiclemodel = "选择载具"
        }
        if (app.newschedulingindex1 == undefined) {
            app.newschedulingindex1 = 0
            app.driverName = "选择司机"
        }
        console.log(app.vehiclemodel)
        this.data.arr[app.newschedulingindex].vehiclemodel = app.vehiclemodel
        this.data.arr[app.newschedulingindex].vehiclepropertye = app.vehiclepropertye
        this.data.arr[app.newschedulingindex1].driverName = app.driverName
        this.data.arr[app.newschedulingindex1].drivermobile = app.drivermobile
        console.log(this.data.arr)
        this.setData({
            arr: this.data.arr,
        })
    },
    cashpayment: function (e) {
        if (!isNaN(e.detail.value)) {
            if (e.detail.value == ""&&e.detail.value) {
                this.data.cashpaymentunmber = 0
            } else {
                this.data.cashpaymentunmber = e.detail.value
            }
            this.setData({
                cherNumber: ".00",
                numbers: parseInt(this.data.cashpaymentunmber) + parseInt(this.data.topaynumber) + parseInt(this.data.returnpaymentnumber) + parseInt(this.data.monthlyknotnumber),
            })
        }

    },
    topay: function (e) {
        if (!isNaN(e.detail.value)) {
            if (e.detail.value == "") {
                this.data.topaynumber = 0
            } else {
                this.data.topaynumber = e.detail.value
            }
            this.setData({
                cherNumber: ".00",
                numbers: parseInt(this.data.cashpaymentunmber) + parseInt(this.data.topaynumber) + parseInt(this.data.returnpaymentnumber) + parseInt(this.data.monthlyknotnumber),
            })
        }
    },
    returnpayment: function (e) {
        if (!isNaN(e.detail.value)) {
            if (e.detail.value == "") {
                this.data.returnpaymentnumber = 0
            } else {
                this.data.returnpaymentnumber = e.detail.value
            }

            this.setData({
                cherNumber: ".00",
                numbers: parseInt(this.data.cashpaymentunmber) + parseInt(this.data.topaynumber) + parseInt(this.data.returnpaymentnumber) + parseInt(this.data.monthlyknotnumber),
            })
        }
    },
    monthlyknot: function (e) {
        if (!isNaN(e.detail.value)) {
            if (e.detail.value == "") {

                this.data.monthlyknotnumber = 0
            } else {
                this.data.monthlyknotnumber = e.detail.value
            }
            this.setData({
                cherNumber: ".00",
                numbers: parseInt(this.data.cashpaymentunmber) + parseInt(this.data.topaynumber) + parseInt(this.data.returnpaymentnumber) + parseInt(this.data.monthlyknotnumber),
            })
        }
    },
    ongenerate: function () {

        if(app.orderdata["isFree"]=="false"){
            wx.showModal({
                title:"提示",
                content:"车辆满载状态，是否继续调度！",
                showCancel:true,
                //用户确定
                success:function (res) {
                    if (res.confirm){
                        app.orderdata["isFree"]="true"
                    }else{

                    }
                },
                //退出失败，可能一些原因导致
                fail:function (res) {
                    wx.hideLoading()
                    wx.showToast({
                        title:"退出失败,请反馈",
                        duration:1500,
                    });
                },
            });


        }else {
            var that = this;
            if (!that.pageLoading) {
                that.pageLoading = !0;
                var desc;
                for (var i = 1; i < this.data.arr.length; i++) {
                    desc = desc + this.data.arr[i].vehiclemodel + " | " + this.data.arr[i].vehiclepropertye + "\n" + this.data.arr[i].driverName + "：" + this.data.arr[i].drivermobile + "\n"
                }
                if (this.data.arr[0].vehiclemodel == "选择载具") {
                    wx.showToast({
                        title: "请选择载具！",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                        success: function () {
                            that.pageLoading = !1
                        }

                    })
                } else if (this.data.arr[0].vehiclemodel == "选择司机") {
                    wx.showToast({
                        title: "请选择司机！",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                        success: function () {
                            that.pageLoading = !1
                        }
                    })
                } else if (this.data.destinationDate == "") {
                    wx.showToast({
                        title: "请填写到达时间！",
                        mask: false,
                        icon: "none",
                        duration: 2000,
                        success: function () {
                            that.pageLoading = !1
                        }

                    })
                } else {
                    var that = this;
                    var arrMode = [];
                    if (this.data.cashpaymentunmber != 0 && this.data.topaynumber != 0 && this.data.returnpaymentnumber != 0 && this.data.monthlyknotnumber != 0) {
                        var cashpayment = {paymentMode: 1021000, money: this.data.cashpaymentunmber}
                        var returnpayment = {paymentMode: 1021020, money: this.data.returnpaymentnumber}
                        var topay = {paymentMode: 1021040, money: this.data.topaynumber}
                        var monthlyknot = {paymentMode: 1021030, money: this.data.monthlyknotnumber}
                        arrMode.push(cashpayment)
                        arrMode.push(returnpayment)
                        arrMode.push(topay)
                        arrMode.push(monthlyknot)
                    } else if (this.data.cashpaymentunmber != 0 && this.data.topaynumber != 0 && this.data.returnpaymentnumber != 0) {
                        var cashpayment = {paymentMode: 1021000, money: this.data.cashpaymentunmber}
                        var returnpayment = {paymentMode: 1021020, money: this.data.returnpaymentnumber}
                        var topay = {paymentMode: 1021040, money: this.data.topaynumber}
                        arrMode.push(cashpayment)
                        arrMode.push(returnpayment)
                        arrMode.push(topay)
                    } else if (this.data.cashpaymentunmber != 0 && this.data.topaynumber != 0) {
                        var cashpayment = {paymentMode: 1021000, money: this.data.cashpaymentunmber}
                        var topay = {paymentMode: 1021040, money: this.data.topaynumber}
                        arrMode.push(cashpayment)
                        arrMode.push(topay)
                    } else if (this.data.cashpaymentunmber != 0) {
                        var cashpayment = {paymentMode: 1021000, money: this.data.cashpaymentunmber}
                        arrMode.push(cashpayment)
                    }
                    console.log(app.deliveryDate.replace(/:/g, "%3A").replace(/ /g, "+"))
                    for(var i=0;i<app.orderdata["arrCargoInfo1"].length;i++){
                        // for(var j=0;j<app.orderdata["arrCargoInfo1"][i].arrAmountInfo.length;j++){
                        //     if(app.orderdata["arrCargoInfo1"][i].arrAmountInfo[j].amountBizType==2){
                        //         app.orderdata["arrCargoInfo1"][i].arrAmountInfo[j].amountBizType=6
                        //     }
                        // }
                        this.data.arrCargoInfo1.push(
                            {
                                cargoID: app.orderdata["arrCargoInfo1"][i].cargoID,
                                cargoName: app.orderdata["arrCargoInfo1"][i].cargoName,
                                model: app.orderdata["arrCargoInfo1"][i].model,
                                valuationMode: app.orderdata["arrCargoInfo1"][i].valuationMode,
                                valuationModeDesc: app.orderdata["arrCargoInfo1"][i].valuationModeDesc,
                                arrAmountInfo: app.orderdata["arrCargoInfo1"][i].arrAmountInfo
                            }

                       )
                    }
                    var options = {
                        port: 'dispatchesPlanCre2',
                        body: {
                            /* "desp":desc,*/
                            "vehicleID": this.data.arr[0].vehicleID,
                            "chiefDriverID": this.data.arr[0].chiefDriverID,
                            "feesTemplateID": null,
                            "arrPaymentModeInfo": arrMode,
                            "arrDispatchPlanInfo": [
                                {
                                    orderID: app.orderID,
                                    arrCargoInfo: this.data.arrCargoInfo1,
                                    paymentModeInfo2: "",
                                    deliveryDate: this.data.deliveryDate,
                                    destinationDate: this.data.destinationDate,
                                    consignorInfo: app.consignorInfoAll,
                                    isDeliveryCentre: false,
                                    deliveryCentreID: null,
                                    consigneeInfo: app.consigneeInfoAll,
                                    isDestinationCentre: app.isDestinationCentre,
                                    destinationCentreID: app.destinationCentreID
                                }
                            ]
                        }
                    }
                    app.connect(options).then(values => {
                        console.log(values)
                        if (values.data.body.content.dispatchBatchID != null) {
                            console.log(789)
                            wx.showToast({
                                title: "调度生成成功",
                                mask: false,
                                icon: "success",
                                duration: 2000,
                                success: function () {
                                    app.orderdata["route"]="newscheduling"
                                    app.orderdata["orderID"] = null
                                        wx.navigateBack({
                                            delta:5,
                                            success:function () {
                                                console.log(123456)
                                                app.orderdata["jumppath"]=true
                                            }
                                        })
                                },
                            })
                        } else {
                            that.pageLoading = !1
                        }
                    })
                }
            }
        }
    },

    onAddother: function () {
        console.log(this.data.i)
        this.data.arr.push(this.data.i++)
        this.data.arr[this.data.i - 1] = {vehiclemodel: "选择载具", driverName: "选择司机"}
        this.setData({
            arr: this.data.arr
        })
        console.log(this.data.arr)
    },
    onindex: function (e) {
        app.newschedulingindex = e.currentTarget.dataset.name
        app.newschedulingindex1 = e.currentTarget.dataset.name
        if (!this.pageLoading) {
            this.pageLoading = !0;
            wx.navigateTo({
                url: '../selectedcarrier/selectedcarrier'
            })
        }
    },
    onindex1: function (e) {
        app.newschedulingindex1 = e.currentTarget.dataset.name
        if (!this.pageLoading) {
            this.pageLoading = !0;
            wx.navigateTo({
                url: '../choosethedriver/choosethedriver'
            })
        }
    },
    onmove: function (e) {
        app.newschedulingindex = 0
        app.newschedulingindex1 = 0
        let idx = e.currentTarget.dataset.name
        let list = this.data.arr
        this.data.i--
        this.data.arr = list.filter((ele, index) => {
            return index != idx
        })
        this.setData({
            arr: this.data.arr
        })
    },
    ontime:function(){
        console.log(this.data. multiIndex)
        var myDate = new Date();
        var a=0;
        var b=0;
        var c=0;
        var d=0;
        var e=0;
        for(var i=89;i<parseInt(myDate.getYear());i++){
            a=a+1
        }
        for(var i=0;i<parseInt(myDate.getMonth());i++){
            b=b+1
        }
        for(var i=1;i<parseInt(myDate.getDate());i++) {
            c = c + 1
        }
        for(var i=0;i<parseInt(myDate.getHours());i++){
            d=d+1
        }
        for(var i=0;i<parseInt(myDate.getMinutes());i++){
            e=e+1
        }
        this.data. multiIndex[0]=a
        this.data. multiIndex[1]=b
        this.data. multiIndex[2]=c
        this.data. multiIndex[3]=d
        this.data. multiIndex[4]=e
        this.setData({
            multiArray:this.data.multiArray,
            multiIndex:this.data. multiIndex
        })

    },
    ontime1:function(){
        var myDate = new Date();
        var a=0;
        var b=0;
        var c=0;
        var d=0;
        var e=0;
        for(var i=89;i<parseInt(myDate.getYear());i++){
            a=a+1
        }
        for(var i=0;i<parseInt(myDate.getMonth());i++){
            b=b+1
        }
        for(var i=1;i<parseInt(myDate.getDate());i++) {
            c = c + 1
        }
        for(var i=0;i<parseInt(myDate.getHours());i++){
            d=d+1
        }
        for(var i=0;i<parseInt(myDate.getMinutes());i++){
            e=e+1
        }
        this.data. multiIndex1[0]=a
        this.data. multiIndex1[1]=b
        this.data. multiIndex1[2]=c
        this.data. multiIndex1[3]=d
        this.data. multiIndex1[4]=e
        this.setData({
            multiArray1:this.data.multiArray1,
            multiIndex1:this.data. multiIndex1
        })
    },

    /*自己组装的时间选择*/
    bindMultiPickerColumnChange: function (e) {
        for(var i=0;i<this.data.multiArray.length;i++){
            for(var j=0;j<this.data.multiArray[i].length;j++) {
                if (i==0) {
                    this.data.multiArray[i][j]=this.data.multiArray[i][j].replace("年","");
                }else if(i==1){
                    this.data.multiArray[i][j]=this.data.multiArray[i][j].replace("月",'')
                }else if(i==2){
                    this.data.multiArray[i][j]=this.data.multiArray[i][j].replace("日",'')
                }else if(i==3){
                    this.data.multiArray[i][j]=this.data.multiArray[i][j].replace("时",'')
                }else if(i==4){
                    this.data.multiArray[i][j]=this.data.multiArray[i][j].replace("分",'')
                }else if(i==5){
                    this.data.multiArray[i][j]=this.data.multiArray[i][j].replace("秒",'')
                }
            }
        }
        console.log(e.detail.column)
        console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
        var data = {
            multiArray: this.data.multiArray,
            multiIndex: this.data.multiIndex
        };
        data.multiIndex = e.detail.value;

        console.log(data)
        this.setData(data);
        this.data.deliveryDate=data.multiArray[0][data.multiIndex[0]]+"-"+data.multiArray[1][data.multiIndex[1]]+"-"+data.multiArray[2][data.multiIndex[2]]+" "+data.multiArray[3][data.multiIndex[3]]+":"+data.multiArray[4][data.multiIndex[4]]+":00"
    },
    bindMultiPickerColumnChange1: function (e) {
        for(var i=0;i<this.data.multiArray.length;i++){
            for(var j=0;j<this.data.multiArray[i].length;j++) {
                if (i==0) {
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("年","");
                    console.log(this.data.multiArray[i][j])
                }else if(i==1){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("月",'')
                }else if(i==2){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("日",'')
                }else if(i==3){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("时",'')
                }else if(i==4){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("分",'')
                }else if(i==5){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("秒",'')
                }
            }
        }
        console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
        var data1 = {
            multiArray1: this.data.multiArray1,
            multiIndex1: this.data.multiIndex1
        };
        data1.multiIndex1 = e.detail.value;
        this.setData(
            data1
        );
        this.data.destinationDate=data1.multiArray1[0][data1.multiIndex1[0]]+"-"+data1.multiArray1[1][data1.multiIndex1[1]]+"-"+data1.multiArray1[2][data1.multiIndex1[2]]+" "+data1.multiArray1[3][data1.multiIndex1[3]]+":"+data1.multiArray1[4][data1.multiIndex1[4]]+":00"
    },

})




