var app = getApp();
Page({
    data: {
        name: '',
    },
    onLoad: function () {
        var body;
        var car;
        var ship;
        console.log(app.vehicletype_name)
        if (app.data.vehicletype_name == "车辆") {
            body = {
                car: "true",
                ship: "false"
            }
        } else {
            body = {
                car: "false",
                ship: "true"
            }
        }
        this.setData({
            shuju: body
        })
    },
    onShow: function () {
        var body;
        var car;
        var ship;
        console.log(app.typeofdriver_name)
        if (app.vehicletype_name == "车辆") {
            body = {
                car: "true",
                ship: "false"
            }
        } else if (app.vehicletype_name == "船舶") {
            body = {
                car: "false",
                ship: "true"
            }
        }
        this.setData({
            shuju: body
        })

    },
    mySelect: function (e) {
        console.log(e.currentTarget.dataset.name)
        this.data.name = e.currentTarget.dataset.name
        var body;
        var car;
        var ship;
        if (this.data.name == "car") {
            app.vehicletype_name = "车辆";
            app.data.loadlength = "车长";
            app.data.carriertype = "车型";
            body = {
                car: "true",
                ship: "false"
            }
        } else if (this.data.name == "ship") {
            app.vehicletype_name = "船舶";
            app.data.carriertype = "船型";
            app.data.loadlength = "航区";
            body = {
                car: "false",
                ship: "true"
            }
        }
        console.log(body.car)
        this.setData({
            shuju: body
        })
        wx.navigateBack({
            delta: -1
        });
    }
})