var app = getApp();
Page({
    onType: function (e) {
        var s = {
            "内河A": 1151000,
            "内河B": 1151010,
            "内河C": 1151020,
            "内河J1": 1151030,
            "内河J2": 1151040,
            "沿海": 1151050,
            "近海": 1151060,
            "近洋": 1151070,
            "远洋": 1151080,
            "其他": 1151090,
        }
        app.navigationarea = e.currentTarget.dataset.name
        app.length = s[e.currentTarget.dataset.name]
        wx.navigateBack({
            delta: -1
        });
    }
})