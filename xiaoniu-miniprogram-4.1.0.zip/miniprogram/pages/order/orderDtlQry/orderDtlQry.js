var app = getApp();
Page({
    data: {
        shuju: '',
        arrCargoInfo:'',
        quality:0,
        numbers:0,
        carryquality:0,
        carrynumbers:0,
        signquality1:0,
        signnumbers:0,
    },
    onReachBottom: function () {
        console.log(333)
    },

    onLoad: function () {
        console.log(app.globalData.userDe)
        app.loads()
        console.log(app.globalData.shfTt)
        var that = this;
        that.setData({
            forward:app.globalData[48],
            shfTt:app.globalData.shfTt,
            btnlocationdefault:app.globalData[15],
            phone:app.globalData[16],
            delivergoods:app.globalData[17],
            collectgoods:app.globalData[18],
        })
        var options = {
            port: 'orderDtlQry2',
            body: {
                "orderID": app.orderID,
                "graphicCode": null,
                "sessionGraphicCode": null
            }
        }

        app.connect(options).then(values => {
            console.log(values)
            that.data.arrCargoInfo=values.data.body.content.arrCargoInfo
            wx.hideLoading()
            if(values.data.body.content.orderStatusInfo.orderStatusDesc=="待执行"&&app.globalData.shfTt==true){
                wx.showModal({
                    title: '提醒',
                    content: '承运人尚未安排车辆/船舶',
                    success: function (res) {
                        if (res.confirm) {//这里是点击了确定以后
                            console.log('用户点击确定')
                            var options = {
                                port: 'messageToDevice',
                            }
                            app.connect(options).then(values => {
                            })
                        } else {//这里是点击了取消以后
                            console.log('用户点击取消')
                        }
                    }
                })
            }
            app.arrCargoInfo= values.data.body.content.arrCargoInfo
            console.log(values)
            values.data.body.content.consignorInfo.addressInfo.cityShortName=app.oncityNam(values.data.body.content.consignorInfo.addressInfo.cityShortName)
            values.data.body.content.consigneeInfo.addressInfo.cityShortName=app.oncityNam(values.data.body.content.consigneeInfo.addressInfo.cityShortName)
            that.data.quality=0
            that.data.numbers=0
            console.log(values.data.body.content.arrCargoInfo)
             for(var i=0;i<values.data.body.content.arrCargoInfo.length;i++){
                 for(var j=0;j< values.data.body.content.arrCargoInfo[i].arrAmountInfo.length;j++){
                     if(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].amountBizType==2){
                         if(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].volume!=0){
                             that.data.quality=Number(that.data.quality)+Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].volume)
                         }
                         if(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].weight!=0){
                             that.data.quality=Number(that.data.quality)+Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].weight)
                         }
                         if(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].quantity!=0){
                             that.data.numbers=Number(that.data.numbers)+Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].quantity)
                         }
                     }
                     if(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].amountBizType==7){
                         if(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].volume!=0){
                             that.data.carryquality=Number(that.data.carryquality)+Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].volume)
                         }
                         if(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].weight!=0){
                             that.data.carryquality=Number(that.data.carryquality)+Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].weight)
                         }
                         if(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].quantity!=0){
                             that.data.carrynumbers=Number(that.data.carrynumbers)+Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].quantity)
                         }
                     }
                     if(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].amountBizType==8){
                         if(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].volume!=0){
                              console.log(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].volume)
                             that.data.signquality1=Number(that.data.signquality1)+Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].volume)
                         }
                         if(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].weight!=0){
                            console.log(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].weight)
                             that.data.signquality1=Number(that.data.signquality1)+Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].weight)
                         }
                         if(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].quantity!=0){
                             that.data.signnumbers=Number(that.data.signnumbers)+Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].quantity)
                         }
                     }
                 }
             }
      //       console.log(app.globalData.userDe.userInfo.companyInfo.adminUserInfo.mobile)
      //      console.log(values.data.body.content.trustorInfo.companyInfo.adminUserInfo.mobile);
            that.setData({
                mobile1:app.globalData.userDe.userInfo.companyInfo.adminUserInfo.mobile,
                company:app.orderdata["company"],
                company1:app.orderdata["company1"],
                carrynumbers:that.data.carrynumbers,
                carryquality:that.data.carryquality,
                signquality:that.data.signquality1,
                signnumbers:that.data.signnumbers,
                numbers:that.data.numbers,
                quality:that.data.quality,
                shuju: values.data.body.content
            })
            var arrAmountInfos = [];
            for (var j = 0; j < values.data.body.content.arrCargoInfo[0].arrAmountInfo.length; j++) {
                var allAmount = {
                    amountBizType: values.data.body.content.arrCargoInfo[0].arrAmountInfo[j].amountBizType,
                    quantity: values.data.body.content.arrCargoInfo[0].arrAmountInfo[j].quantity
                    , quantityUnit: values.data.body.content.arrCargoInfo[0].arrAmountInfo[j].quantityUnit,
                    quantityUnitID: values.data.body.content.arrCargoInfo[0].arrAmountInfo[j].quantityUnitID,
                    volume: values.data.body.content.arrCargoInfo[0].arrAmountInfo[j].volume,
                    weight: values.data.body.content.arrCargoInfo[0].arrAmountInfo[j].weight,
                    weightUnit: values.data.body.content.arrCargoInfo[0].arrAmountInfo[j].weightUnit,
                    weightUnitID: values.data.body.content.arrCargoInfo[0].arrAmountInfo[j].weightUnitID
                }
                arrAmountInfos.push(allAmount)
            }
            var address = {
                cityCode: values.data.body.content.consignorInfo.addressInfo.cityCode,
                cityName: values.data.body.content.consignorInfo.addressInfo.cityName,
                cityShortName: values.data.body.content.consignorInfo.addressInfo.cityShortName,
                addressID: values.data.body.content.consignorInfo.addressInfo.addressID,
                address: values.data.body.content.consignorInfo.addressInfo.address
            }
            var signeeaddress = {
                cityCode: values.data.body.content.consigneeInfo.addressInfo.cityCode,
                cityName: values.data.body.content.consigneeInfo.addressInfo.cityName,
                cityShortName: values.data.body.content.consigneeInfo.addressInfo.cityShortName,
                addressID: values.data.body.content.consigneeInfo.addressInfo.addressID,
                address: values.data.body.content.consigneeInfo.addressInfo.address
            }
            console.log(address)
            console.log(signeeaddress)
            app.amountInfo = arrAmountInfos
            app.cargoID = values.data.body.content.arrCargoInfo[0].cargoID
            app.cargoName = values.data.body.content.arrCargoInfo[0].cargoName
            app.model = values.data.body.content.arrCargoInfo[0].model
            app.valuationMode = values.data.body.content.arrCargoInfo[0].valuationMode
            app.valuationModeDesc = values.data.body.content.arrCargoInfo[0].valuationModeDesc
            app.deliveryDate = values.data.body.content.deliveryDate
            app.destinationDate = values.data.body.content.arrivalDate
            app.consignorInfoAll = {
                linkmanID: values.data.body.content.consignorInfo.linkmanID,
                name: values.data.body.content.consignorInfo.name,
                mobile:
                values.data.body.content.consignorInfo.mobile,
                tel: values.data.body.content.consignorInfo.tel,
                fax: values.data.body.content.consignorInfo.fax
                ,
                companyName: values.data.body.content.consignorInfo.companyName,
                addressInfo: address,
                userID: values.data.body.content.consignorInfo.userID
            }
            if(app.isDeliveryCentre==null){
                app.isDeliveryCentre = false
            }else
                {
                    app.isDeliveryCentre=values.data.body.content.isDeliveryCentre
                }
            app.deliveryCentreID = values.data.body.content.deliveryCentreID
            app.consigneeInfoAll = {
                linkmanID: values.data.body.content.consigneeInfo.linkmanID,
                name: values.data.body.content.consigneeInfo.name,
                mobile:
                values.data.body.content.consigneeInfo.mobile,
                tel: values.data.body.content.consigneeInfo.tel,
                fax: values.data.body.content.consigneeInfo.fax
                ,
                companyName: values.data.body.content.consigneeInfo.companyName,
                addressInfo: signeeaddress,
                userID: values.data.body.content.consigneeInfo.userID
            }
            if(app.destinationCentreID==null){
                app.isDestinationCentre = false
            }else
            {
                app.isDestinationCentre=values.data.body.content.isDestinationCentre.isDestinationCentre
            }
            app.destinationCentreID = values.data.body.content.destinationCentreID

            app.userSimpleInfo={
                userID:values.data.body.content.carrierInfo.userID,
                userName:values.data.body.content.carrierInfo.userName,
                companyID:values.data.body.content.carrierInfo.companyInfo.companyID,
                companyName:values.data.body.content.carrierInfo.companyInfo.companyName,
                orgType: values.data.body.content.carrierInfo.companyInfo.orgType,
                companyType:values.data.body.content.carrierInfo.companyInfo.companyType,
                mobile:values.data.body.content.carrierInfo.mobile,
                portraitPhotoUrl:values.data.body.content.carrierInfo.portraitPhotoUrl,
            }

        })

    },
    chooseimage: function () {
        wx.navigateTo({
            url: '../processinglog/processinglog?type='+1+"&orderID="+app.orderID
        })
    },
    ondispatch: function () {
        var that = this;
        var options = {
            port: 'orderDtlQry2',
            body: {
                "orderID": app.orderID,
                "graphicCode": null,
                "sessionGraphicCode": null
            }
        }
        app.connect(options).then(values => {
            console.log(values)
            app.shuju = values.data.body.content
            if (!this.pageLoading) {
                this.pageLoading = !0;
                wx.navigateTo({
                    url: '../selectionofgoods/selectionofgoods?orderCode=' + values.data.body.content.orderCode,
                })
            }
        })
    },
    onphone:function (e) {
        var phoneNunmber=e.currentTarget.dataset.name
        wx.makePhoneCall({
            phoneNumber: phoneNunmber
        })
    },
    onamount:function (e) {
        var allmoney=e.currentTarget.dataset.name
        wx.navigateTo({
            url: '../contractamount/contractamount?allmoney=' + allmoney,
        })
    },
    ongoods:function () {
        wx.navigateTo({
            url: '../thegoods/thegoods'
        })
    },
    onShow:function () {
        this.pageLoading = !1
    },
    onDispatch:function (e) {
        app.orderdata["orderID"]=e.currentTarget.dataset.name,
        wx.navigateTo({
            url: '../../dispatchlist/list/list'
        })
    },
    onCargodetails:function () {
        app.orderdata["arrCargoInfo"]=this.data.arrCargoInfo
        wx.navigateTo({
            url: '../cargodetails/cargodetails'
        })
    }


})
