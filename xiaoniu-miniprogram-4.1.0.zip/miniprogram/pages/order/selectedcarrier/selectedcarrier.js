var app = getApp();
Page({
    data:{
      index:0,
        alldata:[],

    },
    /*下拉刷新*/
    onPullDownRefresh() {
        this.data.index=0
        this.data.alldata.splice(0, this.data.alldata.length);
        this.onLoad().then(values => {
            wx.stopPullDownRefresh()
        })
    },
    onReachBottom: function () {
        this.data.index=this.data.index+1
        var options = {
            port: 'vehicleListQry3',
            body: {
                isMyVehicle: true,
                "pageIndex": this.data.index,
                "pageSize": 10,
            }
        }
            app.connect(options).then(values => {
                for(var i=0;i<values.data.body.content.arrVehicleAbstractInfo.length;i++){
                    if(values.data.body.content.arrVehicleAbstractInfo[i].arrCityInfo.length!="0") {
                        values.data.body.content.arrVehicleAbstractInfo[i].arrCityInfo[0].cityName = app.oncityNam(values.data.body.content.arrVehicleAbstractInfo[i].arrCityInfo[0].cityName)
                    }
                }
           for(var i=0;i<values.data.body.content.arrVehicleAbstractInfo.length;i++){
               this.data.alldata[0].push(values.data.body.content.arrVehicleAbstractInfo[i])
           }
                this.setData({
                    shuju: this.data.alldata[0]
                })
            })
    },
    nextstep: function () {
        if (!this.pageLoading) {
            this.pageLoading = !0;
            wx.navigateTo({
                url: '../addingtool/addingtool'
            })
        }
    },
    onLoad: function (e) {
        app.loads()
        this.setData({
            carimage:app.globalData[22],
            shipimage:app.globalData[23],
        })
        console.log(e)
        var that = this;
        var options = {
            port: 'vehicleListQry3',
            body: {
                isMyVehicle: true,
                "pageIndex": this.data.index,
                "pageSize": 10,
                "graphicCode": null,
                "sessionGraphicCode": null
            }
        }
        let prom1 = new Promise(function (resolve, reject) {
            app.connect(options).then(values => {
                wx.hideLoading()
                console.log(values)
                for(var i=0;i<values.data.body.content.arrVehicleAbstractInfo.length;i++){
                    if(values.data.body.content.arrVehicleAbstractInfo[i].arrCityInfo.length!="0") {
                        values.data.body.content.arrVehicleAbstractInfo[i].arrCityInfo[0].cityName = app.oncityNam(values.data.body.content.arrVehicleAbstractInfo[i].arrCityInfo[0].cityName)
                    }
                }
                that.data.alldata.push(values.data.body.content.arrVehicleAbstractInfo)
                that.setData({
                    shuju: values.data.body.content.arrVehicleAbstractInfo
                })
                resolve(values)
            })
        });
        return prom1;



    },
    onShow: function () {
        this.pageLoading = !1
        this.onLoad();
        app.selection = "";
        app.shipName = "";
        app.carmoderlName = "";
        app.lengthValue = "";
        app.navigationarea = "";

    },
    onSelect: function () {
    },
    oncarrierList: function (e) {
        var s=e.currentTarget.dataset.id.split(",")
        app.vehicleID = s[0],
            app.orderdata["isFree"]=s[1]
        console.log(app.newschedulingindex)
        if(app.newschedulingindex==0) {
            app.vehicleID1=s[0]
        }
        app.vehiclepropertye = e.currentTarget.dataset.name
        wx.navigateBack({
            delta: -1
        });

    },
    oncarrieroneList: function (e) {
        console.log(e.currentTarget.dataset.name)
        app.vehiclemodel = e.currentTarget.dataset.name
    }
})