var amapFile = require('libs/amap-wx.js');
var app = getApp();
Page({

    data: {
        markers:[],
        distance: '',
        cost: '',
        polyline: [],
        points:[]
    },
    onLoad: function(e) {

        var that = this;
        var options = {
            port: 'traceLocationListQry',
            body: {
                "dispatchID": e.dispatchID
            }
        };
        app.connect(options).then(values => {
            console.log(values)
                if(values.data.body.content.arrLocationInfo.length!=0){
                for(var i=0;i<values.data.body.content.arrLocationInfo.length;i++){
                    console.log(values.data.body.content.arrLocationInfo.length)
                    var params={
                             longitude: values.data.body.content.arrLocationInfo[i].longitude,
                            latitude: values.data.body.content.arrLocationInfo[i].latitude
                    }

                    var param={
                        iconPath: "../../img/mapicon_navi_s.png",
                            id: 0,
                        latitude: values.data.body.content.arrLocationInfo[i].latitude,
                        longitude: values.data.body.content.arrLocationInfo[i].longitude,
                        width: 23,
                        height: 33
                    }
                    that.data.points.push(params)
                    that.data.markers.push(param)
                }
                that.setData({
                    markers:that.data.markers,
                    longitude:values.data.body.content.arrLocationInfo[0].longitude,
                    latitude:values.data.body.content.arrLocationInfo[0].latitude
                })

            }
            var myAmapFun = new amapFile.AMapWX({key: '30de66312b16a7762a50bcd5fd3f7b30'});
            myAmapFun.getDrivingRoute({
                origin: '116.2317,39.5427',
                destination: '121.488182,31.286798',
                success: function(){
                    that.setData({
                        polyline: [{
                            points: that.data.points,
                            color: "#9F4C9D",
                            width: 4
                        }]
                    });
                },
                fail: function(info){
                    that.setData({
                        polyline: [{
                            points: that.data.points,
                            color: "#9F4C9D",
                            width: 4
                        }]
                    });
                }
            })


        })


    },

    showGaodeMapView: function(){
        var points = [];
        points.push({
            longitude: 116.3317,
            latitude: 39.5427
        })
        points.push({
            longitude: 117.2517,
            latitude: 40.7427
        })
        points.push({
            longitude: 117.2617,
            latitude: 40.5777
        })
        points.push({
            longitude: 118.2367,
            latitude: 39.85427
        })
        this.setData({
            polyline: [{
                points: points,
                color: "#9F4C9D",
                width: 12
            }]
        });
    },
    goDetail: function(){
        wx.navigateTo({
            url: '../navigation_car_detail/navigation'
        })
    },
    goToCar: function (e) {
        wx.redirectTo({
            url: '../navigation_car/navigation'
        })
    },
    goToBus: function (e) {
        wx.redirectTo({
            url: '../navigation_bus/navigation'
        })
    },
    goToRide: function (e) {
        wx.redirectTo({
            url: '../navigation_ride/navigation'
        })
    },
    goToWalk: function (e) {
        wx.redirectTo({
            url: '../navigation_walk/navigation'
        })
    }

})