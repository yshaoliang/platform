var app=getApp();
Page({
    onLoad:function () {
        this.setData({
            arrCargoInfo:app.arrCargoInfo
        })
    }
})