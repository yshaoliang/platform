var app = getApp();
Page({
    data:{
        params:''
    },
    onLoad:function (e) {
        var that=this;
        wx.getStorage({
            key:"token",
            success:function (res) {
                console.log(res)
                var param={
                    userID :app.globalData.userDe.userInfo.userID,
                    token :res.data,
                    appSecret : app.data.appSecret,
                    appKey : app.data.appKey,
                    deviceType : 'WEB',
                    version : '1.0.1'
                }
                console.log(param)
                var params=that.encode64(JSON.stringify(param));
                console.log(params)
                that.data.params=params;
                console.log(e.src+app.globalData.userDe.userInfo.companyInfo.companyID+'/'+app.globalData.userDe.userInfo.userID,);
                if(app.data.appName=="顺利运"||app.data.appName=="昆仑云通"){
                    that.setData({
                        sweepCodeValue:e.src+"?params="+that.data.params
                        /*/!*  sweepCodeValue:*!/*/
                        /*sweepCodeValue:"http://192.168.1.66:8089/xiaoniu-niu/api/appApi/huaXiaBank/account"+"?params="+that.data.params*/

                    })
                }else if(app.data.appName=="西南大运"){
                    that.setData({
                        sweepCodeValue:e.src+app.globalData.userDe.userInfo.companyInfo.companyID+'/'+app.globalData.userDe.userInfo.userID,
                        /*/!*  sweepCodeValue:*!/*/
                        /*sweepCodeValue:"http://192.168.1.66:8089/xiaoniu-niu/api/appApi/huaXiaBank/account"+"?params="+that.data.params*/

                    })
                }

            }
        });
    },

    handleGetMessage: function(e) {
        console.log(e);
        /* var that = this;
         //接受h5页面传过来的参数
         var data = e.detail.data;
         var wboid= data[0].wboid;
         that.setData({
             url:"https://....wboid="+wboid
         })*/
    },

    encode64: function (input) {
        // base64加密开始
        var keyStr = "ABCDEFGHIJKLMNOP" + "QRSTUVWXYZabcdef" + "ghijklmnopqrstuv"
            + "wxyz0123456789+/" + "=";
        var output = "";
        var chr1, chr2, chr3 = "";
        var enc1, enc2, enc3, enc4 = "";
        var i = 0;
        do {
            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);
            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;
            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }
            output = output + keyStr.charAt(enc1) + keyStr.charAt(enc2)
                + keyStr.charAt(enc3) + keyStr.charAt(enc4);
            chr1 = chr2 = chr3 = "";
            enc1 = enc2 = enc3 = enc4 = "";
        } while (i < input.length);

        return output;
    },
})