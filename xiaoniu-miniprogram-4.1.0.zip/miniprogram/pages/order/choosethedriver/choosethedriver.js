var app = getApp();
Page({
    data:{
        index:0,
        alldatas:[],
        alldatas1:[]
    },
    /*下拉刷新*/
    onPullDownRefresh() {
        this.data.index=0
        this.data.alldatas.splice(0, this.data.alldatas.length);
        this.onLoad().then(values => {
            wx.stopPullDownRefresh()
        })
    },
    onReachBottom: function () {
        this.data.index=this.data.index+1
        var options = {
            port: 'driverListQry2',
            body: {
                "pageIndex": this.data.index,
                "pageSize": 10,
            }
        }
            app.connect(options).then(values => {
                console.log(values)
                for(var i=0;i<values.data.body.content.arrDriverInfo.length;i++){
                    this.data.alldatas[0].push(values.data.body.content.arrDriverInfo[i])
                }
                this.setData({
                    shuju: this.data.alldatas[0]
                })
            })
    },
    /*数据加载*/
    onShow: function () {
        this.pageLoading = !1
        this.onLoad()
    },
    /*数据加载*/
    onLoad: function () {
        app.loads()
        this.setData({
            headurl:app.globalData[13],
        })
        var that = this;
        var options = {
            port: 'driverListQry2',
            body: {
                "pageIndex": that.data.index,
                "pageSize": 10,
            }
        }
        let prom1 = new Promise(function (resolve, reject) {
        app.connect(options).then(values => {
            wx.hideLoading()
            that.data.alldatas.push(values.data.body.content.arrDriverInfo)
            that.setData({
                shuju: values.data.body.content.arrDriverInfo
            })
            resolve(values)
        })
        });
        return prom1;
    },
    /*跳转页面*/
    nextstep: function () {
        if (!this.pageLoading) {
            this.pageLoading = !0;
            app.selection=""
            wx.navigateTo({
                url: '../adddriver/adddriver',
            })
        }
    },
    /*获取页面数据*/
    onchoosetheDriver: function (e) {
        app.driverID=e.currentTarget.dataset.id
        app.driverName = e.currentTarget.dataset.name
        wx.navigateBack({
            delta: -1
        });
    },
    /*获取页面数据*/
    onchoosethemobileDriver: function (e) {
        app.drivermobile = e.currentTarget.dataset.name
        if(app.newschedulingindex1==0) {
            app.chiefDriverID = e.currentTarget.dataset.id
        }
    },
    onSelectdata: function (e) {
        console.log(e.detail.value)
        this.data.alldatas1.splice(0,this.data.alldatas1.length);
        if (e.detail.value!="") {
            for (var i = 0; i < this.data.alldatas[0].length; i++) {
                if (this.data.alldatas[0][i].name.indexOf(e.detail.value) != -1 || this.data.alldatas[0][i].mobile.indexOf(e.detail.value) != -1) {
                    this.data.alldatas1.push(this.data.alldatas[0][i])
                }
            }
            console.log(this.data.alldatas1)
            this.setData({
                shuju: this.data.alldatas1
            })
        }else{
            this.onLoad()
        }
    }
})