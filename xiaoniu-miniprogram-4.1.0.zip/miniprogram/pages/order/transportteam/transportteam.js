var app = getApp();
Page({
    data: {
        size: '',
    },
    onLoad: function () {
        var that = this;
        var options = {
            port: 'transportTeamQry',
            body: {
                "pageIndex": 0,
                "pageSize": 5,
                "graphicCode": null,
                "sessionGraphicCode": null
            }
        }
        app.connect(options).then(values => {
            console.log(values)
            that.setData({
                shuju: values.data.body.content.arrVehicleTeamInfo
            })
        })
    },
    onvehicleselection: function (e) {
        console.log(e.currentTarget.dataset.name)
        app.orderdata["teamID"]=e.currentTarget.dataset.id
        app.selection = e.currentTarget.dataset.name
        wx.navigateBack({
            delta: -1
        });

    }


})