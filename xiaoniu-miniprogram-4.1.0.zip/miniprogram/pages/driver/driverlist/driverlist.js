var app=getApp();
Page({
    data:{
        index:0,
        alldatas:[],
        alldatas1:[],
        name:null,
        mobile: null,
        data:[]
    },
    /*下拉刷新*/
    onPullDownRefresh() {
        this.data.index=0
        this.data.alldatas.splice(0, this.data.alldatas.length);
        this.onShow().then(values => {
            wx.stopPullDownRefresh()
        })
    },
    onReachBottom: function () {
        app.loads()
        this.data.index=this.data.index+1
        if(this.data.name!=null){
            var options = {
                port: 'driverListQry2',
                body: {
                    name:this.data.name,
                    "pageIndex": this.data.index,
                    "pageSize": 10,
                }
            }
            app.connect(options).then(values => {
                var is=true;
                for(var j=0;j<values.data.body.content.arrDriverInfo.length;j++){
                    for(var i=0;i<this.data.data.length;i++){
                        if(values.data.body.content.arrDriverInfo[j].mobile==this.data.data[i].mobile){
                            is=false;
                        }
                    }
                    if(is==true){
                        this.data.data.push(values.data.body.content.arrDriverInfo[j])
                    }
                }

                var options = {
                    port: 'driverListQry2',
                    body: {
                        mobile:this.data.mobile,
                        "pageIndex": this.data.index,
                        "pageSize": 10,
                    }
                }
                app.connect(options).then(values => {

                    console.log(values)
                    var is=true;
                    for(var j=0;j<values.data.body.content.arrDriverInfo.length;j++){
                        for(var i=0;i<this.data.data.length;i++){
                            console.log(values.data.body.content.arrDriverInfo[j].mobile)
                            console.log(this.data.data[i].mobile)
                            if(values.data.body.content.arrDriverInfo[j].mobile==this.data.data[i].mobile){
                                is=false;
                            }
                        }
                        if(is==true){
                            this.data.data.push(values.data.body.content.arrDriverInfo[j])
                        }
                    }
                    wx.hideLoading();
                    console.log(this.data.data)
                    this.setData({
                        shuju: this.data.data
                    })
                })
            })
        }else{
            var options = {
                port: 'driverListQry2',
                body: {
                    "pageIndex": this.data.index,
                    "pageSize": 10,
                }
            }
            app.connect(options).then(values => {
                console.log(values)
                for(var i=0;i<values.data.body.content.arrDriverInfo.length;i++){
                    this.data.alldatas[0].push(values.data.body.content.arrDriverInfo[i])
                }
                console.log(this.data.alldatas[0])
                wx.hideLoading();
                this.setData({
                    shuju: this.data.alldatas[0]
                })
            })
        }



    },
    onShow: function () {

        this.pageLoading = !1
        app.loads()
        this.setData({
            headurl:app.globalData[13],
        })
        var  that= this;
        that.data.index=0;
        that.data.name=null;
        that.data.mobile=null;
        var options = {
            port: 'driverListQry2',
            body: {
                "pageIndex": that.data.index,
                "pageSize": 10,
                "graphicCode": null,
                "sessionGraphicCode": null
            }
        }
        let prom1 = new Promise(function (resolve, reject) {
            app.connect(options).then(values => {
                wx.hideLoading()
                console.log(values)
                that.data.alldatas.push(values.data.body.content.arrDriverInfo)
                console.log(that.data.alldatas)
                that.setData({
                    shuju: values.data.body.content.arrDriverInfo
                })
                resolve(values)
            })
        });
        return prom1;
    },
    /*跳转页面*/
    nextstep: function () {
        app.orderdata["teamID"]=""
        app.selection = ""
        if (!this.pageLoading) {
            this.pageLoading = !0;
            wx.navigateTo({
                url: '../../order/adddriver/adddriver',
            })
        }
    },
    onchoosetheDriver:function (e) {
        if (!this.pageLoading) {
            this.pageLoading = !0;
            wx.navigateTo({
                url: '../driverdetails/driverdetails?driverID=' + e.currentTarget.dataset.name,
            })
        }
    },

    searchBtn: function (e) {
        console.log(e.detail.value)
        var that = this;
        app.loads()
        that.data.index=0;
        that.data.name=e.detail.value;
        that.data.mobile=e.detail.value;
        var options = {
            port: 'driverListQry2',
            body: {
                name:e.detail.value,
                "pageIndex": that.data.index,
                "pageSize": 10,
                "graphicCode": null,
                "sessionGraphicCode": null
            }
        }
        app.connect(options).then(values => {
            console.log(values)
            console.log(that.data.alldatas.length)

            that.data.data.splice(0,that.data.data.length);
            that.data.alldatas.splice(0,that.data.alldatas.length);
            if(values.data.body.content.arrDriverInfo.length!=0){
                that.data.alldatas.push(values.data.body.content.arrDriverInfo)
            }
            console.log(that.data.alldatas)
            var options = {
                port: 'driverListQry2',
                body: {
                    mobile:e.detail.value,
                    "pageIndex": that.data.index,
                    "pageSize": 10,
                    "graphicCode": null,
                    "sessionGraphicCode": null
                }
            }
            app.connect(options).then(values => {
                wx.hideLoading()
                console.log(values)
                console.log(that.data.alldatas)
                if(values.data.body.content.arrDriverInfo.length!=0){
                    if(that.data.alldatas.length!=0){
                        var is=true;
                        for(var i=0;i<values.data.body.content.arrDriverInfo.length;i++){
                            for(var j=0;j<that.data.alldatas[0].length;j++){
                                console.log(values.data.body.content.arrDriverInfo[i].mobile)
                                console.log(that.data.alldatas[0][j].mobile)
                                if(values.data.body.content.arrDriverInfo[i].mobile==that.data.alldatas[0][j].mobile)
                                {
                                    is=false;

                                }
                            }
                            if(is==true){
                                that.data.alldatas.push(values.data.body.content.arrDriverInfo[i])
                            }
                        }
                    }else{
                        that.data.alldatas.push(values.data.body.content.arrDriverInfo)
                    }
                }
                console.log(that.data.alldatas)
                var data=[];
                if(that.data.alldatas.length>1){
                    for(var i=0;i<that.data.alldatas.length;i++){
                        if(i==0){
                            for(var j=0;j<that.data.alldatas[0].length;j++){
                                data.push(that.data.alldatas[0][j])
                                that.data.data.push(that.data.alldatas[0][j])
                            }
                        }else{
                            data.push(that.data.alldatas[i])
                            that.data.data.push(that.data.alldatas[i]);
                        }
                    }
                }else{
                    for(var i=0;i<that.data.alldatas[0].length;i++){
                        data.push(that.data.alldatas[0][i])
                        that.data.data.push(that.data.alldatas[0][i]);
                    }
                }
                console.log(data)
                that.setData({
                    shuju: data
                })
            })
        })
    },


})