var app = getApp();
var publish = require('../../public_util/publishData');
Page({
  onLoad: function(e) {
    app.loads()
    app.driverID = e.driverID
    var options = {
      port: 'driverDtlQry3',
      body: {
        driverID: e.driverID
      }
    }
    app.connect(options).then(values => {
      wx.hideLoading()
      console.log(values)
      if (values.data.body.code = "-99") {
        app.onRelanding()
      }
      this.setData({
        shuju: values.data.body.content.driverInfo
      })
      // for (let i = 0; i < publish.driverLicenseTypes.length; ++i) {
      //   if (values.data.body.content.driverInfo.driverLicenseType == publish.driverLicenseTypes[i].codeId) {
      //     this.setData({
      //       driveType: publish.driverLicenseTypes[i].codeName
      //     })
      //   }
      // }
    })
  },

  onconfirm: function(e) {
    console.log(e.currentTarget.dataset.name)
    if (!this.pageLoading) {
      this.pageLoading = !0;
      wx.navigateTo({
        url: '../../order/adddriver/adddriver?driverID=' + e.currentTarget.dataset.name
      })
    }
  },
  onShow: function() {
    if (app.driverID != undefined) {
      var options = {
        port: 'driverDtlQry3',
        body: {
          driverID: app.driverID
        }
      }
      app.connect(options).then(values => {
        console.log(values)
        this.setData({
          shuju: values.data.body.content.driverInfo
        })
        for (let i = 0; i < publish.driverLicenseTypes.length; ++i) {
          if (values.data.body.content.driverInfo.driverLicenseType == publish.driverLicenseTypes[i].codeId) {
            this.setData({
              driveType: publish.driverLicenseTypes[i].codeName
            })
          }
        }
        this.setData({
          idNumberDm: values.data.body.content.driverInfo.idNumber.substring(0, 4) + '******' + values.data.body.content.driverInfo.idNumber.substring(values.data.body.content.driverInfo.idNumber.length - 4) 
        })     
      })
    }
    this.pageLoading = !1
  },
  previewImage: function(e) {
    console.log(e.currentTarget.dataset.name)
    wx.previewImage({
      urls: [e.currentTarget.dataset.name]
    })
  },

  // function numberToFixed(value) {
  //   for (let i = 0; i < publish.driverLicenseTypes.length; ++i) {
  //     if (value == publish.driverLicenseTypes[i].codeId) {
  //       return publish.driverLicenseTypes[i].codeName;
  //       break
  //     }
  //   }
  // }
// function formatIdcard(value){

//     var val = ''
// if(value) {
//       
//     }
// return val;
//   }


})