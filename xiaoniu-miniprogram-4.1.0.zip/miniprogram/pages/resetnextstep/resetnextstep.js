//订单详情页面
var app = getApp();
Page({
    data: {
        access_token: '',
        imgRds:app.globalData[50],
        imgRd:app.globalData[1],
        imgRd6:app.globalData[6],
        idFrontPhotoFileID:"",
        idBackPhotoFileID:"",
        licensePhotoFileID:"",
        idFrontPhotoFileUrl:"",
        idBackPhotoFileUrl:"",
        licensePhotoFileUrl:"",
        recentPhotoFileID:"",
        recentPhotoFileUrl:"",
        idNumber:"",
        realNameVal:""
    },

    onLoad: function (event) {
        console.log(event);
        this.setData({
            recentPhotoFileUrl:null,
            Ntevn:event,
        })
    var that = this;
    var url = "https://aip.baidubce.com/oauth/2.0/token";
    var datas = {
      grant_type: "client_credentials",
      client_id: "XG8eM7GVGLuXepax8kczamzf",
      client_secret: "MGWGt1d9zZ5hkWPjffn2y5EjtjO4ZNDw"
    }
    wx.request({
      data: datas,
      header: { 'content-type': 'application/x-www-form-urlencoded' },
      url: url,
      method: 'POST',
      success: function (res) {
        console.log(res)
        that.data.access_token = res.data.access_token
        console.log(that.data.access_token)
      },
      fail: function (event) {
        console.log(event)
      },
    })
    },

    /*realName获取真实姓名*/
    realName:function (event) {
        this.data.realNameVal=event.detail.value
        this.setData({
            realNameVal : event.detail.value,
        })
    },
    /*realSfzhm获取身份证号码*/
    realSfzhm:function (event) {
        var that=this;
      if (event.detail.value != "") {
          that.data.idNumber = event.detail.value
      }
    },
    /*数据保存,提交*/
    subVal: function(event) {
        var options = {
            port: 'realnameRegister2',
            body: {
                "app_key":app.data.appKey,
                "companyType":2541030,
                "name": this.data.realNameVal,
                "idNumber": this.data.idNumber,
                "mobile": this.data.Ntevn.sjhmVal,
                "captcha": this.data.Ntevn.yzmVal,
                "password": this.data.Ntevn.szmmVal,
                "idcardFrontPhotoId":this.data.idFrontPhotoFileID,
                "idcardBackPhotoId":this.data.idBackPhotoFileID,
                "drivingLicensePhotoId":this.data.licensePhotoFileID,
                "portraitPhotoFileID":this.data.recentPhotoFileID
            }
        };
        console.log(options)
        app.connect(options).then(values => {
            console.log(values)
            //存储当前用户的详情
            app.globalData.userDe = values.data.body.content;
            wx.setStorageSync('token', values.data.header.token);
            if (values.data.body.content!=null) {
            wx.showModal({
                title: '提示',
                content: '注册成功',
                showCancel: false,
                success: function () {
                app.isRegister=true
                    wx.navigateTo({
                        url: '../order/addingtool/addingtool',
                    })
                }
            })
        }else{
                wx.showModal({
                    title: '提示',
                    content: values.data.body.desc,
                    showCancel: false,

                })
            }
        })
    },

    chooseimage1: function (e) {
        var type=e.currentTarget.dataset.name
        var _this = this;
        wx.chooseImage({
            count: 1, // 默认9
            sizeType: ['original','compressed'], // 可以指定是原图还是压缩图，默认二者都有
            sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
            success: function (res) {
                // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
                console.log(res.tempFiles)
                var tempFilePaths = res.tempFilePaths;
                console.log(tempFilePaths)
                _this.upload(type,_this, tempFilePaths);
                _this.setData({
                    tempFilePaths2: res.tempFilePaths
                })
            }
        })
    },

    upload:function (type,page, path) {
        console.log(type)
        console.log(path[0])
        var bizCode;
        if(type=="cardFront"||type=="cardside"){
            bizCode="2"
        }else{
            bizCode="3"
        }
        wx.showToast({
            icon: "loading",
            title: "正在上传"
        }),
            wx.uploadFile({
                url: app.data.allDomainNameUrl+'unauthFileUpload',
                filePath: path[0],
                name: 'file',
                formData:{
                    bizCode:bizCode,
                    privateField:"",
                    app_key:app.data.appKey,
               },
                header: {
                    "Content-Type": "multipart/form-data"
                },
                success: function (res) {
                    var s=JSON.parse(res.data)
                    console.log(s)
                    if(type=="cardFront"){
                        console.log(1)
                        page.data.idFrontPhotoFileID=s.body.content.fileID,
                        page.data.idFrontPhotoFileUrl=s.body.content.fileUrl
                        page.setData({
                            idFrontPhotoFileUrl: page.data.idFrontPhotoFileUrl,
                        })
                        //ocr识别
                      var url = "https://aip.baidubce.com/rest/2.0/ocr/v1/idcard";
                      const fs = wx.getFileSystemManager();
                      fs.readFile({
                        filePath: path[0],
                        encoding: "base64",
                        success: function (data) {
                          wx.showToast({
                            icon: "loading",
                            title: "正在识别"
                          })
                          var s = data.data.replace("\n", "");
                          var datas = {
                            access_token: page.data.access_token,
                            image: s,
                            id_card_side: "front",
                            detect_direction: "true",
                            detect_risk: "true"
                          }
                          wx.request({
                            data: datas,
                            header: { 'content-type': 'application/x-www-form-urlencoded' },
                            url: url,
                            method: 'POST',
                            success: function (res) {
                              wx.hideToast();
                              console.log(res)
                                page.data.idNumber= res.data.words_result.公民身份号码.words
                              page.setData({
                                idNumber: res.data.words_result.公民身份号码.words
                              })
                            },
                            fail: function (event) {
                              console.log(event)

                            },
                          })
                        }
                      })
                    }
                    if(type=="cardside"){
                        console.log(2)
                        page.data.idBackPhotoFileID=s.body.content.fileID
                        page.data.idBackPhotoFileUrl=s.body.content.fileUrl
                        page.setData({
                            idBackPhotoFileUrl: page.data.idBackPhotoFileUrl,
                        })
                    }
                    if(type=="drivecard"){
                        console.log(3)
                        page.data.licensePhotoFileID=s.body.content.fileID
                        page.data.licensePhotoFileUrl=s.body.content.fileUrl
                        page.setData({
                            licensePhotoFileUrl: page.data.licensePhotoFileUrl,
                        })

                    }
                    if(type=="headportrait"){
                        console.log(4)
                        page.data.recentPhotoFileID=s.body.content.fileID
                        page.data.recentPhotoFileUrl=s.body.content.fileUrl
                        page.setData({
                            recentPhotoFileUrl: page.data.recentPhotoFileUrl,
                        })

                    }
                    if (res.statusCode != 200) {
                        wx.showModal({
                            title: '提示',
                            content: '上传失败',
                            showCancel: false
                        })
                        return;
                    }
                    var data = res.data
                    page.setData({  //上传成功修改显示头像
                        src: path[0]
                    })
                },
                fail: function (e) {
                    console.log(e);
                    wx.showModal({
                        title: '提示',
                        content: '上传失败',
                        showCancel: false
                    })
                },
                complete: function () {
                    wx.hideToast();  //隐藏Toast
                }
            })
    },






});
