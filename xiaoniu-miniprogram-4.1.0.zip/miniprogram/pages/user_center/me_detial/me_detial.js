//订单详情页面
var util = require('../../login/md5.js');
var template = require('../../tabbar/tabbar.js');
var app = getApp();
Page({
    data: {
        imgRd:app.globalData[1],
        imgRd6:app.globalData[6],
        imgRd56:app.globalData[56],
        typeMd:"",
    },

    onLoad: function () {
        console.log(app.globalData.userDe)
        if(app.globalData.userDe.userInfo.addressInfo == null){
            this.setData({
                cityShortName:""
            })
        }else{
            this.setData({
                cityShortName : app.oncityNam(app.globalData.userDe.userInfo.addressInfo.cityShortName)
            })
        }

        //获取全局域中的用户详情
        this.setData({
            typeMd:app.globalData.userDe,
        });

    },

    /*跳转回单*/
    returnPage:function (event) {
        wx.navigateTo({
      url: '../../supplygoods/public_page/returnpage/returnpage?light1='+ this.data.light1+'&light2='+this.data.light2+'&light3='+this.data.light3+'&myclerd='+ this.data.myclerd
    })
    },

});
