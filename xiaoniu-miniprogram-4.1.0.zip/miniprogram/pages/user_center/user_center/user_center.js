//订单详情页面
var util = require('../../login/md5.js');
var template = require('../../tabbar/tabbar.js');
var app = getApp();
Page({
    data: {
        imgRd:app.globalData[1],
        imgRd6:app.globalData[6],
    },

    onLoad: function () {
        //获取全局域中的用户详情
        if(app.globalData.userDe.userInfo.addressInfo == null){
            this.setData({
                cityShortName:""
            })
        }else{
            this.setData({
                cityShortName : app.oncityNam(app.globalData.userDe.userInfo.addressInfo.cityShortName)
            })
        }
        this.setData({
            typeMd:app.globalData.userDe,
        });
    },

    //跳转到重置秘密
    restPass:function(){
    wx.redirectTo({
        url:'/pages/user_center/reset_pass/reset_pass',
    })
    },

    //跳转用户保存
    skipUser:function(){
        wx.redirectTo({
            url:'/pages/user_center/user_detial/user_detial',
        })
    },

    /*用户退出*/
    signOut:function (event) {
        //首先提示是否退出
        wx.showModal({
            title:"确定是否退出",
            content:"退出登录之后，您将不再继续收到消息，确定要退出吗？",
            showCancel:true,
            //用户确定
            success:function (res) {
                if (res.confirm){
                    //清除缓存中数据
                    wx.removeStorageSync('token');
                    //实现跳转
                    wx.reLaunch({
                        url:'/pages/login/login',
                    });
                }
            },
            //退出失败，可能一些原因导致
            fail:function (res) {
                wx.showToast({
                    title:"退出失败,请反馈",
                    duration:1500,
                });
            },
        });
    },

});
