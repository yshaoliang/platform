//订单详情页面
var util = require('../../login/md5.js');
var template = require('../../tabbar/tabbar.js');
var app = getApp();
var interval = null //倒计时函数
Page({
    data: {
        imgRd:app.globalData[1],
        imgRd6:app.globalData[6],
        date:'请选择日期',
        fun_id:2,
        time: '获取验证码', //倒计时
        currentTime:61,
    },

    onLoad: function () {

    },

    /*sjh获取手机号码*/
    sjhm:function (event) {
        this.setData({
            sjhmVal:event.detail.value,
        })
    },
    /*yzm获取验证码*/
    yzm:function (event) {
        this.setData({
            yzmVal:event.detail.value,
        })
    },

    /*qrmm新密码*/
    qrmm:function (event) {
        this.setData({
            qrmmVal:event.detail.value,
        })
    },

    /*验证码的倒计时*/
    getCode: function (options){
        var that = this;
        var currentTime = that.data.currentTime
        interval = setInterval(function () {
            currentTime--;
            that.setData({
                time: currentTime+'秒'
            })
            if (currentTime <= 0) {
                clearInterval(interval)
                that.setData({
                    time: '重新发送',
                    currentTime:61,
                    disabled: false
                })
            }
        }, 1000)
    },

    /*验证码的获取*/
    getVerificationCode(event){
        this.getCode();
        var that = this
        that.setData({
            disabled:true
        })
        var options = {
            port: 'getCaptcha',
            body: {
                "mobile":this.data.sjhmVal,
                "bizCode":2,
            }
        };
        app.connect(options).then(values => {
            console.log(values);
            if (values.data.body.code == -1){
                wx.showModal({
                    title: "获取失败",
                    content:values.data.body.desc,
                    showCancel:false,
                    duration: 1500,
                });
            }
        });
    },



    /*subMM重置密码的按钮*/
    subMM:function () {
        if (this.data.sjhmVal == null || this.data.yzmVal == null || this.data.qrmmVal== null){
            wx.showModal({
                title: '修改失败',
                content:'填写信息错误',
                showCancel:false,
                duration: 1500,
               });
            return ;
        };

        var options = {
            port: 'passwordUpd',
            body: {
                "mobile":this.data.sjhmVal,
                "captcha":this.data.yzmVal,
                "newPassword":this.data.qrmmVal,
            }
        };
        app.connect(options).then(values => {
            var that = this;
            console.log(values);
            wx.showToast({
                title: '修改成功',
                icon: 'success',
                duration: 2000,
                success:function () {
                    //实现跳转

                        wx.reLaunch({
                            url:'/pages/login/login',
                        })
                }
            })
        });
    },

});
