//订单详情页面
var template = require('../../public_util/publishData.js');
var app = getApp();
Page({
    data: {
        imgRd:app.globalData[1],
        imgRd6:app.globalData[6],
        imgRd56:app.globalData[56],
        imgRd57:app.globalData[57],
        imgRd58:app.globalData[58],
        imgRd59:app.globalData[59],
        typeMd:'',
        bindData:'',
        showView: true,
    },



    onLoad: function () {
        wx.redirectTo('')

        console.log(app.data.appName)
        this.setData({
            companyAgentCode:app.data.appName,
            bindData: template.tabbars,
            thisSel:2,

        });
        //获取全局域中的用户详情
        this.setData({
            typeMd:app.globalData.userDe,
        })
        console.log(this)
      
    },

    /*跳转回单*/
    returnPage:function (event) {
        wx.navigateTo({
      url: '../../supplygoods/public_page/returnpage/returnpage?light1='+ this.data.light1+'&light2='+this.data.light2+'&light3='+this.data.light3+'&myclerd='+ this.data.myclerd
    });
    },

    /*我的名片跳转*/
    myCard:function (event) {
        wx.navigateTo({
            url: '/pages/user_center/me_detial/me_detial',
        });
    },

    /*用户个人中心跳转*/
    userCenter:function () {
        wx.navigateTo({
            url: '/pages/user_center/user_center/user_center',
        });
    },

    /*用户设置详情跳转*/
    userDetial:function () {
        wx.navigateTo({
            url: '/pages/user_center/user_detial/user_detial',
        });
},
    onJump:function () {
        if (!this.pageLoading) {
            this.pageLoading = !0;
            wx.navigateTo({
                url: '../../order/orderlist/orderlist',
            });
        }
    },
    onCap:function () {
        if (!this.pageLoading) {
            this.pageLoading = !0;
            if(app.data.appName=="顺利运"||app.data.appName=="昆仑云通"){
                wx.navigateTo({
                    url: '../../order/capital/capital?src=' + app.data.allDomainNameUrl+'appApi/huaXiaBank/account',
                });
            }else if(app.data.appName=="西南大运"){
                wx.navigateTo({
                    url: '../../order/capital/capital?src=' + app.data.allDomainNameUrl+'appApi/company/reapalAccount/appPage/',
                });
            }

        }
    },
    
    onJump1:function () {
        if (!this.pageLoading) {
            this.pageLoading = !0;
            app.orderdata["orderID"]=null
            app.orderdata["dispatchStatusCode"]="";
            wx.navigateTo({
                url: '../../dispatchlist/list/list',
            });
        }
    },
    onShow:function () {

        this.pageLoading = !1
        var options = {
            port: 'myStatistics',
            body: {
                "orderType": 2,
            }
        }
        app.connect(options).then(values => {
            console.log(values)
            if(values.data.body.content.unexecutedDispatchCount==null){
                values.data.body.content.unexecutedDispatchCount=0
            }else if(values.data.body.content.loadedDiaptchCount==null){
                values.data.body.content.loadedDiaptchCount=0
            }
            var size=Number(values.data.body.content.unexecutedDispatchCount)+Number(values.data.body.content.loadedDiaptchCount)
            this.setData({
                size:size
            })

        })
    },
    sweepCode:function(){
        var that=this;
        wx.scanCode({
            success: (res) => {
                console.log(res)
                /*res.result this.data.params*/
                if(res.result.indexOf("route/batch?type=app")!="-1"){
                    app.orderdata["dispatchStatusCode"]="1141010";
                    wx.navigateTo({
                        url: '../../dispatchlist/list/list',
                    })
                }else{
                    wx.navigateTo({
                        url: '../../order/test/test?src='+res.result,
                    })
                }
            }
        })
    },

});
