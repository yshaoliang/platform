//委托人接口
var util = require('../login/md5.js');

const app = getApp();

Page({
    data: {
        imgRd:app.globalData[0],
        imgRd1:app.globalData[1],
    },
    onLoad:function (event) {
        console.log(event);

        var options = {
            port: 'companyDtlQry',
            body: {"companyID":event.companyID,"companyName":event.companyName}
        };
        app.connect(options).then(values => {
            console.log(values);
            this.setData({
               company:values.data.body.content.companyInfo,
            });
        });


    }

})
