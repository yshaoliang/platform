var app=getApp()
Page({
    data:{
        totalPrice:null,
        amountInfo:null,
        price:null,
        desc:null,
        quotationID:"",
        shipment:""
    },

    onLoad:function () {
        var that=this;
        var price=0;
        var options = {
            port: 'goodsQuotationDtlQry2',
            body: {"quotationID": app.orderdata["quotationID"]}
        };
        app.connect(options).then(values => {
            console.log(values)
            if(values.data.body.content.quotationInfo.amountInfo.weight!="0"){
                that.data.shipment=values.data.body.content.quotationInfo.amountInfo.weight
                price=Number(values.data.body.content.quotationInfo.totalPrice) /Number(values.data.body.content.quotationInfo.amountInfo.weight)
                console.log(price)
            }else if(values.data.body.content.quotationInfo.amountInfo.volume!="0"){
                that.data.shipment=values.data.body.content.quotationInfo.amountInfo.volume
                price=Number(values.data.body.content.quotationInfo.totalPrice)/Number(values.data.body.content.quotationInfo.amountInfo.volume)
                console.log(price)
            }
                this.data.totalPrice=values.data.body.content.quotationInfo.totalPrice
                this.data.amountInfo=values.data.body.content.quotationInfo.amountInfo
                this.data.price=price
                this.data.desc=values.data.body.content.quotationInfo.desc
            this.data.quotationID=values.data.body.content.quotationInfo.quotationID
            that.setData({
                totalPrice:values.data.body.content.quotationInfo.totalPrice,
                price:price,
                shuju:values.data.body.content
            })

        })
    },

    onModify:function () {
        var that=this;
        var options = {
            port: 'goodsQuotationCreUpd3',
            body: {
                "goodsID":app.orderdata["goodsID"],
                "quotationID": this.data.quotationID,
                "priceType":app.orderdata["quotationmethod_type"],
                "totalPrice":this.data.totalPrice,
                "amountInfo":this.data.amountInfo,
                "price":this.data.price,
                "desc":this.data.desc,
            }
        };
        app.connect(options).then(values => {
            console.log(values)
            if(values.data.body.content!=null){
                wx.showToast({
                    title: "修改成功",
                    mask: false,
                    icon: "success",
                    duration: 2000,
                    success: function () {
                        wx.navigateBack({
                            delta: -1
                        });
                    },
                })
            }else{
                wx.showModal({
                    title: '提示',
                    content: values.data.body.desc,
                    showCancel: false
                })
            }
        })
    },
    onType:function () {
        this.onLoad()
        if(app.orderdata["priceType"]==null){
            wx.navigateTo({
                url: '../quotationmethod/quotationmethod'
            });
        }
    },
    onShow:function () {
        this.setData({
            "quotationmethod_name":app.orderdata["quotationmethod_name"]
        })
    },
    totalpriceInput:function (e) {
        var that=this;
        console.log(e.detail.value)
        if(e.detail.value!=""){
            that.setData({
                price:parseInt(e.detail.value)/parseInt(that.data.shipment)
            })
            that.data.totalPrice=e.detail.value

        }
    },
    quasishipmentInput:function (e) {
        var that=this;
        if(e.detail.value!=""){
            if(app.orderdata["quotationmethod_name"]=="按整单"){
                that.setData({
                    price:parseInt(that.data.totalPrice)/parseInt(e.detail.value)
                })
            }else{
                that.setData({
                    totalPrice:parseInt(that.data.price)*parseInt(e.detail.value)
                })
            }
            if(that.data.amountInfo.volume!="0"){
                that.data.shipment=e.detail.value
                that.data.amountInfo.volume=e.detail.value
            }else{
                that.data.shipment=e.detail.value
                that.data.amountInfo.weight=e.detail.value
            }
        }
    },
    priceInput:function (e) {
        var that=this;
        if(e.detail.value!=""){
            that.setData({
                totalPrice:parseInt(that.data.shipment)*parseInt(e.detail.value)
            })
            that.data.price=e.detail.value
        }
    },
    descInput:function (e) {
        if(e.detail.value!=""){
            this.data.desc=e.detail.value
        }
    }

})