//订单详情页面
var util = require('../../login/md5.js');
var template = require('../../public_util/publishData.js');
var app = getApp();
Page({
    data: {
        imgRd:app.globalData[1],
        imgRd6:app.globalData[6],
        imgRd16:app.globalData[16],
        imgRd17:app.globalData[17],
        imgRd18:app.globalData[18],
        imgRd25:app.globalData[25],
        imgRd52:app.globalData[52],
        /*角色显示页面*/
        shfTt:'',
        shfFt:'',
        entrustedquantity:0,
        entrustednumbers:0,
        arrCargoInfo:""
    },

    onLoad: function (e) {
        console.log(e)
        /*根据不同的用户角色，显示不同的页面*/
        console.log(app.globalData.shfFt)
        this.setData({
            company:app.orderdata["company"],
            company1:app.orderdata["company1"],
            forward:app.globalData[48],
            numbers:e.numbers,
            quality:e.quality,
            shfTt:app.globalData.shfTt,
            shfFt:app.globalData.shfFt
        });

        var options = {
            port: 'goodsDtlQry5',
            body: {"goodsID": app.globalData.goodsuuid}
        };
        var that=this;
        app.connect(options).then(values => {
            console.log(values)
            app.orderdata["goodsID"]=values.data.body.content.goodsID
            app.orderdata["priceType"]=values.data.body.content.priceType
            app.orderdata["goodsStatusDesc"]=values.data.body.content.goodsStatusDesc
            if(values.data.body.content.arrQuotationInfo3!=null){
                if(values.data.body.content.arrQuotationInfo3.length!=0){
                    for(var i=0;i<values.data.body.content.arrQuotationInfo3.length;i++){
                        if(values.data.body.content.arrQuotationInfo3[i].userInfo.companyInfo.companyID==app.globalData.userDe.userInfo.companyInfo.companyID){
                            that.setData({
                                isOwn:true
                            })
                        }else{
                            that.setData({
                                isOwn:false
                            })
                        }
                    }
                }else{
                    that.setData({
                        isOwn:false
                    })
                }
            }else{
                that.setData({
                    isOwn:false
                })
            }
            //去除地址的逗号
            for(var i=0;i<1;i++){
                values.data.body.content.consignorInfo.addressInfo.cityShortName = app.oncityNam(values.data.body.content.consignorInfo.addressInfo.cityShortName);
                values.data.body.content.consigneeInfo.addressInfo.cityShortName = app.oncityNam(values.data.body.content.consigneeInfo.addressInfo.cityShortName)
            }
            this.setData({
                companyID:values.data.body.content.trustorInfo.companyInfo.companyID,
                companyName:values.data.body.content.trustorInfo.companyInfo.companyName,
                val: values.data.body.content,
            });
            //物流商
            if (values.data.body.content.arrQuotationInfo3 != null){
                this.data.entrustedquantity=0
                this.data.entrustednumbers=0
                console.log(values.data.body.content.arrCargoInfo)
                this.data.arrCargoInfo=values.data.body.content.arrCargoInfo
                for(var i=0;i<values.data.body.content.arrCargoInfo.length;i++){
                    for(var j=0;j<values.data.body.content.arrCargoInfo[i].arrAmountInfo.length;j++) {
                        if (values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].amountBizType==2) {
                        if (values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].volume != 0) {
                            this.data.entrustedquantity = Number(this.data.entrustedquantity) + Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].volume)
                        } else {
                            this.data.entrustedquantity = Number(this.data.entrustedquantity) + Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].weight)
                        }
                        this.data.entrustednumbers = Number(this.data.entrustednumbers) + Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].quantity)
                    }
                    }

                }
                /*this.data.arrCargoInfo*/
                this.setData({
                    entrustedquantity:this.data.entrustedquantity,
                    entrustednumbers:this.data.entrustednumbers,
                    valQuotation:values.data.body.content.arrQuotationInfo3["0"],
                })
            }
            //委托人
            if (values.data.body.content.arrQuotationInfo3 == null){
                this.data.arrCargoInfo=values.data.body.content.arrCargoInfo
                this.setData({
                    valQuotation:values.data.body.content.arrQuotationInfo3,
                })
            }
            console.log(this.data.valQuotation)
            //这是物流商进来，点开详情可以看见orderid
            if (2541020 == app.globalData.companyType){
                this.setData({
                    orderID:values.data.body.content.arrQuotationInfo3["0"].orderID
                });
                app.orderID = values.data.body.content.arrQuotationInfo3["0"].orderID
            }else{

            }
        })

    },

    calling: function () {
        wx.makePhoneCall({
            phoneNumber: this.data.val.trustorInfo.mobile,
            success: function () {
                console.log("拨打电话成功！")
            },
            fail: function () {
                console.log("拨打电话失败！")
            }
        })
    },
    onShow:function(){
        this.pageLoading = !1;
        /*根据不同的用户角色，显示不同的页面*/
        /*app.orderdata["issupply"]=false*/
        console.log(app.globalData.shfFt)
        this.setData({
            shfTt:app.globalData.shfTt,
            shfFt:app.globalData.shfFt
        });

        var options = {
            port: 'goodsDtlQry5',
            body: {"goodsID": app.globalData.goodsuuid}
        };
        var that=this;
        app.connect(options).then(values => {
            console.log(values)
            app.orderdata["goodsID"]=values.data.body.content.goodsID
            app.orderdata["priceType"]=values.data.body.content.priceType
            app.orderdata["goodsStatusDesc"]=values.data.body.content.goodsStatusDesc
            if(values.data.body.content.arrQuotationInfo3!=null){
                if(values.data.body.content.arrQuotationInfo3.length!=0){
                    for(var i=0;i<values.data.body.content.arrQuotationInfo3.length;i++){
                        if(values.data.body.content.arrQuotationInfo3[i].userInfo.companyInfo.companyID==app.globalData.userDe.userInfo.companyInfo.companyID){
                            that.setData({
                                isOwn:true
                            })
                        }else{
                            that.setData({
                                isOwn:false
                            })
                        }
                    }
                }else{
                    that.setData({
                        isOwn:false
                    })
                }
            }else{
                that.setData({
                    isOwn:false
                })
            }
            //去除地址的逗号
            for(var i=0;i<1;i++){
                values.data.body.content.consignorInfo.addressInfo.cityShortName = app.oncityNam(values.data.body.content.consignorInfo.addressInfo.cityShortName);
                values.data.body.content.consigneeInfo.addressInfo.cityShortName = app.oncityNam(values.data.body.content.consigneeInfo.addressInfo.cityShortName)
            }
            this.setData({
                companyID:values.data.body.content.trustorInfo.companyInfo.companyID,
                companyName:values.data.body.content.trustorInfo.companyInfo.companyName,
                val: values.data.body.content,
            });
            //物流商
            if (values.data.body.content.arrQuotationInfo3 != null){
                this.data.entrustedquantity=0
                this.data.entrustednumbers=0
                console.log(values.data.body.content.arrCargoInfo)
                for(var i=0;i<values.data.body.content.arrCargoInfo.length;i++){
                    for(var j=0;j<values.data.body.content.arrCargoInfo[i].arrAmountInfo.length;j++) {
                        if (values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].amountBizType==2) {
                            if (values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].volume != 0) {
                                this.data.entrustedquantity = Number(this.data.entrustedquantity) + Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].volume)
                            } else {
                                this.data.entrustedquantity = Number(this.data.entrustedquantity) + Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].weight)
                            }
                            this.data.entrustednumbers = Number(this.data.entrustednumbers) + Number(values.data.body.content.arrCargoInfo[i].arrAmountInfo[j].quantity)
                        }
                    }

                }
                this.setData({
                    entrustedquantity:this.data.entrustedquantity,
                    entrustednumbers:this.data.entrustednumbers,
                    valQuotation:values.data.body.content.arrQuotationInfo3["0"],
                })
            }
            //委托人
            if (values.data.body.content.arrQuotationInfo3 == null){
                this.setData({
                    valQuotation:values.data.body.content.arrQuotationInfo3,
                })
            }
            console.log(this.data.valQuotation)
            //这是物流商进来，点开详情可以看见orderid
            if (2541020 == app.globalData.companyType){
                this.setData({
                    orderID:values.data.body.content.arrQuotationInfo3["0"].orderID
                });
                app.orderID = values.data.body.content.arrQuotationInfo3["0"].orderID
            }else{

            }
        })
    },

    /*货源报价*/
    supplyofgoodmoney:function () {
        wx.navigateTo({
            url:'../../supplygoods/supplyofgoods_money/supplyofgoods_money'
        });
    },

    //跳转委托人
    jumpPerson:function () {
        wx.navigateTo({
            url: '../../person_info/person_info?companyID='+this.data.companyID+'&companyName='+this.data.companyName,
        });
    },

    /*我要承运，承运商的报价列表*/
    submitQuote:function (event) {
        console.log(this.data.val)
        app.orderdata["arrCargoInfo2"]=this.data.val
        wx.navigateTo({
            url: '../../supplygoods/supplyofgoods_quote/supplyofgoods_quote?priceMode='+this.data.val.priceMode
                //总价
            +'&consignorTotalPrice='+this.data.val.consignorTotalPrice
                //单价
            +'&consignorPrice='+this.data.val.consignorPrice
                //拟承运(体积)
            +'&volume='+this.data.val.arrCargoInfo["0"].arrAmountInfo["0"].volume
                //判断是整单、还是按单价
            +'&priceType='+ this.data.val.priceType
                //拟承运(重量)
            +'&weight='+this.data.val.arrCargoInfo["0"].arrAmountInfo["0"].weight
                //体积单位
            +'&volumeUnit='+this.data.val.arrCargoInfo["0"].arrAmountInfo["0"].volumeUnit
                //重量单位
            +'&weightUnit='+this.data.val.arrCargoInfo["0"].arrAmountInfo["0"].weightUnit
                //件数单位
            +'&quantityUnit='+this.data.val.arrCargoInfo["0"].arrAmountInfo["0"].quantityUnit
                //件数个数
            +'&quantity='+this.data.val.arrCargoInfo["0"].arrAmountInfo["0"].quantity
                //件数的id
            +'&quantityUnitID='+this.data.val.arrCargoInfo["0"].arrAmountInfo["0"].quantityUnitID
                //体积的id
            +'&volumeUnitID='+this.data.val.arrCargoInfo["0"].arrAmountInfo["0"].volumeUnitID
                //重量的id
            +'&weightUnitID='+this.data.val.arrCargoInfo["0"].arrAmountInfo["0"].weightUnitID
        })
    },

    /**/
    nvOrderDtl:function () {
      //查看订单
        var that = this;
        if (!that.pageLoading) {
            that.pageLoading = !0;
            app.orderID = this.data.valQuotation.orderID
            wx.redirectTo({
                url: '../../order/orderDtlQry/orderDtlQry'
            });
        }
    },

    onDetails:function () {
        app.orderID=this.data.valQuotation.orderID
        console.log(123)
        wx.navigateTo({
            url: '../transactiondetails/transactiondetails?quotationID='+this.data.valQuotation.quotationID,
        });
    },
    onCargodetails:function() {
        console.log(this.data.arrCargoInfo)
        app.orderdata["arrCargoInfo"]=this.data.arrCargoInfo
        wx.navigateTo({
            url: '../supplycargodetails/supplycargodetails'
        })
    }

});

