var template = require('../../public_util/publishData.js');
var util = require('../../login/md5.js');
//获取全局对象
const app = getApp();
Page({
    data: {
        imgRd: app.globalData[0],
        imgRd24: app.globalData[24],
        imgRd14: app.globalData[14],
        imgRd25: app.globalData[25],
        imgRd54: app.globalData[54],
        select: false,
        left_supplyofgoods: '货源状态',
        right_supplyofgoods: '货源类型',
        size: '',
        /*列表条件*/
        name: '',
        othername: '',
        left_id: null,
        companyType:'' ,
        bindData:'',
        alldata:[[],[]],
        index:0,
        right_id:null,
        right_id1:null,
        left_id1: null,
        body: {
            "pageIndex":0,
            "pageSize": 10,
            "isMyGoods": true,
        },
        isRefresh:"",
        isImplement:"",
        company:"",
        company1:""

    },

    onLoad: function () {
        this.data.alldata.splice(0, this.data.alldata.length);
        console.log(app.globalData.userDe.userInfo.companyInfo.companyID)
        this.data.index=0
        this.setData({
            bindData: template.tabbars,
            thisSel:0,
        });
        console.log(app.globalData.companyType)
        this.setData({
            companyType : app.globalData.companyType
        });

        var options = {
            port: 'goodsListQry5',
            body: this.data.body
        }
        app.connect(options).then(values => {
            console.log(values);
            this.setData({
                companyID:app.globalData.userDe.userInfo.companyInfo.companyID
        })
            /*if(values.data.body.content.arrGoodsAbstractInfo.length == 0){
                wx.showToast({
                    title: "暂无货源",
                    mask: false,
                    icon: "none",
                    duration: 2000,
                })
                return false;
            }*/

            //去除地址的逗号
            for(var i=0;i<values.data.body.content.arrGoodsAbstractInfo.length;i++){
                values.data.body.content.arrGoodsAbstractInfo[i].consignorInfo.addressInfo.cityShortName=app.oncityNam(values.data.body.content.arrGoodsAbstractInfo[i].consignorInfo.addressInfo.cityShortName)
                values.data.body.content.arrGoodsAbstractInfo[i].consigneeInfo.addressInfo.cityShortName=app.oncityNam(values.data.body.content.arrGoodsAbstractInfo[i].consigneeInfo.addressInfo.cityShortName)
            }
            /*this.data.alldata.push(values.data.body.content.arrGoodsAbstractInfo);*/
            this.data.alldata[0]=values.data.body.content.arrGoodsAbstractInfo;
            console.log(this.data.alldata)
            var that=this;
            that.data.alldata.push([])
            for(var i=0;i<that.data.alldata[0].length;i++){
                that.data.quality=0
                that.data.numbers=0
                that.data.company=""
                that.data.company1=""
                for(var j=0;j<that.data.alldata[0][i].arrCargoInfo.length;j++){
                    for(var h=0;h<that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo.length;h++){
                        if(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].amountBizType==1){
                            if(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volume!=0){
                                console.log(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volume)
                                if(that.data.company==""){
                                    that.data.company=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volumeUnit
                                }else{
                                    if(that.data.company!=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volumeUnit){
                                        that.data.company="单位"
                                    }
                                }
                                that.data.quality=Number(that.data.quality)+Number(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volume)
                            }
                            if(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weight!=0){
                                console.log(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weight)
                                if(that.data.company==""){
                                    that.data.company=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weightUnit
                                }else{
                                    if(that.data.company!=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weightUnit){
                                        that.data.company="单位"
                                    }
                                }
                                that.data.quality=Number(that.data.quality)+Number(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weight)
                            }
                           /* if(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].quantity!=0){*/
                                if(that.data.company1==""){
                                    that.data.company1=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].quantityUnit
                                }else{
                                    if(that.data.company1!=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].quantityUnit){
                                        that.data.company1="单位"
                                    }
                                }
                                that.data.numbers=Number(that.data.numbers)+Number(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].quantity)
                          /*  }*/
                        }
                    }

                }
                that.data.alldata[1].push([
                    {
                        company:that.data.company,
                        company1:that.data.company1,
                        quality:that.data.quality,
                        numbers: that.data.numbers
                    }
                ])

            }
            console.log(that.data.alldata)
            this.setData({
                shuju:this.data.alldata,
            });
        });
    },

    onShow:function () {
        if(app.orderdata["jumppath"]==true){
            app.orderdata["orderID"] = null
            wx.navigateTo({
                url: '../../dispatchlist/list/list',
                success:function () {
                    app.orderdata["jumppath"]=false
                }
            });
       }
        app.orderdata["issupply"]=false
        this.pageLoading = !1;
        console.log(app.orderdata["isRefresh"])
        console.log(this.data.isRefresh)
        if(this.data.isRefresh!=true||app.orderdata["isRefresh"]!=true){
       console.log(this.data.left_supplyofgoods)
if(this.data.left_supplyofgoods=="货源状态"&&this.data.right_supplyofgoods=="货源类型"||this.data.right_id!=null||this.data.left_id!=null) {
    var that = this;
    that.data.index = 0
    //货源类型刷选this.onLoad()
    if (this.data.left_id == 1) {
        this.setData({
            left_id: null
        })
    }
    if (this.data.right_id == 1) {
        this.setData({
            right_id: null
        })
    }

    this.setData({
        body: {
            "pageIndex": this.data.index,
            "pageSize": 10,
            "isMyGoods": true,
            "goodsCondition": this.data.right_id,
            "goodsStatus": this.data.left_id,
        }
    });

    var options = {
        port: 'goodsListQry5',
        body: this.data.body
    }
    app.connect(options).then(values => {
        console.log(values);
        if (values.data.body.content.arrGoodsAbstractInfo.length == 0) {
            wx.showToast({
                title: "暂无货源",
                mask: false,
                icon: "none",
                duration: 2000,
            })
            return false;
        }
        //去除地址的逗号
        for (var i = 0; i < values.data.body.content.arrGoodsAbstractInfo.length; i++) {
            values.data.body.content.arrGoodsAbstractInfo[i].consignorInfo.addressInfo.cityShortName = app.oncityNam(values.data.body.content.arrGoodsAbstractInfo[i].consignorInfo.addressInfo.cityShortName)
            values.data.body.content.arrGoodsAbstractInfo[i].consigneeInfo.addressInfo.cityShortName = app.oncityNam(values.data.body.content.arrGoodsAbstractInfo[i].consigneeInfo.addressInfo.cityShortName)
        }
        if (that.data.right_id != null || that.data.left_id != null) {
            that.data.alldata[0].splice(0, that.data.alldata[0].length);
        }
        console.log(values.data.body.content.arrGoodsAbstractInfo)
        that.data.alldata[0] = values.data.body.content.arrGoodsAbstractInfo;
        console.log(that.data.alldata[0])
        that.data.right_id1 = that.data.right_id
        that.data.left_id1 = that.data.left_id
        that.data.right_id = null
        that.data.left_id = null
        console.log(that.data.alldata)
        that.setData({
            shuju: that.data.alldata,
        });
    });
    that.pageLoading = !1;
}
}else{
this.data.isRefresh=false
        }
    },

    /*左边下拉框选项框*/
    supplyofgoodspage: function (e) {
        console.log(e);
        wx.navigateTo({
            url: '../../supplygoods/public_page/supplyofgoodspage/supplyofgoodspage?supplyId=' + e.currentTarget.dataset.supplyId,
        });
    },

    /*右边下拉框选项框*/
    supplyofgoodsright: function (e) {
        console.log(e);
        wx.navigateTo({
            url: '../../supplygoods/public_page/supplyofgoodsright/supplyofgoodsright?supplyId=' + e.currentTarget.dataset.supplyId,
        });
    },

    /*列表循环单击选择事件*/
    tapName: function (event) {

        var that=this;
       /* if (!that.pageLoading) {
            that.pageLoading = !0;*/
            app.orderdata["isRefresh"] = true
            that.data.isRefresh = true
            that.data.right_id != null
            that.data.left_id != null
            var s = event.currentTarget.dataset.id.split(",")
            app.globalData.goodsuuid = s[0];
            app.orderdata["company"] = s[1]
            app.orderdata["company1"] = s[2]

            wx.navigateTo({
                url: '../supplyofgoods_details/supplyofgoods_details?goodsID=' + s[0] + "&quality=" + that.data.alldata[1][event.currentTarget.dataset.name][0].quality + "&numbers=" + that.data.alldata[1][event.currentTarget.dataset.name][0].numbers
            });
      /*  }*/
    },


    //下拉刷新
    onPullDownRefresh:function()
    {
        this.data.alldata.splice(0, this.data.alldata.length);
        wx.showNavigationBarLoading() //在标题栏中显示加载
        //模拟加载
        this.onLoad();
        setTimeout(function()
        {
            wx.hideNavigationBarLoading() //完成停止加载
            wx.stopPullDownRefresh() //停止下拉刷新
        },1500);
    },

    //上拉加载
    onReachBottom: function() {
        var that = this;
        that.data.alldata[1].splice(0, that.data.alldata[1].length);
        that.data.index=that.data.index+1
        var options = {
            port: 'goodsListQry5',
            body: {
                "pageIndex": that.data.index,
                "pageSize": 10,
                "isMyGoods": true,
                "goodsCondition":that.data.right_id1,
                "goodsStatus":that.data.left_id1,
            }
        }
        app.connect(options).then(values => {
            //去除地址的逗号
            console.log(values)
            for(var i=0;i<values.data.body.content.arrGoodsAbstractInfo.length;i++){
                values.data.body.content.arrGoodsAbstractInfo[i].consignorInfo.addressInfo.cityShortName=app.oncityNam(values.data.body.content.arrGoodsAbstractInfo[i].consignorInfo.addressInfo.cityShortName)
                values.data.body.content.arrGoodsAbstractInfo[i].consigneeInfo.addressInfo.cityShortName=app.oncityNam(values.data.body.content.arrGoodsAbstractInfo[i].consigneeInfo.addressInfo.cityShortName)
            }
            for (var i = 0; i < values.data.body.content.arrGoodsAbstractInfo.length; i++) {
                that.data.alldata[0].push(values.data.body.content.arrGoodsAbstractInfo[i])
            }
            for(var i=0;i<that.data.alldata[0].length;i++){
                that.data.quality=0
                that.data.numbers=0
                that.data.company=""
                that.data.company1=""
                for(var j=0;j<that.data.alldata[0][i].arrCargoInfo.length;j++){
                    for(var h=0;h<that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo.length;h++){
                        if(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].amountBizType==1){
                            if(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volume!=0){
                                console.log(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volume)
                                if(that.data.company==""){
                                    that.data.company=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volumeUnit
                                }else{
                                    if(that.data.company!=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volumeUnit){
                                        that.data.company="单位"
                                    }
                                }
                                that.data.quality=Number(that.data.quality)+Number(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].volume)
                            }
                            if(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weight!=0){
                                console.log(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weight)
                                if(that.data.company==""){
                                    that.data.company=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weightUnit
                                }else{
                                    if(that.data.company!=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weightUnit){
                                        that.data.company="单位"
                                    }
                                }
                                that.data.quality=Number(that.data.quality)+Number(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].weight)
                            }
                            /*if(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].quantity!=0){*/
                                if(that.data.company1==""){
                                    that.data.company1=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].quantityUnit
                                }else{
                                    if(that.data.company1!=that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].quantityUnit){
                                        that.data.company1="单位"
                                    }
                                }
                                that.data.numbers=Number(that.data.numbers)+Number(that.data.alldata[0][i].arrCargoInfo[j].arrAmountInfo[h].quantity)
                           /* }*/
                        }
                    }

                }
                that.data.alldata[1].push([
                    {
                        company:that.data.company,
                        company1:that.data.company1,
                        quality:that.data.quality,
                        numbers: that.data.numbers
                    }
                ])

            }
            console.log(that.data.alldata)
            that.setData({
                shuju: that.data.alldata
            })
        })
    },


})