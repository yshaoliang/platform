/**
 * @author chenyang_yuan
 * @version 1.0
 * Created by chenyang_yuan on 2018/10/14.
 * content：发布货源
 */
var app = getApp();
var template = require('../../tabbar/tabbar.js');
var publish = require('../../public_util/publishData');
var show = false;
var strlong = '';
var numlong = '';
Page({
    data: {
        imgRd:app.globalData[1],
        multiArray: [publish.years,publish.mouths,publish.days,publish.houvers],
        multiIndex: [1, 0, 0,0],
        region: ['广东省', '广州市', '海珠区'],
        regiontwo:['安徽省','合肥市','肥东县'],
        multiTranArray: [publish.drives,publish.dlongs,publish.dwidts],
        multiTranIndex: [1, 0, 0],
        hight: "重货",
        dataid: '1131000',
        weightvolume: "重量",
        list: [1],
        pubif:true,
        payawyid:1021000,
        paywayName:'付款方式',
        transel:false,
        addid:0,
        invoiceid:1031000,
        invoicename:'发票要求',
        pricing:false,
        elementname:'按整单',
        elementid:1181000,
        priceMode:1171010,
        publicGoods:0,
        total:'总价',
        issue:true,
        arrpubly:[],
        arrpublylength:'',
        /*这是重量体积的单位选择*/
        company:publish.weightVolumeUnits,
        /*单位显示模板*/
        weigW:false,
        /*隐藏件数选框*/
        numberTf:false,
        /*件数单位选择*/
        jsNum:publish.numbers,

    },

    onLoad: function (options) {
    },

    //生命周期函数--监听页面初次渲染完成
    onReady: function (e) {

    },

    /*发货省市县的选择*/
    bindRegionChange: function (e) {
        console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
            region: e.detail.value
        })
    },

    /*收货省市县*/
    bindRegionChangetwo: function (e) {
        console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
            regiontwo: e.detail.value
        })
    },

    /*自己组装的时间选择*/
    bindMultiPickerColumnChange: function (e) {
        console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
        var data = {
            multiArray: this.data.multiArray,
            multiIndex: this.data.multiIndex
        };
        data.multiIndex[e.detail.column] = e.detail.value;
        this.setData(data);

    },


    /*载具要求的增加*/
    bindTranMultiPickerChange: function (e) {
        console.log(e)
        console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
        var data = {
            multiTranArray: this.data.multiTranArray,
            multiTranIndex: this.data.multiTranIndex
        };
        data.multiTranIndex[e.detail.column] = e.detail.value;
        this.setData(data);
    },


    /*选择计价方式*/
    goods: function (e) {
        wx.navigateTo({
            url: '../../supplygoods/public_page/goods_page/goods_page?dataid=' + e.currentTarget.dataset.id,
        })
    },

    /*重量体积选择*/
    wevol: function (event) {
        strlong = "";
        var that = this;
        console.log(this.data.weigW);
        if (this.data.weigW){
            that.setData({
               weigW:false,
           })
       }else{
            that.setData({
               weigW:true,
               numberTf:false
           })
       }
    },

    /*选择单位事件*/
    touchWeight:function (event) {
        if (event.target.dataset.id.length < 2){
            strlong = strlong + event.target.dataset.id;
            console.log(strlong);
            this.setData({
                strlong:strlong
            })
        }
        for(var s in publish.weightVolumeUnits){
            console.log(event.target.dataset.id)
            if(event.target.dataset.id ==publish.weightVolumeUnits[s].codeId){
                console.log(publish.numbers[s].codeName)
                this.setData({
                    striid:publish.weightVolumeUnits[s].codeId,
                    strName: publish.weightVolumeUnits[s].codeName,
                    weigW: false
                });
            };
        }
    },


    /*件数触发事件*/
    jsTouch:function (event) {
        numlong = "";
        var that = this;
        console.log(this.data.weigW);
        if (this.data.numberTf){
            that.setData({
                numberTf:false,
            });
        }else{
            that.setData({
                numberTf:true,
                weigW:false
            });
        }
    },


    /*选择件数触发事件*/
    numberTouch:function (event) {
        console.log(event);
        if (event.target.dataset.id.length < 2){
            numlong = numlong + event.target.dataset.id;
            this.setData({
                numlong:numlong
            });
        }
        //传过来的codeId找到codeName
        for(var s in publish.numbers){
            if(event.target.dataset.id == publish.numbers[s].codeId){
                    this.setData({
                        numid:publish.numbers[s].codeId,
                        numName:publish.numbers[s].codeName,
                        numberTf:false
                    });
            };
        }
    },



    /*载具要求vehicle对view进行追加*/
    addvehicle: function (e) {
        var content = this.data.list.concat(1);//向list不断增加1，仅为参考
        1 < e.currentTarget.dataset.id ?
        this.setData({
            list: content,
        })
        :
        this.setData({
            transel:true,
            addid:2
        })
    },

    /*增加后的文本框动态添加工具*/
    inputcode: function (e) {

    },


    /*其他选项点开关闭触发事件*/
    openandclose:function (e) {
       this.pubif = !this.pubif;
    this.setData({
        pubif: this.pubif,
        })
    },

    /*付款方式触发事件*/
    payway: function (e) {
        wx.navigateTo({
            url: '../../supplygoods/public_page/pay_awy/pay_awy?payawyid=' + e.currentTarget.dataset.id,
        })
    },

    /*发票要求跳转触发事件*/
    invoice:function (e) {
        wx.navigateTo({
            url: '../../supplygoods/public_page/invoice/invoice?invoiceid=' + e.currentTarget.dataset.id,
        })
    },

    /*货主定价触发事件*/
    pricingTouch:function (e) {
        var  that =this;
        this.pricing = !this.pricing;
        that.setData({
            pricing: this.pricing,
        })
    },

    /*公开货源switch*/
    switchChange:function (event) {
        var that = this;
        that.setData({
            /*是否公开货源*/
            issue: !event.detail.value,
            publicGoods :  event.detail.value ? 0 : 1,
        });
    },

    /*报价方式的触发事件*/
    element:function (e) {
        wx.navigateTo({
            url: '../../supplygoods/public_page/element/element?elementid=' + e.currentTarget.dataset.id,
        });
    },


    /*发布范围触发选择*/
    releaseRange:function (event){
        wx.navigateTo({
            url: '../../supplygoods/public_page/logistics_provider/logisticsprovider?arrpubly=' + this.data.arrpubly +'&arrpublylength='+this.data.arrpublylength,
        })
    },

    /*货主触发选择事件*/
    providerSwc:function (event) {
      this.setData({
          priceMode :  event.detail.value ? 1171000 : 1171010,

      })
    },



    /*发布货源数据提交保存*/
    formSubmit: function (e) {
        console.log(e);
        console.log(e.detail.value);
        var shang = "";
        var cheng = "";
        /*选择触发计算价格*/
        if("1181000" == this.data.elementid){
            var sum =  e.detail.value.zj;
            var js = e.detail.value.js;
            shang = sum/js+"";

        }
        if ("1181010" == this.data.elementid){
            var js = e.detail.value.js
            var zj = e.detail.value.zj
            cheng  = js*zj+"";

        };
        /*这是判断是选择什么单位*/
        "1131010" != e.detail.value.valuationMode?
          this.setData({
              volumes:null,
              volumeUnits:null,
              volumeUnitIDs:null,
              weights:e.detail.value.vstrlong,
              weightUnits:e.detail.value.vstrName,
              weightUnitIDs:e.detail.value.vstriid,
          })
          :
          this.setData({
               volumes:e.detail.value.vstrlong,
               volumeUnits:e.detail.value.vstrName,
               volumeUnitIDs:e.detail.value.vstriid,
               weights:null,
               weightUnits:null,
               weightUnitIDs:null,
           });


        //定义一个数组对象
        var param = {
            arrCargoInfo :[{
                arrAmountInfo:[{
                    amountBizType:"1",
                    quantity : e.detail.value.numlong,
                    quantityUnit :e.detail.value.unitName,
                    quantityUnitID : e.detail.value.numid,
                    volume : this.data.volumes,
                    volumeUnit : this.data.volumeUnits,
                    volumeUnitID : this.data.volumeUnitIDs,
                    weight :this.data.weights ,
                    weightUnit :this.data.weightUnits,
                    weightUnitID : this.data.weightUnitIDs,
                }],
                cargoID:null,
                valuationMode : e.detail.value.valuationMode,
                cargoName : e.detail.value.hwmc}],

            consigneeInfo:{
                addressInfo:{
                    cityCode:"230881",
                    cityName:"\U5409\U6797\U7701,\U677e\U539f\U5e02,\U957f\U5cad\U53bf",
                    cityShortName:"\U5409\U6797\U7701,\U677e\U539f\U5e02,\U957f\U5cad\U53bf"
                },
                userID:null,
                linkmanID:null,
                mobile:null,
                name:null
            },

            /*不是公开货源有公司codeID*/
            arrVehicleNeedsInfo :    [],
            consignorInfo :
                {
                    addressInfo :{
                        cityCode:"230881",
                        cityName:"\U5409\U6797\U7701,\U677e\U539f\U5e02,\U957f\U5cad\U53bf",
                        cityShortName:"\U5409\U6797\U7701,\U677e\U539f\U5e02,\U957f\U5cad\U53bf"
                    },
                    userID:null,
                    linkmanID:null,
                    mobile:null,
                    name:null
                },
            goodsID:null,
            /*货主定价单价*/
            consignorPrice:shang,
            /*货主定价总价*/
            consignorTotalPrice:cheng,
            deliveryDate : "2018-10-24 12:45:25",
            desc:e.detail.value.desc,
            invoiceRequest: e.detail.value.invoiceRequest,
            paymentMode : e.detail.value.paymentMode,
            priceMode : e.detail.value.priceMode,
            publicGoods :1,// e.detail.value.publicGoods,
            valuationMode : e.detail.value.valuationMode,
            splitPackage:0,
            transportMode:"1041000",
            /*是否整车计划*/
            vehicleQuotation:0,
        };






        console.log(param)
        var options = {
            port: 'goodsCreUpd5',
            body: param,

        }
        app.connect(options).then(values => {
            console.log(values);
            success:(res)=>{
              console.log("成功");
              console.log(res)
            };
            fail:(res)=>{
              console.log("失败")
                console.log(res);
            };
        });

    },

})

