    /**
 * @author chenyang_yuan
 * @version 1.0
 * Created by chenyang_yuan on 2018/10/15.
 * content：货源报价多个报价界面
 */
var app = getApp();
Page({
    data: {
        imgRd: app.globalData[10],
        imgRdTwo: app.globalData[1],
        imgRd52: app.globalData[52],
        imgRd53: app.globalData[53],
        imgRd54: app.globalData[54],
        0:'按单价排序',
        1:'从低到高',
        2:'从高到低',
        3:'按时间排序',
        4:'最新报价',
        5:'最早报价',
        ldftVal:'按单价排序',
        rightVal:' 按时间排序',
        secOne: false,
        secTwo: false,
    },

    onLoad: function (event) {
        var options = {
            port: 'goodsQuotationListQry2',
            body: {"goodsID": app.globalData.goodsuuid}
        };
        app.connect(options).then(values => {
            console.log(values);
            this.setData({
                val: values.data.body.content.arrQuotationInfo,
                va:values.data.body.content,
                //从列表进来的order
                orderID:values.data.body.content.arrQuotationInfo["0"].orderID
            });
            app.orderID = values.data.body.content.arrQuotationInfo["0"].orderID;
        });
    },

    /*左边下拉框*/
    leftOrder: function (event) {
        this.setData({
            secOne: true,
            secTwo: false
        });
    },

    /*右边下拉框*/
    rightOrder: function (event) {
        this.setData({
            secOne: false,
            secTwo: true
        });
    },

    /*左框触发事件*/
    selLeftTap: function (event) {
        this.setData({
            ldftVal:this.data[event.target.dataset.id],
            secOne: false,
            secTwo: false,
        });
    },

    /*右框触发事件*/
    selRightTap:function (event) {
        this.setData({
            rightVal:this.data[event.target.dataset.id],
            secOne: false,
            secTwo: false,
        });
    },
    
    calling: function (event) {
        wx.makePhoneCall({
            phoneNumber: '15609695296', //此号码并非真实电话号码，仅用于测试
            success: function () {
                console.log("拨打电话成功！")
            },
            fail: function () {
                console.log("拨打电话失败！")
            }
        })
    },
    
    /*货源报价详情，委托订单*/
    supplyofgoodsQuote:function (event) {
        console.log(event);
        app.globalData.quotationuuid = event.currentTarget.dataset.quotationid;
        wx.navigateTo({
            url: '../../supplygoods/supplyofgoods_modetail/supplyofgoods_modetail?companyName='
            +this.data.va.arrQuotationInfo[event.currentTarget.dataset.id].userInfo.companyInfo.companyName+'&userName='
            +this.data.va.arrQuotationInfo[event.currentTarget.dataset.id].userInfo.userName+'&price='
            +this.data.va.arrQuotationInfo[event.currentTarget.dataset.id].price+'&weight='
            +this.data.va.arrQuotationInfo[event.currentTarget.dataset.id].amountInfo.weight+'&weightUnit='
            +this.data.va.arrQuotationInfo[event.currentTarget.dataset.id].amountInfo.weightUnit+'&totalPrice='
            +this.data.va.arrQuotationInfo[event.currentTarget.dataset.id].totalPrice+'&desc='
            +this.data.va.arrQuotationInfo[event.currentTarget.dataset.id].desc
        })
   },

    /*委托跳转创建订单*/
    entrust:function (event) {
        //报价id
        app.globalData.quotationuuid = event.currentTarget.dataset.quoid;
        wx.redirectTo({
            url: '/pages/supplygoods/creategoods/creategoods'
        })
    },

    /*创建订单成功,查看详情*/
    entOrderDit:function () {
        wx.navigateTo({
            url: '/pages/order/orderDtlQry/orderDtlQry'
        });
    },
})