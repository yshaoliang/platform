//引用加密and公用方法
const app = getApp();

Page({

    data: {
        imgRd:app.globalData[1],
        imgRd6:app.globalData[6],
    },

    /*不需要查，直接url传来的*/
    onLoad: function (event) {
        this.setData({
            vals:event
        })
    },


    /*委托跳转订单*/
    entrust:function () {
        wx.navigateTo({
            url: '../../supplygoods/creategoods/creategoods'
        })
    },
})