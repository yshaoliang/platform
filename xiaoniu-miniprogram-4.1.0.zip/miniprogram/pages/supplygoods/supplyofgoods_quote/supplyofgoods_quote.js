const app = getApp();
var publish = require('../../public_util/publishData');
Page({

    data: {
        imgRd:app.globalData[1],
        elementid:'1181000',
        elementname:'按整单',
        evn:"",
        consignorTotalPrice:'',
        totae:'',
        amountInfo:"",
        entrustedquantity:0,
        entrustednumbers:0,
    },

    onLoad: function (event) {
        console.log(app.orderdata["arrCargoInfo2"])
        for(var i=0;i<app.orderdata["arrCargoInfo2"].arrCargoInfo.length;i++){
            for(var j=0;j<app.orderdata["arrCargoInfo2"].arrCargoInfo[i].arrAmountInfo.length;j++){
                if(app.orderdata["arrCargoInfo2"].arrCargoInfo[i].arrAmountInfo[j].amountBizType==3){
                    if(app.orderdata["arrCargoInfo2"].arrCargoInfo[i].arrAmountInfo[j].volume!=0){
                        this.data.entrustedquantity=Number(this.data.entrustedquantity)+Number(app.orderdata["arrCargoInfo2"].arrCargoInfo[i].arrAmountInfo[j].volume)
                    }else{
                        this.data.entrustedquantity=Number(this.data.entrustedquantity)+Number(app.orderdata["arrCargoInfo2"].arrCargoInfo[i].arrAmountInfo[j].weight)
                    }
                    this.data.entrustednumbers=Number(this.data.entrustednumbers)+Number(app.orderdata["arrCargoInfo2"].arrCargoInfo[i].arrAmountInfo[j].quantity)
                }
            }
        }
        this.data.amountInfo=event
        this.setData({
            company: app.orderdata["company"],
            entrustedquantity:this.data.entrustedquantity,
            entrustednumbers:this.data.entrustednumbers,
            typeMode:publish.typeModes,
            evn:event,
            consignorTotalPrice:event.consignorTotalPrice,
            weight2:event.weight,
            volume2:event.volume,
        });
    },


    /*委托跳转订单*/
    entrust:function (event) {
        wx.navigateTo({
            url: '../../supplygoods/creategoods/creategoods'
        });
    },

    /*报价方式的触发事件*/
    element:function (e) {
        wx.navigateTo({
            url: '../../supplygoods/public_page/element/element?elementid=' + e.currentTarget.dataset.id,
        });
        console.log(this.data.elementid)
    },


    /*托运人体积变化*/
    ncyChangvol:function (event) {

        var total =  this.data.evn.consignorPrice * event.detail.value;
        this.setData({
            volume2:event.detail.value.ncyvolume ,
            consignorTotalPrice:total,
            ncyvolume:event.detail.value,
            volumeUnit:this.data.evn.volumeUnit,
            volumeUnitID:this.data.evn.volumeUnitID,
            ncyweight:"0",
            weightUnit:null,
            weightUnitID:null,
        });
    },
    /*托运人重量变化*/
    ncyChangwei:function (event) {
        console.log(event)
        console.log(this.data.evn)
        var total =  this.data.evn.consignorPrice * event.detail.value;
        this.setData({
            weight2:event.detail.value.ncyweight,
            consignorTotalPrice:total,
            ncyweight:event.detail.value,
            weightUnit:this.data.evn.weightUnit,
            weightUnitID:this.data.evn.weightUnitID,
            ncyvolume:"0",
            volumeUnit:null,
            volumeUnitID:null,

        });
    },

    /*物流商重量(体积)变化*/
    bindConsignncy:function (event) {
        console.log(event)
        if(this.data.elementid == 1181000){
        if (this.data.totae == ''){
            var pr = 0 / event.detail.value;
        }else{
            var pr = this.data.totae/event.detail.value;
        }
            if (this.data.evn.volume == 0){
                this.setData({
                    pr:pr,
                    pri:event.detail.value,
                    ncyweight:event.detail.value
                });
            }else{
                this.setData({
                    pr:pr,
                    pri:event.detail.value,
                    ncyvolume:event.detail.value
                });
            }

        }else if (this.data.elementid == 1181010){
            if (this.data.pricc == ''){
                var prto = 0 * event.detail.value;
            }else{
                var prto = this.data.pricc * event.detail.value;
            }

            if (this.data.evn.volume == 0){
                this.setData({
                    prto:prto,
                    pri:event.detail.value,
                    ncyweight:event.detail.value
                });
            }else{
                this.setData({
                    prto:prto,
                    pri:event.detail.value,
                    ncyvolume:event.detail.value
                });
            }
        }
    },

    /*物流商报价按整单*/
    bindConsignTotal:function (event) {
        //改变总和
        this.setData({
            totae:event.detail.value
        });
        //输入总价改变单价，拟承运不变
        if (this.data.evn.volume == 0){
                if(this.data.evn.weight == this.data.pri || undefined==this.data.pri ){
                        /*this.data.evn.weight*/
                        var pr = this.data.totae / this.data.entrustedquantity;
                        this.setData({
                            ncyweight:this.data.entrustedquantity,
                        })
                }else {
                    var pr = this.data.totae /this.data.pri;
                    this.setData({
                        ncyweight:this.data.pri,
                    })
                }
            this.setData({
                pr:pr,
                ncyweight:this.data.ncyweight,
                weightUnit:this.data.evn.weightUnit,
                weightUnitID:this.data.evn.weightUnitID,
                ncyvolume:"0",
                volumeUnit:null,
                volumeUnitID:null,
            });
        }else {
            if(this.data.evn.volume == this.data.pri || undefined==this.data.pri ){
                var pr = this.data.totae / this.data.entrustedquantity;
                this.setData({
                    ncyvolume:this.data.entrustedquantity,
                })
            }else {
                var pr = this.data.totae / this.data.pri;
                this.setData({
                    ncyvolume:this.data.pri,
                })
            }
            this.setData({
                pr:pr,
                ncyvolume:this.data.ncyvolume,
                volumeUnit:this.data.evn.volumeUnit,
                volumeUnitID:this.data.evn.volumeUnitID,
                ncyweight:"0",
                weightUnit:null,
                weightUnitID:null,
            });
        }

    },

    /*物流商按单价变化 -> 总价*/
    conPri:function (event) {
        console.log(event)
        this.setData({
            pricc:event.detail.value
    });
        //输入总价改变单价，拟承运不变
        if (this.data.evn.volume == 0){
            if(this.data.evn.weight == this.data.pri || undefined==this.data.pri ){
                var prto = this.data.pricc * this.data.entrustedquantity;
                this.setData({
                    ncyweight:this.data.entrustedquantity,
                })
            }else {
                var prto = this.data.pricc * this.data.pri;
                this.setData({
                    ncyweight:this.data.pri,
                })
            }
            this.setData({
                prto:prto,
                ncyweight:this.data.ncyweight,
                weightUnit:this.data.evn.weightUnit,
                weightUnitID:this.data.evn.weightUnitID,
                ncyvolume:"0",
                volumeUnit:null,
                volumeUnitID:null,
            });
        }else {
            if(this.data.evn.volume == this.data.pri || undefined==this.data.pri ){
                var prto = this.data.pricc * this.data.entrustedquantity;
                this.setData({
                    ncyvolume:this.data.entrustedquantity,
                })
            }else {
                var prto = this.data.pricc * this.data.pri;
                this.setData({
                    ncyvolume:this.data.pri,
                })
            }
            this.setData({
                prto:prto,
                ncyvolume:this.data.ncyvolume,
                volumeUnit:this.data.evn.volumeUnit,
                volumeUnitID:this.data.evn.volumeUnitID,
                ncyweight:"0",
                weightUnit:null,
                weightUnitID:null,
            });
        }
    },

    /*货源提交*/
    formSubmit: function(event) {
        app.orderdata["isRefresh"]=false
        console.log(event)
        console.log(event.detail.value.ncyvolume)
        var parms=null;
        if(undefined == event.detail.value.ncyvolume){
            this.setData({
                volume:0,
                weight:this.data.weight2 * 1
            })
        }
        if(undefined == event.detail.value.ncyweight){
            this.setData({
                volume:this.data.volume2 * 1,
                weight:0
            })
        }
        /*货主定价*/
        if(this.data.evn.priceMode == 1171000){
            //按整单
            if(this.data.evn.priceType == 1181000){
                console.log(1181000)
                console.log(this.data.evn)
                if(event.detail.value.consignTotal==""){
                    wx.showToast({
                        title: "总价不能为0",
                        mask: false,
                        icon: "none",
                        duration: 3000,
                        success(res) {

                        }
                    });
                }else{
                    parms= {
                        //货源id
                        "goodsID": app.globalData.goodsuuid,
                        //计价类型
                        "priceType":this.data.evn.priceType,
                        //报价总价
                        "totalPrice": event.detail.value.consignTotal,
                        //报价单价
                        "price": event.detail.value.djTwo,
                        //报价拟承运量
                        "amountInfo": {
                            amountBizType: "4",
                            quantity: this.data.evn.quantity,
                            quantityUnit: this.data.evn.quantityUnit,
                            quantityUnitID: this.data.evn.quantityUnitID,
                            volume:this.data.volume,
                            volumeUnit:this.data.volumeUnit,
                            volumeUnitID: this.data.volumeUnitID,
                            weight: this.data.weight,
                            weightUnit: this.data.weightUnit,
                            weightUnitID:this.data.weightUnitID,
                        },
                        desc:event.detail.value.beiz

                    }
                }

                console.log(parms)
            }
            //按单价
            else if (this.data.evn.priceType == 1181010){
                console.log(1181010)
                if(event.detail.value.conigPrice==""){
                    wx.showToast({
                        title: "单价不能为0",
                        mask: false,
                        icon: "none",
                        duration: 3000,
                        success(res) {

                        }
                    });
                }else{
                    parms = {
                        //货源id
                        "goodsID": app.globalData.goodsuuid,
                        //计价类型
                        "priceType":this.data.evn.priceType,
                        //报价总价
                        "totalPrice":event.detail.value.consignTotalTwo,
                        //报价单价
                        "price":event.detail.value.conigPrice,
                        //报价拟承运量
                        "amountInfo": {
                            amountBizType: "4",
                            quantity: this.data.evn.quantity,
                            quantityUnit: this.data.evn.quantityUnit,
                            quantityUnitID: this.data.evn.quantityUnitID,
                            volume:this.data.volume,
                            volumeUnit:this.data.volumeUnit,
                            volumeUnitID: this.data.volumeUnitID,
                            weight:this.data.weight,
                            weightUnit: this.data.weightUnit,
                            weightUnitID:this.data.weightUnitID,
                        },
                        desc:event.detail.value.beiz
                    }
                }

                console.log(parms)
            }
        }
        /*物流商报价*/
        else if (this.data.evn.priceMode == 1171010){
            //按整单
            if(this.data.elementid == 1181000){
                console.log(1181000)
                if(this.data.totae==""){
                    wx.showToast({
                        title: "总价不能为0",
                        mask: false,
                        icon: "none",
                        duration: 3000,
                        success(res) {

                        }
                    });
                }else{
                    parms= {
                        //货源id
                        "goodsID": app.globalData.goodsuuid,
                        //计价类型
                        "priceType":this.data.elementid,
                        //报价总价
                        "totalPrice": this.data.totae,
                        //报价单价
                        "price": this.data.pr,
                        //报价拟承运量
                        "amountInfo": {
                            amountBizType: "4",
                            quantity: this.data.evn.quantity,
                            quantityUnit: this.data.evn.quantityUnit,
                            quantityUnitID: this.data.evn.quantityUnitID,
                            volume:this.data.ncyvolume ,
                            volumeUnit:this.data.volumeUnit,
                            volumeUnitID: this.data.volumeUnitID,
                            weight: this.data.ncyweight,
                            weightUnit: this.data.weightUnit,
                            weightUnitID:this.data.weightUnitID,
                        },
                        desc:event.detail.value.beiz
                    }
                }

            }
            //按单价
            else if (this.data.elementid == 1181010){
                console.log(1181010)
                console.log(this.data.pricc)
                if(this.data.pricc==undefined){
                    wx.showToast({
                        title: "单价不能为0",
                        mask: false,
                        icon: "none",
                        duration: 3000,
                        success(res) {

                        }
                    });
                }else{
                    parms= {
                        //货源id
                        "goodsID": app.globalData.goodsuuid,
                        //计价类型
                        "priceType":this.data.elementid,
                        //报价总价
                        "totalPrice": this.data.prto,
                        //报价单价
                        "price": this.data.pricc,
                        //报价拟承运量
                        "amountInfo": {
                            amountBizType: "4",
                            quantity: this.data.evn.quantity,
                            quantityUnit: this.data.evn.quantityUnit,
                            quantityUnitID: this.data.evn.quantityUnitID,
                            volume:this.data.ncyvolume ,
                            volumeUnit:this.data.volumeUnit,
                            volumeUnitID: this.data.volumeUnitID,
                            weight: this.data.ncyweight,
                            weightUnit: this.data.weightUnit,
                            weightUnitID:this.data.weightUnitID,
                        },
                        desc:event.detail.value.beiz

                    }
                }

            }
        }
        console.log(event)
        if(parms!=null){
            var options = {
                port: 'goodsQuotationCreUpd3',
                body: parms
            };
            console.log(options)
            app.connect(options).then(values => {
                console.log(values);
                //成功之后，提示框，确认跳转到货源详情
                if(values.data.body.code==0){
                    wx.navigateBack({
                        delta: 1
                    });
                }else{
                    wx.showToast({
                        title: values.data.body.desc,
                        mask: false,
                        icon: "none",
                        duration: 3000,
                        success() {

                        }
                    });
                }

            });
        }
    },
});