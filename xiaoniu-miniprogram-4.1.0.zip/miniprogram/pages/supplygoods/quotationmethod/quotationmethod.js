var app = getApp();
Page({
    data: {
        name: '',
    },
    onLoad: function () {
        var body;
        var car;
        var ship;
        if (app.orderdata["quotationmethod_name"] == "按整单") {
            body = {
                car: "true",
                ship: "false"
            }
        } else {
            body = {
                car: "false",
                ship: "true"
            }
        }
        this.setData({
            save:app.globalData[11],
            shuju: body
        })
    },
    onShow: function () {
        var body;
        var car;
        var ship;
        if (app.orderdata["quotationmethod_name"] == "按整单") {
            body = {
                car: "true",
                ship: "false"
            }
        } else if (app.orderdata["quotationmethod_name"]== "按单价") {
            body = {
                car: "false",
                ship: "true"
            }
        }
        this.setData({
            shuju: body
        })
    },
    mySelect: function (e) {
        console.log(e.currentTarget.dataset.name)
        this.data.name = e.currentTarget.dataset.name
        var body;
        var car;
        var ship;
        console.log(this.data.name)
        if (this.data.name == "car") {
            app.orderdata["quotationmethod_type"] = 1181000;
            app.orderdata["quotationmethod_name"] = "按整单";
            body = {
                car: "true",
                ship: "false"
            }
        } else if (this.data.name == "ship") {
            app.orderdata["quotationmethod_type"] = 1181010;
            app.orderdata["quotationmethod_name"] = "按单价";
            body = {
                car: "false",
                ship: "true"
            }
        }
        console.log(body.car)
        this.setData({
            shuju: body
        })
        wx.navigateBack({
            delta: -1
        });
    }
})