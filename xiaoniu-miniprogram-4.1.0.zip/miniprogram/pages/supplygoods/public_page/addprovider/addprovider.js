Page({
    data: {
        company: "",
        userName: "",
        userPhone: ""
    },


    onLoad: function () {

    },


    mySelect: function (e) {


    },

})