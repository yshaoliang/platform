var app = getApp();
Page({
    data: {
        imgRd: app.globalData[11],
        light1: '',
        light2: '',
        light3: '',
        myclerd: "mySelect",
        mythree: "mySelectThree",
        light1Id:'',
        light1Name:'',
        light2Id:'',
        light2Name:'',
    },

    onLoad: function (options) {
        console.log(options);
        if (options.light3 == "") {
            this.setData({
                myclerd: "mySelect",
                light1:options.light1,
                light2:options.light2,
            })
        } else {
            this.setData({
                light3: options.light3,
                myclerd: "",
            });
        }
    },


    mySelectThree: function (e) {
        /*console.log(e);
        console.log(this.data.light3)*/
        if (this.data.light3 == true) {
            this.setData({
                myclerd: "",
            })
        }
       /* console.log(e);
        console.log(this.data.light3)*/
        if (this.data.light3 != "true") {
            if ("2001020" == e.currentTarget.dataset.id) {
                var pages = getCurrentPages();
                var prevPage = pages[pages.length - 2];  //上一个页面
                prevPage.setData({
                    light3: true,
                    myclerd: '',
                    light3Name:e.currentTarget.dataset.name
                });
                wx.navigateBack({
                    delta: 1,
                });
            }
        } else {
            this.setData({
                light3: false,
                myclerd: 'mySelect',
            })
        }
    },

    mySelect: function (event) {
       /* console.log(event);
        console.log(event.currentTarget.dataset.id)*/
        switch (event.currentTarget.dataset.id) {
            case "2001000": {
                this.setData({
                    light1: true,
                    light1Id:event.currentTarget.dataset.id,
                    light1Name:event.currentTarget.dataset.name,
                    mythree: ''
                });
                if (event.currentTarget.dataset.ss == true) {
                    this.setData({
                        light1: false,
                        mythree: ''
                    });
                }
            }
                break;
            case  "2001010": {
                this.setData({
                    light2: true,
                    light2Id:event.currentTarget.dataset.id,
                    light2Name:event.currentTarget.dataset.name,
                    mythree: ''
                });
                if (event.currentTarget.dataset.ss == true) {
                    this.setData({
                        light2: false,
                        mythree: ''
                    });
                }
            }
        }

        if (this.data.light1 == false && this.data.light2 == false) {
            this.setData({
                mythree: "mySelectThree"
            })
        }
    },

    commit:function (event) {
        console.log(event);
        var pages = getCurrentPages();
        var prevPage = pages[pages.length - 2];  //上一个页面
        prevPage.setData({
            light1: this.data.light1,
            light2: this.data.light2,
            light3:"",
            light1Id:this.data.light1Id,
            light1Name:this.data.light1Name,
            light2Id:this.data.light2Id,
            light2Name:this.data.light2Name,
        });
        wx.navigateBack({
            delta: 1,
        })
    },

})

