var app = getApp();
Page({
  data: {
    light1: true,
    light2: false,
    imgRd:app.globalData[11],
  },

  onLoad: function(options) {
     this.touchSet(options.elementid);
  },

  mySelect: function(e) {
      this.touchSet(e.currentTarget.dataset.id)
          var pages = getCurrentPages();
          var prevPage = pages[pages.length - 2];  //上一个页面
          prevPage.setData({
              elementname: e.currentTarget.dataset.name,
              elementid: e.currentTarget.dataset.id,
              total: e.currentTarget.dataset.total,
          });
          wx.navigateBack({
              delta: 1,
          })
  },

  touchSet:function (event) {
      switch (event) {
          case "1181000": {
              this.setData({
                  light1: true,
                  light2: false,
              })
              break;
          }

          case "1181010": {
              this.setData({
                  light1: false,
                  light2: true,
              })
          }
      }
  }
})


