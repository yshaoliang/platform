var app = getApp();
Page({
  data: {
    light1: true,
    light2: false,
    light3: false,
    imgRd:app.globalData[11],
  },

  onLoad: function(options) {
      this.touchSet(options.dataid);
  },
  mySelect: function(e) {
      this.touchSet(e.currentTarget.dataset.id);

          var pages = getCurrentPages();
          var prevPage = pages[pages.length - 2];  //上一个页面
          prevPage.setData({
              hight: e.currentTarget.dataset.name,
              dataid: e.currentTarget.dataset.id,
              weightvolume: e.currentTarget.dataset.ss,
          });
          wx.navigateBack({
              delta: 1,
          })

  },

  touchSet:function (event) {
      switch(event){
          case "1131000":
              this.setData({
                  light1: true,
                  light2: false,
                  light3: false
              })
              break;
          case "1131010":
              this.setData({
                  light1: false,
                  light2: true,
                  light3: false,
              })
              break;
          case "1131020":
              this.setData({
                  light1: false,
                  light2: false,
                  light3: true,
              })
              break;
      }
  }

})

