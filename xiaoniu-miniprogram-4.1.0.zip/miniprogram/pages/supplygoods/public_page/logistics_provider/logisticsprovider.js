var app = getApp();
Page({
    data: {
        empty: [],
        imgRd: app.globalData[12],
        imgRd11: app.globalData[11],
        arrpublylength: '',
        arrpubly: '',
        arrindex:[],
    },

    onLoad: function (arrpubly) {
          var options = {
                port: 'companyListQry',
                body: {isMember: true}
            };
            app.connect(options).then(values => {
                this.setData({
                    empty: values.data.body.content.arrCompanyInfo,
                });
            });

            if (arrpubly.arrpublylength < 1){

            }else {
                    this.setData({
                        arrindex:arrpubly.arrpubly.split(","),
                    })
                    console.log(this.data.arrindex)
            }
        },

    /*多选*/
    checkboxChange: function (event) {
        console.log(event);
        this.setData({
            arrpublylength: event.detail.value.length,
            arrpubly: event.detail.value
        })
    },

    /*确定跳转*/
    submitcheck: function () {
        var pages = getCurrentPages();
        var prevPage = pages[pages.length - 2];  //上一个页面
        prevPage.setData({
            arrpublylength: this.data.arrpublylength,
            arrpubly: this.data.arrpubly,
        });
        wx.navigateBack({
            delta: 1,
        })
    },

    /*搜索添加物流商*/
    addprovider: function (event) {
        wx.navigateTo({
            url: '../../public_page/addprovider/addprovider?invoiceid=' + event.currentTarget.dataset.id,
        })
    },


})