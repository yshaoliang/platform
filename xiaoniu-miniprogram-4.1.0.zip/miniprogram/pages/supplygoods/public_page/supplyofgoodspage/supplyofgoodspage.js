var app = getApp();
Page({
    data: {
        imgRd:app.globalData[11],

    },

    onLoad: function (options) {

    },

    mySelect: function (e) {
        var pages = getCurrentPages();
        var prevPage = pages[pages.length - 2];  //上一个页面
        console.log(e.currentTarget.dataset.id)
        prevPage.setData({
            right_supplyofgoods: '货源类型',
            left_supplyofgoods: e.currentTarget.dataset.name,
            left_id: e.currentTarget.dataset.id,
        });
        wx.navigateBack({
            delta: 1,
        })
    },
})