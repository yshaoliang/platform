var app = getApp();
Page({
    data: {
        imgRd:app.globalData[11],
           },

    onLoad: function (options) {
    },

    mySelect: function (e) {
        var pages = getCurrentPages();
        var prevPage = pages[pages.length - 2];  //上一个页面
        prevPage.setData({
            left_supplyofgoods: '货源状态',
            right_supplyofgoods: e.currentTarget.dataset.name,
            right_id:e.currentTarget.dataset.id,
        });
        wx.navigateBack({
            delta: 1,
        })
    },
})