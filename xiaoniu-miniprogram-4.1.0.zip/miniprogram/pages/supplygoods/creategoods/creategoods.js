//订单详情页面
var util = require('../../login/md5.js');
var publish = require('../../public_util/publishData');
var app = getApp();
Page({
    data: {
        imgRd:app.globalData[1],
        imgRd6:app.globalData[6],
        transportMode:"",
        light1:false,
        light2:false,
        light3:false,
        myclerd:'',
        light1Id:'',
        light1Name:'',
        light2Id:'',
        light2Name:'',
        light3Name:'',
        multiArray1: [publish.years,publish.mouths,publish.days,publish.houvers,publish.branchs],
        multiIndex1: ["", "", "","",""],
    },

    onLoad: function () {
        /*自己的物价信息*/
        var optionst = {
            port: 'goodsDtlQry5',
            body: {"goodsID": app.globalData.goodsuuid}
        };

        app.connect(optionst).then(values => {
            console.log(values);
            this.setData({
                goodsVal: values.data.body.content,
                consigneeInfo_cityShortName:app.oncityNam(values.data.body.content.consigneeInfo.addressInfo.cityShortName),
                consignorInfo_cityShortName:app.oncityNam(values.data.body.content.consignorInfo.addressInfo.cityShortName)
            });
        });

        /*各个人员报价*/
            var options = {
            port: 'goodsQuotationDtlQry3',
            body: {"quotationID": app.globalData.quotationuuid}
        };

        app.connect(options).then(values => {
            console.log(values);
            this.setData({
                quotationVal: values.data.body.content.quotationInfo
            })
        });

    },


    /*跳转回单*/
    returnPage:function (event) {
        wx.navigateTo({
       url:'/pages/supplygoods/public_page/returnpage/returnpage'
        })
      /*  wx.navigateTo({
      url: '/pages/supplygoods/public_page/returnpage/returnpage?light1='+this.data.light1+'&light2='+this.data.light2+'&light3='+this.data.light3
    })*/
    },


    calling: function () {
        wx.makePhoneCall({
            phoneNumber: '15609695296', //此号码并非真实电话号码，仅用于测试
            success: function () {
                console.log("拨打电话成功！")
            },
            fail: function () {
                console.log("拨打电话失败！")
            }
        })
    },

    //时间选择的插件
    ontime1:function(){
        var myDate = new Date();
        var a=0;
        var b=0;
        var c=0;
        var d=0;
        var e=0;
        for(var i=89;i<parseInt(myDate.getYear());i++){
            a=a+1
        }
        for(var i=0;i<parseInt(myDate.getMonth());i++){
            b=b+1
        }
        for(var i=1;i<parseInt(myDate.getDate());i++) {
            c = c + 1
        }
        for(var i=0;i<parseInt(myDate.getHours());i++){
            d=d+1
        }
        for(var i=0;i<parseInt(myDate.getMinutes());i++){
            e=e+1
        }
        this.data. multiIndex1[0]=a
        this.data. multiIndex1[1]=b
        this.data. multiIndex1[2]=c
        this.data. multiIndex1[3]=d
        this.data. multiIndex1[4]=e
        this.setData({
            multiArray1:this.data.multiArray1,
            multiIndex1:this.data. multiIndex1
        })
    },

    bindMultiPickerColumnChange1: function (e) {
        for(var i=0;i<this.data.multiArray1.length;i++){
            for(var j=0;j<this.data.multiArray1[i].length;j++) {
                if (i==0) {
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("年","");
                    console.log(this.data.multiArray1[i][j])
                }else if(i==1){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("月",'')
                }else if(i==2){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("日",'')
                }else if(i==3){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("时",'')
                }else if(i==4){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("分",'')
                }else if(i==5){
                    this.data.multiArray1[i][j]=this.data.multiArray1[i][j].replace("秒",'')
                }
            }
        }
        console.log('修改的列为', e, '，值为', e.detail.value);
        var data1 = {
            multiArray1: this.data.multiArray1,
            multiIndex1: this.data.multiIndex1
        };
        data1.multiIndex1 = e.detail.value;
        this.setData(
            data1
        );
        this.data.destinationDate=data1.multiArray1[0][data1.multiIndex1[0]]+"-"+data1.multiArray1[1][data1.multiIndex1[1]]+"-"+data1.multiArray1[2][data1.multiIndex1[2]]+" "+data1.multiArray1[3][data1.multiIndex1[3]]+":"+data1.multiArray1[4][data1.multiIndex1[4]]+":00"
    console.log(this.data.destinationDate)
    },

    /*创建提交订单*/
    formSubmit:function (event) {
        var param;
        console.log(event);
        param = {
            /*货物类别*/
            arrCargoInfo: this.data.goodsVal.arrCargoInfo,
            /*付款进度*/
            arrPaymentModeInfo: [{
                //price
                money: this.data.quotationVal.totalPrice,
                paymentMode: this.data.goodsVal.paymentMode,
                /*到付的code码*/
                paymentModeDesc: "\U73b0\U4ed8",
            }],
            /*回单要求*/
            arrPodType: [2001000],
            /*收货时间*/
            arrivalDate: this.data.goodsVal.arrivalDate,
            /*承运人公司id*/
            carrierCompanyID: this.data.quotationVal.userInfo.companyInfo.companyID,
            /*承运人用户id*/
            carrierUserID: this.data.quotationVal.userInfo.userID,

            /*收货人信息*/
            consigneeInfo: {
                addressInfo: {
                    address: event.detail.value.jd,
                    addressID: this.data.goodsVal.consigneeInfo.addressInfo.addressID,
                    cityCode: this.data.goodsVal.consigneeInfo.addressInfo.cityCode,
                    cityName: this.data.goodsVal.consigneeInfo.addressInfo.cityName,
                    cityShortName: app.oncityNam(this.data.goodsVal.consigneeInfo.addressInfo.cityShortName),
                },
                companyName:event.detail.value.shdw,
                fax: this.data.goodsVal.consigneeInfo.fax,
                linkmanID: this.data.goodsVal.consigneeInfo.linkmanID,
                mobile: this.data.goodsVal.consigneeInfo.mobile,
                name: this.data.goodsVal.consigneeInfo.name,
                tel:this.data.goodsVal.consigneeInfo.tel,
                userID: this.data.goodsVal.consigneeInfo.userID,
            },



            /*发货人信息*/
            consignorInfo: {
                addressInfo: {
                    address: event.detail.value.jd2,
                    addressID: this.data.goodsVal.consignorInfo.addressInfo.addressID,
                    cityCode: this.data.goodsVal.consignorInfo.addressInfo.cityCode,
                    cityName: this.data.goodsVal.consignorInfo.addressInfo.cityName,
                    cityShortName: app.oncityNam(this.data.goodsVal.consignorInfo.addressInfo.cityShortName),
                },
                    companyName: this.data.goodsVal.consignorInfo.companyName,
                    fax: this.data.goodsVal.consignorInfo.fax,
                    linkmanID: this.data.goodsVal.consignorInfo.linkmanID,
                    mobile: this.data.goodsVal.consignorInfo.mobile,
                    name: this.data.goodsVal.consignorInfo.name,
                    tel: this.data.goodsVal.consignorInfo.tel,
                    userID: this.data.goodsVal.consignorInfo.userID,
            },

            /*是否创建货源*/
            createGoods: 0,
            /*出发时间*/
            deliveryDate: this.data.goodsVal.deliveryDate,
            /*点间类型*/
            deliveryMode: 1011000,
            /*备注F*/
            desc: event.detail.value.desc,
            /*距离F*/
            distance: null,

            /*价格信息T*/
            freightInfo: {
                arrFeesInfo: null,
                feeOfCollection: null,
                freightID: null,
                insurance: null,
                paymentCollection: null,
                premiumRate: null,
                total:this.data.quotationVal.totalPrice,
                valueInsured: null,
            },
            /*货值申明F*/
            goodsValue: null,
            /*货物已经入库T*/
            inStorage: 0,
            /*对应科目T*/
            insureSubjectId: null,
            /*投保类型0：无；1货运险*/
            insureType: 0,
            /*发票要求T*/
            invoiceRequest:  this.data.goodsVal.invoiceRequest,
            /*物流订单ID*/
            orderID: null,
            /*订单来源F*/
            orderOrigin: 2201010,
            /*货源报价ID F*/
            quotationID: app.globalData.quotationuuid,
            /*经纪佣金F*/
            rebate: null,
            /*经纪佣金已返T*/
            rebatePaid: 0,
            /*交易时间T*/
            salesTime:this.data.destinationDate,
            /*业务员*/
            salesmanUserID: this.data.goodsVal.trustorInfo.userID,
            /*运输方式T*/
            transportMode: this.data.goodsVal.transportMode,
            /*托运人公司id*/
            trustorCompanyID: this.data.goodsVal.trustorInfo.companyInfo.companyID,
            /*托运人用户ID*/
            trustorUserID: this.data.goodsVal.trustorInfo.userID,
            /*计价方式T*/
            valuationMode: this.data.goodsVal.valuationMode,
            /*是否整单计价T*/
            vehicleQuotation: true,
        };

        console.log(param);
        var options = {
            port: 'orderCreUpd',
            body: param
        };
        app.connect(options).then(values => {
            console.log(values);
            //创建订单成功了，将订单设置为全局
            wx.redirectTo({
                url: '/pages/supplygoods/supplyofgoods_money/supplyofgoods_money'
               });
            app.orderID = values.data.body.content.orderID
            console.log(11)
        });
    },
});
