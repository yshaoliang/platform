var app=getApp();
Page({
    onLoad:function () {
        console.log(app.orderdata["arrCargoInfo"])
        this.setData({
            arrCargoInfo:app.orderdata["arrCargoInfo"]
        })
    }
})