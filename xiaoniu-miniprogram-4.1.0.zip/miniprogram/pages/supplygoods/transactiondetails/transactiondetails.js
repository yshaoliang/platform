var  app=getApp();
Page({
    data:{
        imgRd:app.globalData[1],
    },
    onLoad:function (e) {
        app.orderdata["quotationID"]=e.quotationID
        var that=this;
        var price=0;
        var options = {
            port: 'goodsQuotationDtlQry2',
            body: {"quotationID": e.quotationID}
        };
        app.connect(options).then(values => {
            console.log(values)

            if(values.data.body.content.quotationInfo.amountInfo.weight!="0"){
                price=Number(values.data.body.content.quotationInfo.totalPrice) /Number(values.data.body.content.quotationInfo.amountInfo.weight)
           console.log(price)
            }else if(values.data.body.content.quotationInfo.amountInfo.volume!="0"){
                price=Number(values.data.body.content.quotationInfo.totalPrice)/Number(values.data.body.content.quotationInfo.amountInfo.volume)
                console.log(price)
            }
            that.setData({
                phone:app.globalData[16],
                goodsStatusDesc:app.orderdata["goodsStatusDesc"],
                price:price,
                shuju:values.data.body.content
            })

        })
    },
    onModify:function () {
        wx.navigateTo({
            url: '../quotationmodification/quotationmodification'
        });
    },
    onDetails:function () {
        wx.navigateTo({
            url: '/pages/order/orderDtlQry/orderDtlQry'
        });
    },
 onphone:function (e) {
     var phoneNunmber=e.currentTarget.dataset.name
     wx.makePhoneCall({
         phoneNumber: phoneNunmber
     })
 },
    onShow:function () {

        var that=this;
        var price=0;
        var options = {
            port: 'goodsQuotationDtlQry2',
            body: {"quotationID": app.orderdata["quotationID"]}
        };
        app.connect(options).then(values => {
            console.log(values)

            if(values.data.body.content.quotationInfo.amountInfo.weight!="0"){
                price=Number(values.data.body.content.quotationInfo.totalPrice) /Number(values.data.body.content.quotationInfo.amountInfo.weight)
                console.log(price)
            }else if(values.data.body.content.quotationInfo.amountInfo.volume!="0"){
                price=Number(values.data.body.content.quotationInfo.totalPrice)/Number(values.data.body.content.quotationInfo.amountInfo.volume)
                console.log(price)
            }
            that.setData({
                phone:app.globalData[16],
                goodsStatusDesc:app.orderdata["goodsStatusDesc"],
                price:price,
                shuju:values.data.body.content
            })

        })
    }

})