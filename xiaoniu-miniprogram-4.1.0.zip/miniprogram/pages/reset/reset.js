var app = getApp();
var interval = null //倒计时函数
Page({
    data: {
        imgRd:app.globalData[1],
        imgRd6:app.globalData[6],
        date:'请选择日期',
        fun_id:2,
        time: '获取验证码', //倒计时
        currentTime:61
    },


    onLoad: function () {


    },

    /*sjhm手机号码*/
    sjhm:function (event) {
        this.setData({
            sjhmVal: event.detail.value
        })
    },
    /*验证码*/
    yzm:function (event) {
        this.setData({
            yzmVal: event.detail.value
        })
    },
    /*szmm设置密码*/
    szmm:function (event) {
        this.setData({
            szmmVal: event.detail.value
        })
    },

/*验证码的倒计时*/
    getCode: function (options){
        var that = this;
        var currentTime = that.data.currentTime
        interval = setInterval(function () {
            currentTime--;
            that.setData({
                time: currentTime+'秒'
            })
            if (currentTime <= 0) {
                clearInterval(interval)
                that.setData({
                    time: '重新发送',
                    currentTime:61,
                    disabled: false
                })
            }
        }, 1000)
        that.setData({
            disabled:false
        })
    },

    /*验证码的获取*/
    getVerificationCode(event){
        wx.setStorageSync('token', null);
        var that = this

        var options = {
            port: 'getCaptcha',
            body: {
                "mobile":this.data.sjhmVal,
                "bizCode":1,
            }
        };
        app.connect(options).then(values => {
            console.log(values);
            if (values.data.body.code == -1){
                wx.showModal({
                    title: "注册失败",
                    content:values.data.body.desc,
                    showCancel:false,
                    duration: 1500,
                });
            }else{
                this.getCode();
                that.setData({
                    disabled:true
                })
            }
        });
    },

    /*下一步*/
    nextTo:function () {
        wx.navigateTo({
            url: '../resetnextstep/resetnextstep?sjhmVal='
            +this.data.sjhmVal+'&yzmVal='
            +this.data.yzmVal+'&szmmVal='
            +this.data.szmmVal
        });
    },
});
