var md = require('pages/login/md5.js');
var Promise = require('pages/public_util/es6-promise.auto');

App({
  
    data: {

        // 更改版本需要
        appName:"运输圈",
        appSecret:"pA2eJ8zGRXGcqnCK5x0pRg",
        appKey:"1gB3n3XnSpuUITDsXaeUXA",
        allDomainNameUrl: 'https://192.168.0.1/api/',
        imgName:'xiaoniu_w@2x.png',

        //图片路径
        domainNameUrl: "192.168.0.1",
        access_token:"",
        /*注册-电话号码*/
        mobile: '',
        /*注册-验证码*/
        captcha1: '',
        /*注册-密码*/
        password: '',
        /*作废列别*/
        havebeenabandoned: '已作废',
        /*全部*/
        all: '全部',
        /*报价中*/
        quotation: '报价中',
        /*已完成*/
        completed: '已完成',
        /*已游标*/
        alreadycursor: '已游标',
        /*全部货源*/
        allsourceofgoods: '全部货源',
        /*我发布的*/
        ireleasedit: '我发布的',
        /*我报价的*/
        iquoted: '我报价的',
        /*新增车辆*/
        vehicletype_name: '车辆',
        /*个人*/
        personal_name: '个人',
        datas: '',
        /*订单id*/
        orderID: '',
        /*具体车辆名*/
        selection: '',
        /*车船类型*/
        shiptype: '',
        /*车长*/
        length: '',
        /*车型*/
        carriertype: '车型',
        /*载具长度*/
        loadlength: '车长',
        /*城市编码*/
        cityCode: '',
        /*城市姓名*/
        cityName: '',
        /*载具名*/
        shipName: '',
        /*车长*/
        lengthValue: '',
        typeofdriver_name: '外协司机',
        /*司机类型*/
        relationType: '1',
        /*司机姓名*/
        driverName: '选择司机',
        /*船型*/
        carmoderlName: '',
        /*船型码*/
        carmoderlType: '',
        /*船区*/
        navigationarea: '',
        /*车船型号*/
        vehiclemodel: '选择载具',
        /*车船属性*/
        vehiclepropertye: '',
        /*号码*/
        drivermobile: '',
        /*载具ID*/
        vehicleID: '',
        /*主驾驶id*/
        chiefDriverID: '',
        /*货物id*/
        cargoID: '',
        /*货物姓名*/
        cargoName: '',
        /*规格型号*/
        model: '',
        /*计量方式*/
        valuationMode: '',
        /*计价方式描述*/
        valuationModeDesc: '',
        /**/
        amountInfo: '',
        /*计划出发*/
        deliveryDate: '',
        /*计划到达时间*/
        destinationDate: '',
        /*联系人*/
        consignorInfoAll: '',
        isDeliveryCentre: '',
        deliveryCentreID: '',
        consigneeInfoAll: '',
        isDestinationCentre: '',
        destinationCentreID: '',
        newschedulingindex: 0,
        allarr: '',
        /*判断下标*/
        newschedulingindex1: 0,
        arrCargoInfoAll: '',
        islistdispatchBatchID: '',
        /*日志对象*/
        userSimpleInfo:'',
        arrCargoInfo:'',
        driverID:'',
        vehicleID1:'',
        sex_name:'男',
        sex: '1',
        driverType:'1',
        token:'',
        drivingType:'',
        drivingName:'',
        isEffective:'是',
        isRegister:false
    },

    onLaunch: function () {
        console.log("<--------WX-最先-入口-达牛-信息------->")
        if (!wx.cloud) {
            console.error('请使用 2.2.3 或以上的基础库以使用云能力')
        } else {
            wx.cloud.init({
                traceUser: true,
            })
        }
        var imgUrl = 'http://' + this.data.domainNameUrl + '/appimg/';
        this.globalData = {
            0: imgUrl + "120.png",
            1: imgUrl + "rightArrow.png",
            3: imgUrl + "修改.png",
            4: imgUrl + "我要报价.png",
            5: imgUrl + "结束.png",
            6: imgUrl + "phone.png",
            7: imgUrl + "btn_forward_pressed.png",
            8: imgUrl + "128 128.png",
            9: imgUrl + "verifyCer@2x.png",
            10: imgUrl + "yunxiao2_logo@2x.png",
            11: imgUrl + "btn_save_pressed@2x.png",
            12: imgUrl + "btn_add_pressed.png",
            13: imgUrl + "logo_w@2x.png",
            14: imgUrl + "to@2x.png",
            15: imgUrl + "btn_location_default@2x.png",
            16: imgUrl + "phone.png",
            17: imgUrl + "icon_destination.png",
            18: imgUrl + "icon_origin@2x.png",
            19: imgUrl + "加@2x.png",
            20: imgUrl + "unSelected@2x.png",
            21: imgUrl + "btn_add_item@2x.png",
            22: imgUrl + "icon_car.png",
            23: imgUrl + "icon_ship@2x.png",
            24: imgUrl + "goods@2x.png",
            25: imgUrl + "logo_w@2x.png",
            26: imgUrl + "btn_goods_default@2x.png",
            27: imgUrl + "main_goods@2x.png",
            28: imgUrl + "order_workplace@2x.png",
            29: imgUrl + "goods_workplace@2x.png",
            30: imgUrl + "dispatch_workplace@2x.png",
            31: imgUrl + "track_workplace@2x.png",
            32: imgUrl + "vehicle_workplace@2x.png",
            33: imgUrl + "driver_workplace@2x.png",
            34: imgUrl + "yunhua_logo@2x.png",
            35: imgUrl + "mine_default@3x.png",
            36: imgUrl + "mine_selected@3x.png",
            37: imgUrl + "backspace@2x.png",
            38: imgUrl + "disagree_blue@2x.png",
            39: imgUrl + "agree_blue@2x.png",
            40: imgUrl+"mine_default@2x.png",
            41: imgUrl+"mineLine_selected@2x.png",
            42: imgUrl+"btn_goods_default@2x.png",
            43: imgUrl+"goodsLine_selected@2x.png",
            44: imgUrl+"topicDefault@2x.png",
            45: imgUrl+"topicSelected@2x.png",
            //要改

            46: imgUrl + this.data.imgName,

            47:imgUrl+'selected@2x.png',
            48:imgUrl+'rightArrow.png',
            49:imgUrl+'icon_msg_query.png',
            50:imgUrl+'camera@2x.png',
            51:imgUrl+'star_gray.png',
            52:imgUrl+'star_high.png',
            53:imgUrl+'btn_up@2x.png',
            54:imgUrl+'btn_down@2x.png',
            55:imgUrl+'messageSendFail@2x.png',
            56:imgUrl+'verifyCer@2x.png',
            57:imgUrl+'mine_setting@2x.png',
            58:imgUrl+'btn_order_default@2x.png',
            59:imgUrl+'btn_driver_default@2x.png',
            60:imgUrl+'zywl_logo@2x.png',
            61:imgUrl+'klwl_logo@2x.png',
            62:imgUrl+'sly_logo@2x.png',
            63:imgUrl + 'scan@2x.png'

        }
        this.orderdata={
            dispatchStatusCode:'',
            driver:'',
            teamID:'',
            bepresentcolor:"",
            shipmentcolor:"",
            signincolor:"",
            index:"",
            key:"",
            dispatchStatus:"",
            arrCargoInfo:"",
            orderID:"",
            quotationmethod_name:"按整单",
            quotationmethod_type:1181000,
            quotationID:"",
            goodsID:"",
            priceType:"",
            goodsStatusDesc:"",
            isFree:"",
            isRefresh:"true",
            arrCargoInfo1:"",
            arrCargoInfo2:"",
            orderCode:"",
            route:"",
            company:"",
            company1:"",
            jumppath:"",
            issupply:"",
            formId:"",
            latitude:null,
            longitude:null,
            speed:"",
            accuracy:"",
            type:""
         }
    },
    /**
     * @author chenyang_yuan
     * @version 1.0
     * Created by chenyang_yuan on 2018/10/14.
     * content：所用方法的入参统一方法
     *var token = wx.getStorageSync('token');
     */
    connect: function (options) {
        console.log(options)
        var that = this;
        let prom = new Promise(function (resolve, reject) {
        //要改
          var url = that.data.allDomainNameUrl + options.port;
            var jsonHeader = {
                "header": {
                    "serviceName": null,
                    "userAgent": "WEB",
                    "channel": null,
                    "userID": "VPuDlEC8SnGzqL9_kVfUng",
                    "privateField": null,
                    "serialId": null
                },
                "body": options.body,
            };
            wx.getStorage({
                key: 'token',
                success: function (res) {
                    console.log(res.data)
                    var app_secret = that.data.appSecret;
                    var app_key = that.data.appKey;
                    var version = "1.0.1";
                    var timestamp = new Date().getTime();
                    var params = JSON.stringify(jsonHeader);
                    var sign = that.data.appSecret + "access_token" + res.data + "app_key" + app_key + "timestamp" + timestamp + "version" + version + "param" + params + that.data.appSecret;
                    var strSignContents = encodeURIComponent(sign);
                    var s = strSignContents.replace(/:/g, "%3A").replace(/%20/g, "+");
                    var strSignContent = md.hex_md5(s).toLocaleUpperCase();
                    var datas = {
                        access_token: res.data,
                        app_key: app_key,
                        sign: strSignContent,
                        timestamp: timestamp,
                        version: version,
                        secretKey: that.data.appSecret,
                        param: params
                    };

                    wx.request({
                        data: datas,
                        header: {'content-type': 'application/x-www-form-urlencoded'},
                        url: url,
                        method: 'POST',
                        success: function (res) {
                            console.log(res)
                            resolve(res);
                            console.log(res)
                            if(res.data.body.code=="-99"){
                                wx.showModal({
                                    title:"提示",
                                    content:res.data.body.desc,
                                    showCancel:false,
                                    //用户确定
                                    success:function (res) {
                                        if (res.confirm){
                                            //清除缓存中数据
                                            wx.removeStorageSync('token');
                                            //实现跳转
                                            wx.reLaunch({
                                                url:'/pages/login/login',
                                            });
                                        }
                                    },
                                    //退出失败，可能一些原因导致
                                    fail:function (res) {
                                        console.log(res)
                                        wx.hideLoading()
                                        wx.showToast({
                                            title:"退出失败,请反馈",
                                            duration:1500,
                                        });
                                    },
                                });
                            }
                        },
                        fail: function (event) {
                            console.log(res)
                            wx.hideLoading()
                            wx.showModal({
                                title: "登录失败",
                                content:"请重新输入",
                                showCancel:false,
                                duration: 1500,
                            });
                        },
                    })

                },
                fail: function (res) {
                        var app_secret = that.data.appSecret;
                        var app_key = that.data.appKey;
                        var version = "1.0.1";
                        var timestamp = new Date().getTime();
                        var params = JSON.stringify(jsonHeader);
                        var sign = that.data.appSecret + "app_key" + app_key + "timestamp" + timestamp + "version" + version + "param" + params + that.data.appSecret;
                        var strSignContents = encodeURIComponent(sign);
                        var s = strSignContents.replace(/:/g, "%3A").replace(/%20/g, "+");
                        var strSignContent = md.hex_md5(s).toLocaleUpperCase();
                        var datas = {
                            app_key: app_key,
                            sign: strSignContent,
                            timestamp: timestamp,
                            version: version,
                            secretKey: that.data.appSecret,
                            param: params
                        };
                        wx.request({
                            data: datas,
                            header: {'content-type': 'application/x-www-form-urlencoded'},
                            url: url,
                            method: 'POST',
                            success: function (res) {
                                resolve(res);
                                wx.hideLoading()
                                console.log(res)
                                if(res.data.body.code=="-99"){
                                    wx.showModal({
                                        title:"提示",
                                        content:res.data.body.desc,
                                        showCancel:false,
                                        //用户确定
                                        success:function (res) {
                                            if (res.confirm){
                                                //清除缓存中数据
                                                wx.removeStorageSync('token');
                                                //实现跳转
                                                wx.reLaunch({
                                                    url:'/pages/login/login',
                                                });
                                            }
                                        },
                                        //退出失败，可能一些原因导致
                                        fail:function (res) {
                                            wx.hideLoading()
                                            wx.showToast({
                                                title:"退出失败,请反馈",
                                                duration:1500,
                                            });
                                        },
                                    });
                                }
                            },
                            fail: function (event) {
                                wx.hideLoading()
                                wx.showModal({
                                    title: "登录失败",
                                    content:"请重新输入",
                                    showCancel:false,
                                    duration: 1500,
                                });
                            },
                        })

                }
            });
        })
        return prom
    },
    oncityNam:function(cityName) {
    var str = "";
    if(cityName){
        var a = cityName.split(",");
        var isShowFirst = true;
        if(undefined != arguments[1] && null != arguments[1]){
            isShowFirst = arguments[1];
        }
        switch (a.length)
        {
            case 1:
                str = cityName;
                break;
            case 2:
                if (a[1] == "市辖区" || a[1] =="县")
                    str = a[0];
                else
                    str = a[0] + a[1];
                break;
            case 3:
                if (a[2].substr(a[2].indexOf("市"),a[2].length) == "市"  || a[1] =="市辖区" || a[1] =="县")
                {
                    str = a[2];
                }
                else
                {
                    str = a[1] + a[2];
                }
                if(isShowFirst){
                    str = a[0] + str;
                }else if(a[0].indexOf("省")<0){
                    str = a[0] + str;
                }
                break;
        }
        str = str.replace("市辖区",'');
    }

    return str;
},
    loads:function () {

        if (wx.showLoading) {
            // 基础库 1.1.0 微信6.5.6版本开始支持，低版本需做兼容处理
            wx.showLoading({
                title: "正在加载中...",
                mask: true,
                success:function () {
                }
            });
        } else {
            // 低版本采用Toast兼容处理并将时间设为20秒以免自动消失
            wx.showToast({
                title: "正在加载中...",
                icon: 'loading',
                mask: true,
                duration: 20000
            });
        }
    },
    copyObj:function(obj){
      let res = {}
      for (var key in obj) {
        res[key] = obj[key]
      }
      return res
    }
})

